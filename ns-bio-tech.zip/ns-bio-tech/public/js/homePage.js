// public/js/homePage.js

document.addEventListener('DOMContentLoaded', function() {
    renderNavbar('accueil');
    renderFooter();

    const featuresGrid = document.getElementById('featuresGrid');
    const featuredProductsGrid = document.getElementById('featuredProductsGrid');
    const testimonialsGrid = document.getElementById('testimonialsGrid');
    const newsletterForm = document.getElementById('newsletterForm');

    // Injecter les icônes SVG (inchangé)
    const heroArrow = document.querySelector('.icon-arrow-hero');
    if (heroArrow && ICONS_SVG.ArrowRight) heroArrow.innerHTML = ICONS_SVG.ArrowRight;
    const linkArrow = document.querySelector('.icon-arrow-link');
    if (linkArrow && ICONS_SVG.ArrowRight) linkArrow.innerHTML = ICONS_SVG.ArrowRight;
    const sendIcon = document.querySelector('.icon-send');
    if (sendIcon && ICONS_SVG.Send) sendIcon.innerHTML = ICONS_SVG.Send;

    // Fonction pour afficher les "Features" (utilise toujours data.js pour l'instant)
    function displayFeatures() {
        if (!featuresGrid || !siteFeatures || !ICONS_SVG) return; // siteFeatures vient de data.js
        featuresGrid.innerHTML = '';
        siteFeatures.forEach(feature => {
            const iconSvg = ICONS_SVG[feature.icon] || '<svg class="h-6 w-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>';
            const featureCard = `
                <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-100 transition-all duration-300 hover:shadow-md hover:border-emerald-100 hover:-translate-y-1">
                    <div class="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mb-4">
                        ${iconSvg}
                    </div>
                    <h3 class="text-xl font-semibold mb-2 text-gray-800">${feature.title}</h3>
                    <p class="text-gray-600 text-sm">${feature.description}</p>
                </div>
            `;
            featuresGrid.insertAdjacentHTML('beforeend', featureCard);
        });
    }

    /**
     * Récupère les produits "Featured" depuis l'API et les affiche.
     */
    async function fetchAndDisplayFeaturedProducts() {
        if (!featuredProductsGrid) return;
        featuredProductsGrid.innerHTML = "<p class='col-span-full text-center text-gray-500'>Chargement des produits populaires...</p>";

        try {
            // Idéalement, votre API aurait un moyen de filtrer les produits "featured"
            // Exemple: /api/products?featured=true&limit=3
            // Pour ce prototype, nous récupérons tous les produits (approuvés) et filtrons côté client.
            const response = await fetch(`${API_BASE_URL}/products`); // Récupère tous les produits approuvés
            if (!response.ok) {
                throw new Error(`Erreur HTTP ${response.status}`);
            }
            const data = await response.json();

            if (data.success && data.products) {
                // Filtrer pour les produits "isFeatured" et prendre les 3 premiers
                // Ou si votre API ne renvoie pas isFeatured, prendre les 3 premiers produits
                // S'assurer que les produits ont bien le champ isFeatured ou adapter la logique
                const featured = data.products
                    .filter(product => product.disponible === true) // Assurez-vous que ce champ existe et est booléen
                    .slice(0, 3); // Limiter à 3 produits
                
                // Si pas de champ isFeatured, ou pas assez de produits featured, prendre les premiers
                if (featured.length === 0 && data.products.length > 0) {
                    console.warn("Aucun produit marqué comme 'isFeatured'. Affichage des premiers produits disponibles.");
                    // featured = data.products.slice(0, 3); // Fallback
                }


                if (featured.length === 0) {
                    featuredProductsGrid.innerHTML = "<p class='col-span-full text-center text-gray-500'>Aucun produit populaire disponible pour le moment.</p>";
                    return;
                }
                
                featuredProductsGrid.innerHTML = ''; // Vider le message de chargement

                featured.forEach(product => {
                    // La logique de création de la carte produit est la même qu'avant
                    const newBadge = product.isNew ? '<span class="absolute top-2 right-2 bg-emerald-500 text-white text-xs font-bold px-2 py-1 rounded-full">Nouveau</span>' : '';
                    // Le badge isFeatured est implicite car on ne filtre que ceux-là
                    // mais si on avait un fallback on pourrait l'ajouter aussi.

                    // Gestion des étoiles (simplifiée)
                    let starsHtml = '';
                    const rating = product.rating || 0; // S'assurer que rating est un nombre
                    for (let i = 0; i < 5; i++) {
                        starsHtml += `<span class="${i < Math.floor(rating) ? 'text-amber-500 fill-amber-500' : 'text-gray-300'}">${ICONS_SVG.Star || '★'}</span>`;
                    }
                    // Pour une demi-étoile (plus complexe, à ajouter si besoin)
                    // if (rating % 1 >= 0.5) { ... }


                    const productCard = `
                        <div class="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-100 transition-all duration-300 hover:shadow-md flex flex-col h-full">
                            <a href="/produit-detail.html?id=${product._id}" class="block h-full flex flex-col">
                                <div class="relative">
                                    <img src="${product.imageUrl || 'https://via.placeholder.com/300x200?text=NSBIO'}" alt="${product.nom}" class="w-full h-48 object-cover">
                                    ${newBadge}
                                </div>
                                <div class="p-4 flex-grow flex flex-col">
                                    <h3 class="font-semibold text-lg mb-1 text-gray-800">${product.nom}</h3>
                                    <div class="flex items-center mb-2">
                                        <div class="flex items-center">
                                            ${starsHtml}
                                        </div>
                                        <span class="text-sm text-gray-600 ml-1">${rating.toFixed(1)}</span>
                                    </div>
                                    <p class="text-gray-600 text-sm mb-4 line-clamp-2 flex-grow">${product.description || 'Pas de description.'}</p>
                                    <div class="mt-auto flex items-center justify-between">
                                        <span class="font-bold text-emerald-700 text-lg">${product.prix.toFixed(2)} FCFA</span>
                                        <span class="bg-emerald-100 hover:bg-emerald-200 text-emerald-700 p-2 rounded-full transition-colors cursor-pointer">
                                            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3zM16 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM6.5 18a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" /></svg>
                                        </span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    `;
                    featuredProductsGrid.insertAdjacentHTML('beforeend', productCard);
                });
            } else {
                featuredProductsGrid.innerHTML = `<p class='col-span-full text-center text-gray-500'>${data.message || 'Aucun produit populaire à afficher.'}</p>`;
            }
        } catch (error) {
            console.error('Erreur de récupération des produits populaires:', error);
            featuredProductsGrid.innerHTML = "<p class='col-span-full text-center text-red-500'>Une erreur est survenue lors du chargement des produits.</p>";
        }
    }

    // Fonction pour afficher les "Testimonials" (utilise toujours data.js)
    function displayTestimonials() {
        if (!testimonialsGrid || !testimonialsData || !ICONS_SVG) return; // testimonialsData vient de data.js
        testimonialsGrid.innerHTML = '';
        testimonialsData.forEach(testimonial => {
            let starsHtml = '';
            for (let i = 0; i < 5; i++) {
                starsHtml += `<span class="${i < testimonial.rating ? 'text-amber-500 fill-amber-500' : 'text-gray-300'}">${ICONS_SVG.Star || '★'}</span>`;
            }
            const testimonialCard = `
                <div class="bg-gray-50 p-6 rounded-xl shadow-sm border border-gray-100">
                    <div class="flex items-center mb-4">
                        <img src="${testimonial.imageUrl}" alt="${testimonial.name}" class="w-12 h-12 rounded-full object-cover mr-4">
                        <div>
                            <h4 class="font-semibold text-gray-900">${testimonial.name}</h4>
                            <p class="text-sm text-gray-500">${testimonial.role}</p>
                        </div>
                    </div>
                    <div class="flex mb-4">${starsHtml}</div>
                    <p class="text-gray-700 italic text-sm">"${testimonial.content}"</p>
                </div>
            `;
            testimonialsGrid.insertAdjacentHTML('beforeend', testimonialCard);
        });
    }

    // Gérer la soumission du formulaire Newsletter (inchangé)
    if (newsletterForm) { /* ... */ }

    // Appeler les fonctions pour peupler la page
    displayFeatures(); // Toujours depuis data.js
    fetchAndDisplayFeaturedProducts(); // <<--- APPEL MODIFIÉ
    displayTestimonials(); // Toujours depuis data.js
});