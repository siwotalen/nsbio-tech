// public/js/client/clientDashboard.js
document.addEventListener('DOMContentLoaded', async function() {
    const clientUser = protectPage('client', 'authToken', 'userData', '/connexion.html');
    if (!clientUser) return;

    renderClientSidebar('client_dashboard');
    // renderFooter(); // Décommentez si vous avez un footer

    const welcomeMessage = document.getElementById('clientWelcomeMessage');
    const statTotalOrdersSpan = document.getElementById('statTotalOrders');
    const statPendingOrdersSpan = document.getElementById('statPendingOrders');
    const statUnreadNotificationsSpan = document.getElementById('statUnreadNotifications');
    const recentOrdersListDiv = document.getElementById('recentOrdersClientList');
    const recentNotificationsListDiv = document.getElementById('recentNotificationsClientList');
    const messageArea = 'messageAreaClientDashboard';
    
    // Injecter les icônes pour les cartes de stats
    if(ICONS_SVG) {
        document.getElementById('iconTotalOrders').innerHTML = ICONS_SVG.ShoppingCart?.replace('class="lucide', 'class="lucide h-6 w-6') || '';
        document.getElementById('iconPendingOrders').innerHTML = ICONS_SVG.Package?.replace('class="lucide', 'class="lucide h-6 w-6') || '';
        document.getElementById('iconUnreadNotifications').innerHTML = ICONS_SVG.Bell?.replace('class="lucide', 'class="lucide h-6 w-6') || '';
    }


    if (welcomeMessage && clientUser.nomComplet) {
        welcomeMessage.textContent = `Bienvenue, ${clientUser.nomComplet} !`;
    } else if (welcomeMessage && clientUser.email) {
        welcomeMessage.textContent = `Bienvenue, ${clientUser.email} !`;
    }

    async function loadClientDashboardData() {
        const token = localStorage.getItem('authToken');
        if (!token) {
            showMessage("Session invalide, veuillez vous reconnecter.", "error", messageArea);
            return;
        }

        try {
            // 1. Récupérer les commandes
            const ordersResponse = await fetch(`${API_BASE_URL}/orders/my-orders/client?limit=3&page=1&sort=createdAt_desc`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const ordersData = await ordersResponse.json();

            if (ordersResponse.ok && ordersData.success) {
                if(statTotalOrdersSpan) statTotalOrdersSpan.textContent = ordersData.totalOrders || '0';
                const pendingCount = ordersData.orders.filter(o => 
                    ['simulation_payee', 'en_preparation', 'prete_pour_retrait', 'expediee'].includes(o.statutCommande)
                ).length;
                if(statPendingOrdersSpan) statPendingOrdersSpan.textContent = pendingCount;
                displayRecentOrders(ordersData.orders);
            } else {
                if(statTotalOrdersSpan) statTotalOrdersSpan.textContent = 'Er.';
                if(statPendingOrdersSpan) statPendingOrdersSpan.textContent = 'Er.';
                if(recentOrdersListDiv) recentOrdersListDiv.innerHTML = `<p class="text-xs text-red-500">${ordersData.message || "Erreur chargement commandes."}</p>`;
            }

            // 2. Récupérer les notifications
            const notifResponse = await fetch(`${API_BASE_URL}/users/me/notifications?limit=3&page=1&sort=createdAt_desc`, {
                 headers: { 'Authorization': `Bearer ${token}` }
            });
            const notifData = await notifResponse.json();
            if (notifResponse.ok && notifData.success) {
                if(statUnreadNotificationsSpan) statUnreadNotificationsSpan.textContent = notifData.unreadCount || '0';
                displayRecentNotifications(notifData.notifications);
            } else {
                 if(statUnreadNotificationsSpan) statUnreadNotificationsSpan.textContent = 'Er.';
                 if(recentNotificationsListDiv) recentNotificationsListDiv.innerHTML = `<p class="text-xs text-red-500">${notifData.message || "Erreur chargement notifications."}</p>`;
            }

        } catch (error) {
            console.error("Erreur chargement données dashboard client:", error);
            showMessage("Erreur réseau lors du chargement du tableau de bord.", 'error', messageArea);
            if(statTotalOrdersSpan) statTotalOrdersSpan.textContent = 'Er.';
            if(statPendingOrdersSpan) statPendingOrdersSpan.textContent = 'Er.';
            if(statUnreadNotificationsSpan) statUnreadNotificationsSpan.textContent = 'Er.';
            if(recentOrdersListDiv) recentOrdersListDiv.innerHTML = `<p class="text-xs text-red-500">Erreur réseau commandes.</p>`;
            if(recentNotificationsListDiv) recentNotificationsListDiv.innerHTML = `<p class="text-xs text-red-500">Erreur réseau notifications.</p>`;
        }
    }

    function displayRecentOrders(orders) {
        if (!recentOrdersListDiv) return;
        if (!orders || orders.length === 0) {
            recentOrdersListDiv.innerHTML = '<p class="text-sm text-gray-500">Aucune commande récente.</p>';
            return;
        }
        let listHtml = '<ul class="space-y-3">';
        orders.forEach(order => {
            const statutText = order.statutCommande.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
            const statutColor = order.statutCommande === 'livree' || order.statutCommande === 'retiree' ? 'bg-emerald-100 text-emerald-700' : 
                                order.statutCommande === 'annulee' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700';
            listHtml += `
                <li class="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    <div>
                        <p class="font-medium text-sm text-gray-900">Commande #${order._id.slice(-6)}</p>
                        <p class="text-xs text-gray-500">${new Date(order.createdAt).toLocaleDateString('fr-FR')} - ${order.totalCommande.toFixed(2)} FCFA</p>
                    </div>
                    <span class="text-xs font-semibold px-2 py-1 rounded-full ${statutColor}">
                        ${statutText}
                    </span>
                </li>
            `;
        });
        listHtml += '</ul>';
        recentOrdersListDiv.innerHTML = listHtml;
    }

    function displayRecentNotifications(notifications) {
        if (!recentNotificationsListDiv) return;
        if (!notifications || notifications.length === 0) {
            recentNotificationsListDiv.innerHTML = '<p class="text-sm text-gray-500">Aucune notification récente.</p>';
            return;
        }
        let listHtml = '<ul class="space-y-3">';
        notifications.forEach(notif => {
            const iconHtml = ICONS_SVG && ICONS_SVG.Bell ? ICONS_SVG.Bell.replace('class="lucide', 'class="lucide h-5 w-5 text-emerald-600 mr-3 flex-shrink-0') : '🔔';
            listHtml += `
                 <a href="${notif.lienInterne || '#'}" class="block p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors ${!notif.estLue ? 'border-l-4 border-emerald-500' : ''}">
                    <div class="flex items-start">
                        ${iconHtml}
                        <div class="min-w-0 flex-1">
                            <p class="font-medium text-sm text-gray-900 ${!notif.estLue ? 'font-bold' : ''}">${notif.titre || 'Notification'}</p>
                            <p class="text-xs text-gray-500 line-clamp-2">${notif.message}</p>
                            <p class="text-xs text-gray-400 mt-1">${new Date(notif.createdAt).toLocaleString('fr-FR')}</p>
                        </div>
                    </div>
                </a>
            `;
        });
        listHtml += '</ul>';
        recentNotificationsListDiv.innerHTML = listHtml;
    }
    
    loadClientDashboardData();
});