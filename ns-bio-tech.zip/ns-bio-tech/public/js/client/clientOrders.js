// public/js/client/clientOrders.js
document.addEventListener('DOMContentLoaded', function() {
    const clientUser = protectPage('client', 'authToken', 'userData', '/connexion.html');
    if (!clientUser) return;

    renderClientSidebar('client_orders');
    renderFooter();

    const ordersTableContainer = document.getElementById('clientOrdersTableContainer');
    const paginationDiv = document.getElementById('clientOrdersPagination');
    const messageArea = 'messageAreaClientOrders';
    let currentPage = 1;
    const limit = 10;

    async function fetchClientOrders(page = 1) {
        ordersTableContainer.innerHTML = '<p class="text-gray-500 p-6 text-center">Chargement...</p>';
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/orders/my-orders/client?page=${page}&limit=${limit}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await response.json();
            if (response.ok && data.success) {
                displayClientOrders(data.orders);
                displayClientOrdersPagination(data.currentPage, data.totalPages);
            } else {
                throw new Error(data.message || 'Erreur chargement commandes.');
            }
        } catch (error) {
            showMessage(error.message, 'error', messageArea);
            ordersTableContainer.innerHTML = '<p class="text-red-500 p-6 text-center">Erreur chargement.</p>';
        }
    }

    function displayClientOrders(orders) {
        if (!orders || orders.length === 0) {
            ordersTableContainer.innerHTML = '<p class="text-gray-500 p-6 text-center">Vous n\'avez aucune commande pour le moment.</p>';
            return;
        }
        let tableHTML = `
            <table class="w-full min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">N° Commande</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nb Articles</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">`;
        orders.forEach(order => {
            const nbArticles = order.produits.reduce((sum, p) => sum + p.quantite, 0);
            const statutText = order.statutCommande.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
             // Adapter getStatusColor de votre Orders.tsx ou définir des classes Tailwind ici
            const statusColorClasses = getStatusColorTailwind(order.statutCommande);

            tableHTML += `
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">#${order._id.slice(-8)}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${new Date(order.createdAt).toLocaleDateString('fr-FR')}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${nbArticles}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${order.totalCommande.toFixed(2)} FCFA</td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColorClasses}">
                            ${statutText}
                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button onclick="viewOrderDetails('${order._id}')" class="text-emerald-600 hover:text-emerald-800">
                            ${ICONS_SVG && ICONS_SVG.ChevronRight ? ICONS_SVG.ChevronRight.replace('class="lucide', 'class="lucide h-5 w-5') : '→'}
                        </button>
                    </td>
                </tr>`;
        });
        tableHTML += `</tbody></table>`;
        ordersTableContainer.innerHTML = tableHTML;
    }
    
    // Fonction pour obtenir les classes Tailwind pour les statuts (à adapter de votre Orders.tsx)
    function getStatusColorTailwind(status) {
         switch (status) {
             case 'simulation_payee': return 'bg-blue-100 text-blue-700';
             case 'en_preparation': return 'bg-yellow-100 text-yellow-700';
             case 'prete_pour_retrait': return 'bg-indigo-100 text-indigo-700';
             case 'expediee': return 'bg-amber-100 text-amber-700'; // Utiliser amber de votre theme
             case 'livree': case 'retiree': return 'bg-emerald-100 text-emerald-700';
             case 'annulee': return 'bg-red-100 text-red-700';
             default: return 'bg-gray-100 text-gray-700';
         }
    }

     window.viewOrderDetails = function(orderId) { // Rendre globale pour l'attribut onclick
         // Pour le prototype, on peut afficher dans un alert ou un modal simple
         // ou rediriger vers une page de détail de commande (à créer)
         alert(`Détails pour la commande ID: ${orderId} (Page de détail à implémenter).`);
         // window.location.href = `/client/order-detail.html?id=${orderId}`;
     }

    function displayClientOrdersPagination(currentPageNum, totalPagesNum) {
         // ... (Copier/Adapter la logique de pagination, appeler fetchClientOrders au clic) ...
         // Exemple simplifié :
         paginationDiv.innerHTML = ''; // Vider
         if (totalPagesNum <= 1) return;
         for (let i = 1; i <= totalPagesNum; i++) {
             const pageButton = document.createElement('button');
             pageButton.textContent = i;
             pageButton.className = `px-3 py-1.5 mx-0.5 text-xs font-medium border border-gray-300 rounded-md hover:bg-gray-50 ${i === currentPageNum ? 'bg-emerald-600 text-white border-emerald-600' : 'text-gray-600 bg-white'}`;
             if (i === currentPageNum) pageButton.disabled = true;
             pageButton.onclick = () => { currentPage = i; fetchClientOrders(i); };
             paginationDiv.appendChild(pageButton);
         }
    }
    fetchClientOrders(currentPage);
});