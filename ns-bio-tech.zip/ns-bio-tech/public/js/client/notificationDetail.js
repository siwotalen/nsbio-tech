// public/js/client/notificationDetail.js
document.addEventListener('DOMContentLoaded', function() {
    const clientUser = protectPage('client', 'authToken', 'userData', '/connexion.html');
    if (!clientUser) return;

    // Déterminer la clé de page actuelle pour la sidebar
    // Si on veut que "Notifications" reste actif dans le sidebar quand on voit un détail:
    renderClientSidebar('client_notifications');
    // renderFooter();

    const notificationDetailContainer = document.getElementById('notificationDetailContainer');
    const pageTitleH1 = document.getElementById('pageTitle'); // Pour mettre à jour le titre si besoin
    const messageArea = 'messageAreaNotificationDetail';

    const urlParams = new URLSearchParams(window.location.search);
    const notificationId = urlParams.get('id');

    if (!notificationId) {
        notificationDetailContainer.innerHTML = '<p class="text-red-600 bg-red-50 p-4 rounded-md">ID de notification manquant.</p>';
        if (pageTitleH1) pageTitleH1.textContent = "Erreur";
        return;
    }

    async function fetchAndDisplayNotificationDetail() {
        notificationDetailContainer.innerHTML = '<p class="text-gray-500 text-center py-10">Chargement...</p>';
        try {
            const token = localStorage.getItem('authToken');

            // 1. Marquer la notification comme lue (l'API s'en charge si ce n'est pas déjà fait)
            // L'endpoint doit vérifier que la notification appartient bien à l'utilisateur connecté.
            const markReadResponse = await fetch(`${API_BASE_URL}/users/me/notifications/${notificationId}/read`, {
                method: 'PATCH',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const markReadData = await markReadResponse.json();

            if (!markReadResponse.ok || !markReadData.success) {
                // Afficher l'erreur mais continuer pour essayer d'afficher la notif quand même
                showMessage(markReadData.message || "Erreur pour marquer la notification comme lue.", 'error', messageArea);
            } else {
                updateNotificationCounterInNav(); // Mettre à jour le compteur global
            }

            // 2. Récupérer les détails de la notification (un nouvel endpoint API est nécessaire)
            // GET /api/users/me/notifications/:notificationId
            const detailResponse = await fetch(`${API_BASE_URL}/users/me/notifications/${notificationId}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });

            if (!detailResponse.ok) {
                const errorData = await detailResponse.json().catch(() => ({}));
                throw new Error(errorData.message || `Notification non trouvée ou erreur ${detailResponse.status}`);
            }
            const detailData = await detailResponse.json();

            if (detailData.success && detailData.notification) {
                displayNotification(detailData.notification);
            } else {
                throw new Error(detailData.message || 'Impossible de charger la notification.');
            }

        } catch (error) {
            console.error("Erreur fetchNotificationDetail:", error);
            notificationDetailContainer.innerHTML = `<p class="text-red-600 bg-red-50 p-4 rounded-md">Erreur: ${error.message}</p>`;
            if (pageTitleH1) pageTitleH1.textContent = "Erreur Notification";
        }
    }

    function displayNotification(notif) {
        if (pageTitleH1) pageTitleH1.textContent = notif.titre || 'Détail Notification';
        document.title = `${notif.titre || 'Notification'} - NSBIO-TECH`; // Mettre à jour le titre de l'onglet

        const iconHtml = ICONS_SVG && ICONS_SVG.Bell ? ICONS_SVG.Bell.replace('class="lucide', `class="lucide h-8 w-8 mr-4 text-emerald-600 flex-shrink-0"`) : '🔔';

        let metadataHtml = '';
        if (notif.metadata && Object.keys(notif.metadata).length > 0) {
            metadataHtml += '<div class="mt-4 pt-4 border-t border-gray-200"><h4 class="text-sm font-semibold text-gray-700 mb-1">Informations supplémentaires :</h4><ul class="list-disc list-inside text-xs text-gray-600 space-y-0.5">';
            for (const key in notif.metadata) {
                metadataHtml += `<li><strong>${key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}:</strong> ${notif.metadata[key]}</li>`;
            }
            metadataHtml += '</ul></div>';
        }
        
        notificationDetailContainer.innerHTML = `
            <div class="flex items-start mb-4">
                ${iconHtml}
                <div>
                    <h2 class="text-xl font-bold text-gray-800">${notif.titre || 'Notification Importante'}</h2>
                    <p class="text-xs text-gray-500">Reçue le: ${new Date(notif.createdAt).toLocaleString('fr-FR')}</p>
                </div>
            </div>
            <div class="prose prose-sm max-w-none text-gray-700">
                ${
                    // Simple conversion des sauts de ligne en <br> ou utilisation d'une lib Markdown si les messages peuvent en contenir
                    notif.message.replace(/\n/g, '<br>')
                }
            </div>
            ${metadataHtml}
            ${notif.lienInterne ? `
                <div class="mt-6 text-center">
                    <a href="${notif.lienInterne}" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500">
                        Voir les détails associés
                        <svg class="ml-2 -mr-1 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" /></svg>
                    </a>
                </div>
            ` : ''}
        `;
    }

    // Lancer le chargement
    fetchAndDisplayNotificationDetail();
});