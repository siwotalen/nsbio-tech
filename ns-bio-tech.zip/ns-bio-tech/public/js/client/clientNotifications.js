// public/js/client/clientNotifications.js
document.addEventListener('DOMContentLoaded', function() {
    const clientUser = protectPage('client', 'authToken', 'userData', '/connexion.html');
    if (!clientUser) return;

    renderClientSidebar('client_notifications');
    // renderFooter();

    const notificationsListContainer = document.getElementById('notificationsListContainer');
    const paginationDiv = document.getElementById('notificationsPagination');
    const filterSelect = document.getElementById('notificationFilter');
    const markAllReadBtn = document.getElementById('markAllReadButton');
    const totalNotificationsSpan = document.getElementById('totalNotificationsDisplay');
    const unreadNotificationsSpan = document.getElementById('unreadNotificationsDisplay');
    const messageArea = 'messageAreaNotifications';

    let currentPage = 1;
    const limit = 10; // Notifications par page

    async function fetchClientNotifications(page = 1, filter = '') {
        notificationsListContainer.innerHTML = '<p class="text-gray-500 py-4 text-center">Chargement...</p>';
        markAllReadBtn.disabled = true;
        try {
            const token = localStorage.getItem('authToken');
            const params = new URLSearchParams({
                page: page.toString(),
                limit: limit.toString(),
                sort: 'createdAt_desc' // Trier par date de création décroissante
            });
            if (filter) params.append('filter', filter);

            const response = await fetch(`${API_BASE_URL}/users/me/notifications?${params.toString()}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) throw new Error('Erreur lors du chargement des notifications.');
            
            const data = await response.json();

            if (data.success && data.notifications) {
                displayNotifications(data.notifications);
                displayNotificationsPagination(data.currentPage, data.totalPages);
                if(totalNotificationsSpan) totalNotificationsSpan.textContent = data.totalNotifications || 0;
                if(unreadNotificationsSpan) unreadNotificationsSpan.textContent = data.unreadCount || 0;
                markAllReadBtn.disabled = data.unreadCount === 0;
                updateNotificationCounterInNav(); // Mettre à jour le compteur global
            } else {
                notificationsListContainer.innerHTML = `<p class="text-gray-500 py-4 text-center">${data.message || 'Aucune notification trouvée.'}</p>`;
                displayNotificationsPagination(1,1);
            }
        } catch (error) {
            console.error("Erreur fetchClientNotifications:", error);
            showMessage(error.message, 'error', messageArea);
            notificationsListContainer.innerHTML = `<p class="text-red-500 py-4 text-center">Erreur de chargement.</p>`;
        }
    }

    function displayNotifications(notifications) {
        if (notifications.length === 0) {
            notificationsListContainer.innerHTML = '<p class="text-gray-500 py-4 text-center">Aucune notification à afficher.</p>';
            return;
        }
        notificationsListContainer.innerHTML = ''; // Vider
        const ul = document.createElement('ul');
        ul.className = 'divide-y divide-gray-200';
        
        notifications.forEach(notif => {
            const li = document.createElement('li');
            li.className = `notification-item p-4 hover:bg-gray-50 transition-colors ${!notif.estLue ? 'bg-emerald-50 border-l-4 border-emerald-500' : 'bg-white'}`;
            li.dataset.notificationId = notif._id;

            const iconHtml = ICONS_SVG && ICONS_SVG.Bell ? ICONS_SVG.Bell.replace('class="lucide', `class="lucide h-6 w-6 mr-3 flex-shrink-0 ${!notif.estLue ? 'text-emerald-600' : 'text-gray-400'}`) : '🔔';

            li.innerHTML = `
                <a href="/client/notification-detail.html?id=${notif._id}" class="block group">
                    <div class="flex items-start space-x-3">
                        ${iconHtml}
                        <div class="flex-1 min-w-0">
                            <div class="flex justify-between items-center">
                                <p class="text-sm font-semibold text-gray-800 group-hover:text-emerald-600 truncate ${!notif.estLue ? 'font-bold' : ''}">
                                    ${notif.titre || 'Notification NSBIO-TECH'}
                                </p>
                                <p class="text-xs text-gray-400 whitespace-nowrap">${new Date(notif.createdAt).toLocaleString('fr-FR')}</p>
                            </div>
                            <p class="text-sm text-gray-600 mt-1 line-clamp-2">${notif.message}</p>
                        </div>
                        ${!notif.estLue ? `
                            <button data-id="${notif._id}" class="mark-as-read-btn ml-2 p-1 text-xs text-emerald-600 hover:text-emerald-800 font-medium" title="Marquer comme lue">
                                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                            </button>
                        ` : ''}
                    </div>
                </a>
            `;
            // Marquer comme lue au clic sur le corps de la notification
            li.querySelector('a').addEventListener('click', async function(e) {
                // Si pas déjà lue, on la marque comme lue
                if (!notif.estLue) {
                    // e.preventDefault(); // Optionnel: empêcher la navigation si on veut juste marquer et recharger
                    await markNotificationRead(notif._id, li);
                }
                // Laisser la navigation se faire si lienInterne est défini
            });
             const markReadBtn = li.querySelector('.mark-as-read-btn');
            if (markReadBtn) {
                markReadBtn.addEventListener('click', async (e) => {
                    e.stopPropagation(); // Empêcher le clic de se propager au lien <a>
                    e.preventDefault();
                    await markNotificationRead(notif._id, li);
                });
            }
            ul.appendChild(li);
        });
        notificationsListContainer.appendChild(ul);
    }

    async function markNotificationRead(notificationId, listItemElement) {
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/users/me/notifications/${notificationId}/read`, {
                method: 'PATCH',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await response.json();
            if (response.ok && data.success) {
                if (listItemElement) { // Mettre à jour l'UI pour cette notification
                    listItemElement.classList.remove('bg-emerald-50', 'border-l-4', 'border-emerald-500');
                    listItemElement.classList.add('bg-white');
                    const titleP = listItemElement.querySelector('p.font-semibold');
                    if (titleP) titleP.classList.remove('font-bold');
                    const markReadBtn = listItemElement.querySelector('.mark-as-read-btn');
                    if(markReadBtn) markReadBtn.remove();
                }
                fetchClientNotifications(currentPage, filterSelect.value); // Recharger pour mettre à jour les compteurs
            } else {
                showMessage(data.message || "Erreur pour marquer comme lue.", 'error', messageArea);
            }
        } catch (error) {
            showMessage("Erreur réseau pour marquer comme lue.", 'error', messageArea);
        }
    }
    
    async function markAllAsRead() {
        if (!confirm("Êtes-vous sûr de vouloir marquer toutes les notifications comme lues ?")) return;
        markAllReadBtn.disabled = true;
        markAllReadBtn.textContent = "Traitement...";
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/users/me/notifications/read-all`, {
                method: 'PATCH',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await response.json();
            if (response.ok && data.success) {
                showMessage(data.message, 'success', messageArea);
                fetchClientNotifications(1, ''); // Recharger à la première page, tous filtres
                if(filterSelect) filterSelect.value = '';
            } else {
                showMessage(data.message || "Erreur pour marquer toutes comme lues.", 'error', messageArea);
            }
        } catch (error) {
            showMessage("Erreur réseau pour marquer toutes comme lues.", 'error', messageArea);
        } finally {
            markAllReadBtn.disabled = false;
            markAllReadBtn.textContent = "Tout Marquer comme Lu";
        }
    }


    function displayNotificationsPagination(currentPageNum, totalPagesNum) {
        // ... (Copiez la fonction de pagination de parrainCommissionsDetail.js)
        // Remplacez les appels à fetchParrainCommissions par :
        // fetchClientNotifications(page_num, filterSelect.value)
        function displayPagination(currentPageNum, totalPagesNum) {
        commissionPaginationDiv.innerHTML = '';
        if (totalPagesNum <= 1) return;

        // Bouton Précédent
        const prevButton = document.createElement('button');
        prevButton.innerHTML = '« Préc.';
        prevButton.className = 'px-4 py-2 mx-1 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed';
        prevButton.disabled = currentPageNum === 1;
        prevButton.addEventListener('click', () => fetchClientNotifications(page_num, filterSelect.value));
        commissionPaginationDiv.appendChild(prevButton);

        // Afficher quelques numéros de page (simplifié)
        let startPage = Math.max(1, currentPageNum - 2);
        let endPage = Math.min(totalPagesNum, currentPageNum + 2);

        if (currentPageNum <=3) endPage = Math.min(totalPagesNum, 5);
        if (currentPageNum >= totalPagesNum - 2) startPage = Math.max(1, totalPagesNum - 4);


        if (startPage > 1) {
            const firstButton = document.createElement('button');
            firstButton.textContent = '1';
            firstButton.className = 'px-4 py-2 mx-1 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50';
            firstButton.addEventListener('click', () => fetchClientNotifications(1, filterSelect.value));
            commissionPaginationDiv.appendChild(firstButton);
            if (startPage > 2) {
                const ellipsis = document.createElement('span');
                ellipsis.textContent = '...';
                ellipsis.className = 'px-4 py-2 mx-1 text-sm text-gray-500';
                commissionPaginationDiv.appendChild(ellipsis);
            }
        }

        for (let i = startPage; i <= endPage; i++) {
            const pageButton = document.createElement('button');
            pageButton.textContent = i;
            pageButton.className = `px-4 py-2 mx-1 text-sm font-medium border border-gray-300 rounded-md hover:bg-gray-50 ${i === currentPageNum ? 'bg-emerald-600 text-white border-emerald-600' : 'text-gray-700 bg-white'}`;
            if (i === currentPageNum) pageButton.disabled = true;
            pageButton.addEventListener('click', () => fetchClientNotifications(1, filterSelect.value));
            commissionPaginationDiv.appendChild(pageButton);
        }

        if (endPage < totalPagesNum) {
            if (endPage < totalPagesNum - 1) {
                const ellipsis = document.createElement('span');
                ellipsis.textContent = '...';
                ellipsis.className = 'px-4 py-2 mx-1 text-sm text-gray-500';
                commissionPaginationDiv.appendChild(ellipsis);
            }
            const lastButton = document.createElement('button');
            lastButton.textContent = totalPagesNum;
            lastButton.className = 'px-4 py-2 mx-1 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50';
            lastButton.addEventListener('click', () => fetchClientNotifications(page_num, filterSelect.value));
            commissionPaginationDiv.appendChild(lastButton);
        }

        // Bouton Suivant
        const nextButton = document.createElement('button');
        nextButton.innerHTML = 'Suiv. »';
        nextButton.className = 'px-4 py-2 mx-1 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed';
        nextButton.disabled = currentPageNum === totalPagesNum;
        nextButton.addEventListener('click', () => fetchClientNotifications(currentPageNum + 1, statusFilter.value));
        commissionPaginationDiv.appendChild(nextButton);
    }
    
        
    }
    
    if(filterSelect) {
        filterSelect.addEventListener('change', function() {
            currentPage = 1;
            fetchClientNotifications(currentPage, this.value);
        });
    }
    if(markAllReadBtn) {
        markAllReadBtn.addEventListener('click', markAllAsRead);
    }

    fetchClientNotifications(currentPage, filterSelect ? filterSelect.value : '');
});