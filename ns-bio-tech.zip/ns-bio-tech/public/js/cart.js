// public/js/cart.js
document.addEventListener('DOMContentLoaded', function() {
    renderNavbar('panier');
    renderFooter();

    const cartItemsContainer = document.getElementById('cartItemsContainer');
    const cartSummarySection = document.getElementById('cartSummarySection');
    const subtotalAmountSpan = document.getElementById('subtotalAmount');
    const discountAmountSpan = document.getElementById('discountAmount');
    const totalAmountSpan = document.getElementById('totalAmount');
    const promoCodeInput = document.getElementById('promoCodeInput');
    const applyPromoCodeButton = document.getElementById('applyPromoCodeButton');
    const checkoutButton = document.getElementById('checkoutButton');
    const messageArea = 'messageAreaCart'; // ID de la zone de message sur cette page

    const TAUX_REDUCTION_PROMO_SIMULE = 0.05; // 5%
    let currentCart = [];
    let currentDiscount = 0; // Pour stocker la réduction appliquée

    function renderCart() {
        currentCart = JSON.parse(localStorage.getItem('cart')) || [];
        cartItemsContainer.innerHTML = '';

        if (currentCart.length === 0) {
            cartItemsContainer.innerHTML = '<p class="text-gray-500 text-center py-10">Votre panier est actuellement vide. <a href="/catalogue.html" class="text-emerald-600 hover:underline">Continuer vos achats</a>.</p>';
            cartSummarySection.classList.add('hidden');
            checkoutButton.disabled = true;
            updateCartCounterInNav();
            return;
        }

        cartSummarySection.classList.remove('hidden');
        checkoutButton.disabled = false;
        let subtotal = 0;

        currentCart.forEach((item, index) => {
            const itemSubtotal = item.prix * item.quantity;
            subtotal += itemSubtotal;
            const typeText = item.typeElement === 'produit' ? 'Produit' : 'Service';

            const cartItemDiv = document.createElement('div');
            cartItemDiv.className = 'flex items-center gap-4 py-4 border-b border-gray-200 last:border-b-0';
            cartItemDiv.innerHTML = `
                <img src="${item.imageUrl || 'https://via.placeholder.com/80'}" alt="${item.nom}" class="w-20 h-20 object-cover rounded-lg">
                <div class="flex-1 min-w-0">
                    <h3 class="text-md font-semibold text-gray-800 truncate">${item.nom}</h3>
                    <p class="text-xs text-gray-500 capitalize">${typeText} - ${item.prix.toFixed(2)} FCFA/unité</p>
                    <div class="mt-2 flex items-center">
                        <button data-index="${index}" class="quantity-change p-1 text-gray-500 hover:text-emerald-600 rounded-full hover:bg-gray-100" data-delta="-1">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4"></path></svg>
                        </button>
                        <input type="number" value="${item.quantity}" min="1" 
                               ${item.typeElement === 'produit' && item.quantiteEnStock ? `max="${item.quantiteEnStock}"` : ''} 
                               data-index="${index}" 
                               class="item-quantity-input w-12 mx-2 text-center border-gray-300 rounded-md focus:ring-emerald-500 focus:border-emerald-500 text-sm py-1" readonly>
                        <button data-index="${index}" class="quantity-change p-1 text-gray-500 hover:text-emerald-600 rounded-full hover:bg-gray-100" data-delta="1">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                        </button>
                    </div>
                </div>
                <div class="text-right">
                    <p class="text-md font-semibold text-gray-800">${itemSubtotal.toFixed(2)} FCFA</p>
                    <button data-index="${index}" class="remove-item-button text-xs text-red-500 hover:text-red-700 hover:underline mt-1">
                        Retirer
                    </button>
                </div>
            `;
            cartItemsContainer.appendChild(cartItemDiv);
        });

        updateSummary(subtotal, false); // Ne pas réappliquer le code promo juste en rendant
        addCartEventListeners();
        updateCartCounterInNav();
    }

    function updateSummary(subtotal, applyPromo = true) {
        const promoCode = promoCodeInput.value.trim().toUpperCase();
        
        if (applyPromo && promoCode !== "") {
            // Simulation de la validation du code promo.
            // Pour ce proto, on vérifie si le code est celui stocké avec l'utilisateur (codeParrainSaisi)
            const userData = getAuthenticatedUser();
            if (userData && userData.codeParrainSaisi && userData.codeParrainSaisi === promoCode) {
                currentDiscount = subtotal * TAUX_REDUCTION_PROMO_SIMULE;
                showMessage(`Code promo "${promoCode}" appliqué ! Vous bénéficiez de ${TAUX_REDUCTION_PROMO_SIMULE * 100}% de réduction.`, 'success', messageArea);
            } else if (userData && userData.codeParrainSaisi && userData.codeParrainSaisi !== promoCode) {
                currentDiscount = 0;
                showMessage(`Le code promo "${promoCode}" ne correspond pas à votre code parrain enregistré. Aucune réduction appliquée.`, 'error', messageArea);
            } else if (promoCode) { // Un code est entré mais l'utilisateur n'a pas de codeParrainSaisi
                currentDiscount = 0; // Ou simuler une réduction générique pour test
                showMessage(`Code promo "${promoCode}" entré. La validation des codes tiers n'est pas encore implémentée pour ce prototype.`, 'info', messageArea);
                // console.warn("Validation de code promo tiers non implémentée.");
            } else {
                currentDiscount = 0; // Pas de code, pas de réduction
            }
        } else if (!applyPromo && promoCode === "") { // Si le champ code est vidé, on enlève la réduc stockée
            currentDiscount = 0;
        }
        // Si applyPromo est false, on utilise currentDiscount tel quel (s'il a été appliqué avant)


        const total = subtotal - currentDiscount;
        subtotalAmountSpan.textContent = `${subtotal.toFixed(2)} FCFA`;
        discountAmountSpan.textContent = `-${currentDiscount.toFixed(2)} FCFA`;
        totalAmountSpan.textContent = `${total.toFixed(2)} FCFA`;
    }

    function addCartEventListeners() {
        document.querySelectorAll('.quantity-change').forEach(button => {
            button.addEventListener('click', function() {
                const index = parseInt(this.dataset.index);
                const delta = parseInt(this.dataset.delta);
                let newQuantity = currentCart[index].quantity + delta;
                const item = currentCart[index];

                if (newQuantity < 1) newQuantity = 1;
                if (item.typeElement === 'produit' && item.quantiteEnStock && newQuantity > item.quantiteEnStock) {
                    newQuantity = item.quantiteEnStock;
                    showMessage(`Stock maximum atteint pour "${item.nom}".`, 'info', messageArea);
                }
                currentCart[index].quantity = newQuantity;
                saveCartAndUpdate();
            });
        });
        // Mettre à jour manuellement la quantité si l'utilisateur tape directement (plus complexe à gérer proprement)
        // Pour l'instant, on se fie aux boutons +/-

        document.querySelectorAll('.remove-item-button').forEach(button => {
            button.addEventListener('click', function() {
                const index = parseInt(this.dataset.index);
                currentCart.splice(index, 1);
                saveCartAndUpdate();
            });
        });
    }
    
    if (applyPromoCodeButton) {
        applyPromoCodeButton.addEventListener('click', () => {
            let subtotal = 0;
            currentCart.forEach(item => { subtotal += item.prix * item.quantity; });
            updateSummary(subtotal, true); // Forcer la réévaluation du code promo
        });
    }
    // Optionnel: réévaluer le code promo si l'input change
    // if(promoCodeInput){
    //     promoCodeInput.addEventListener('input', () => {
    //         if(promoCodeInput.value.trim() === "") currentDiscount = 0; // Reset discount if code removed
    //         let subtotal = 0;
    //         currentCart.forEach(item => { subtotal += item.prix * item.quantity; });
    //         updateSummary(subtotal, false); // Mettre à jour le total sans réappliquer automatiquement la promo
    //     });
    // }


    function saveCartAndUpdate() {
        localStorage.setItem('cart', JSON.stringify(currentCart));
        renderCart();
    }

    async function handleCheckout() {
        const user = getAuthenticatedUser();
        if (!user) { /* ... (message connexion requise) ... */ return; }
        if (user.role !== 'client') { /* ... (seuls clients) ... */ return; }
        if (currentCart.length === 0) { /* ... (panier vide) ... */ return; }

        const codePromoPourApi = promoCodeInput.value.trim().toUpperCase();
        let reductionEffectivementAppliquee = 0;
        // Recalculer la réduction au moment du checkout pour s'assurer qu'elle est valide
        let subtotalCheckout = currentCart.reduce((sum, item) => sum + item.prix * item.quantity, 0);
         if (codePromoPourApi) {
            if (user.codeParrainSaisi && user.codeParrainSaisi === codePromoPourApi) {
                 reductionEffectivementAppliquee = subtotalCheckout * TAUX_REDUCTION_PROMO_SIMULE;
            } else {
                // Pour le proto, si le code n'est pas celui du client, on ne l'envoie pas ou on informe.
                // Le backend fera la validation finale du code de toute façon.
                 console.log("Le code promo entré sera validé par le backend.")
            }
        }


        const orderPayload = {
            produits: currentCart.map(item => ({
                idProduit: item._id,
                quantite: item.quantity
            })),
            codePromo: codePromoPourApi || undefined
        };

        showMessage('Traitement de votre commande...', 'info', messageArea);
        checkoutButton.disabled = true;
        checkoutButton.innerHTML = `<svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>En cours...`;

        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/orders/simulate`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`},
                body: JSON.stringify(orderPayload)
            });
            const data = await response.json();

            if (response.ok && data.success) {
                localStorage.removeItem('cart');
                currentCart = [];
                // La redirection se fait maintenant vers commande-confirmee.html
                let confirmationUrl = `/client/commande-confirmee.html`;
                const params = new URLSearchParams();
                if (data.orderId) params.append('orderId', data.orderId);
                if (data.details && data.details.totalAPayer) params.append('total', data.details.totalAPayer);
                if (params.toString()) confirmationUrl += `?${params.toString()}`;
                
                showMessage(data.message || 'Commande simulée réussie!', 'success', messageArea);
                setTimeout(() => { window.location.href = confirmationUrl; }, 1500);

            } else {
                showMessage(data.message || 'Erreur lors de la commande.', 'error', messageArea);
                checkoutButton.disabled = false;
                checkoutButton.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-5 h-5"><path d="M10 2a3 3 0 00-3 3v1H5a2 2 0 00-2 2v7a2 2 0 002 2h10a2 2 0 002-2V8a2 2 0 00-2-2h-2V5a3 3 0 00-3-3zm0 2a1 1 0 011 1v1H9V5a1 1 0 011-1zM5 8h10v7H5V8z" /></svg> Passer la Commande`;
            }
        } catch (error) {
            console.error('Erreur Checkout:', error);
            showMessage('Une erreur réseau est survenue.', 'error', messageArea);
            checkoutButton.disabled = false;
            checkoutButton.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-5 h-5"><path d="M10 2a3 3 0 00-3 3v1H5a2 2 0 00-2 2v7a2 2 0 002 2h10a2 2 0 002-2V8a2 2 0 00-2-2h-2V5a3 3 0 00-3-3zm0 2a1 1 0 011 1v1H9V5a1 1 0 011-1zM5 8h10v7H5V8z" /></svg> Passer la Commande`;
        }
    }

    if (checkoutButton) checkoutButton.addEventListener('click', handleCheckout);
    if (applyPromoCodeButton) applyPromoCodeButton.addEventListener('click', () => {
        let subtotal = currentCart.reduce((sum, item) => sum + item.prix * item.quantity, 0);
        updateSummary(subtotal, true); // true pour forcer la réévaluation du code
    });


    renderCart(); // Chargement initial
});