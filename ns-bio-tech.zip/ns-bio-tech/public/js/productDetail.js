// public/js/productDetail.js
document.addEventListener('DOMContentLoaded', function() {
    renderNavbar('produit_detail');
    renderFooter();

    const productDetailContentDiv = document.getElementById('productDetailContent');
    const messageArea = 'messageAreaProductDetail'; // ID de la zone de message sur cette page

    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');

    if (!productId) {
        productDetailContentDiv.innerHTML = '<p class="text-red-600 bg-red-50 p-4 rounded-md">Aucun produit spécifié. Veuillez retourner au catalogue.</p>';
        return;
    }

    async function fetchProductDetails() {
        try {
            const response = await fetch(`${API_BASE_URL}/products/single/${productId}`);
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `Produit non trouvé ou erreur ${response.status}`);
            }
            const data = await response.json();

            if (data.success && data.product) {
                displayProductDetails(data.product);
            } else {
                throw new Error(data.message || 'Impossible de charger les détails du produit.');
            }
        } catch (error) {
            console.error('Erreur de récupération des détails du produit:', error);
            productDetailContentDiv.innerHTML = `<p class="text-red-600 bg-red-50 p-4 rounded-md">Erreur: ${error.message}</p>`;
        }
    }

    function displayProductDetails(product) {
        document.title = `${product.nom} - NSBIO-TECH`;

        const typeBadgeClass = product.typeElement === 'produit' ? 'bg-blue-100 text-blue-700' : 'bg-emerald-100 text-emerald-700';
        const typeText = product.typeElement === 'produit' ? 'Produit' : 'Service';

        let specificsHtml = '';
        if (product.typeElement === 'produit') {
            specificsHtml = `<p class="text-sm text-gray-600"><strong>Stock disponible :</strong> 
                <span class="${product.quantiteEnStock > 0 ? 'text-emerald-600' : 'text-red-600'} font-semibold">
                    ${product.quantiteEnStock > 0 ? product.quantiteEnStock + ' unités' : 'Épuisé'}
                </span></p>`;
        } else if (product.typeElement === 'service') {
            if(product.dureeServiceMinutes) specificsHtml += `<p class="text-sm text-gray-600"><strong>Durée :</strong> ${product.dureeServiceMinutes} minutes</p>`;
            if(product.lieuService) specificsHtml += `<p class="text-sm text-gray-600"><strong>Lieu :</strong> ${product.lieuService}</p>`;
        }
        
        let starsHtml = '';
        const rating = product.rating || 0;
        for (let i = 1; i <= 5; i++) {
            starsHtml += `<svg class="h-5 w-5 ${i <= rating ? 'text-amber-500 fill-amber-500' : 'text-gray-300'}" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /></svg>`;
        }


        productDetailContentDiv.innerHTML = `
            <div class="grid md:grid-cols-2 gap-8 items-start">
                <div class="product-detail-image bg-gray-100 rounded-lg p-4">
                    <img src="${product.imageUrl || 'https://via.placeholder.com/400x300?text=Image+Indisponible'}" alt="${product.nom}" class="w-full h-auto max-h-[500px] object-contain rounded-md">
                </div>
                <div class="product-detail-info space-y-4">
                    <div>
                        <span class="text-xs font-semibold uppercase tracking-wider px-2 py-1 rounded-full ${typeBadgeClass}">${typeText}</span>
                        ${product.categorie ? `<span class="ml-2 text-xs font-semibold uppercase tracking-wider px-2 py-1 rounded-full bg-gray-200 text-gray-700">${product.categorie}</span>` : ''}
                    </div>
                    <h1 class="text-3xl lg:text-4xl font-bold text-gray-900">${product.nom}</h1>
                    <div class="flex items-center">
                        ${starsHtml}
                        <span class="ml-2 text-sm text-gray-600">(${rating.toFixed(1)} évaluation)</span>
                    </div>
                    <p class="text-3xl font-bold text-emerald-600">${product.prix.toFixed(2)} FCFA</p>
                    <div class="prose prose-sm text-gray-700">
                        <p>${product.description || 'Aucune description détaillée disponible.'}</p>
                    </div>
                    ${specificsHtml ? `<div class="product-specifics mt-4 p-4 bg-gray-50 rounded-md border border-gray-200">${specificsHtml}</div>` : ''}
                    
                    <div class="add-to-cart-section mt-6 flex items-center gap-4">
                        ${(product.typeElement === 'produit' && product.quantiteEnStock > 0) || product.typeElement === 'service' ? `
                            <div class="flex items-center">
                                <label for="quantity" class="mr-2 text-sm font-medium text-gray-700">Quantité:</label>
                                <input type="number" id="quantity" name="quantity" value="1" min="1" 
                                       ${product.typeElement === 'produit' ? `max="${product.quantiteEnStock}"` : 'max="10"'} 
                                       class="w-20 pl-4 pr-2 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 text-center">
                            </div>
                            <button id="addToCartButton" class="w-full md:w-auto flex-grow bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors flex items-center justify-center gap-2">
                                ${ICONS_SVG && ICONS_SVG.ShoppingCart ? ICONS_SVG.ShoppingCart.replace('class="lucide', 'class="lucide h-5 w-5') : '🛒'}
                                Ajouter au Panier
                            </button>
                        ` : product.typeElement === 'produit' ? '<p class="text-red-600 font-semibold">Produit actuellement épuisé.</p>' : ''}
                    </div>

                    ${product.idVendeur && product.idVendeur.nomBoutique ? `
                        <div class="vendor-info mt-6 pt-4 border-t border-gray-200">
                            <h3 class="text-md font-semibold text-gray-700 mb-1">Vendu et expédié par :</h3>
                            <p><a href="/boutique-profil.html?id=${product.idVendeur._id}" class="text-emerald-600 hover:text-emerald-700">${product.idVendeur.nomBoutique}</a></p>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;

        const addToCartBtn = document.getElementById('addToCartButton');
        if (addToCartBtn) {
            addToCartBtn.addEventListener('click', () => handleAddToCart(product));
        }
    }

    function handleAddToCart(product) {
        // ... (Copiez votre fonction handleAddToCart de la réponse précédente pour productDetail.js)
        // Assurez-vous qu'elle utilise le messageAreaId 'messageAreaProductDetail'
        const quantityInput = document.getElementById('quantity');
        const quantity = quantityInput ? parseInt(quantityInput.value) : 1;

        if (isNaN(quantity) || quantity < 1) {
            showMessage('Veuillez entrer une quantité valide.', 'error', messageArea);
            return;
        }
        if (product.typeElement === 'produit' && quantity > product.quantiteEnStock) {
            showMessage('La quantité demandée dépasse le stock disponible.', 'error', messageArea);
            return;
        }

        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        const existingProductIndex = cart.findIndex(item => item._id === product._id);

        if (existingProductIndex > -1) {
            let newQuantity = cart[existingProductIndex].quantity + quantity;
            if (product.typeElement === 'produit' && product.quantiteEnStock && newQuantity > product.quantiteEnStock) {
                newQuantity = product.quantiteEnStock;
                showMessage(`Quantité ajustée au stock disponible (${product.quantiteEnStock}). Panier mis à jour.`, 'info', messageArea);
            }
            cart[existingProductIndex].quantity = newQuantity;
        } else {
            cart.push({
                _id: product._id, nom: product.nom, prix: product.prix, imageUrl: product.imageUrl,
                typeElement: product.typeElement, quantiteEnStock: product.quantiteEnStock, quantity: quantity
            });
        }
        localStorage.setItem('cart', JSON.stringify(cart));
        showMessage(`${product.nom} (x${quantity}) ajouté au panier !`, 'success', messageArea);
        updateCartCounterInNav();
    }

    fetchProductDetails();
});