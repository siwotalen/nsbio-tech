// public/js/boutique/pickupPoints.js
document.addEventListener('DOMContentLoaded', function() {
    const boutiqueUser = protectPage('boutique', 'authToken', 'userData', '/connexion.html');
    if (!boutiqueUser) return;

    renderBoutiqueSidebar('boutique_pickup');
    // renderFooter();

    const listContainer = document.getElementById('pickupPointsListContainer');
    const messageArea = 'messageAreaPickupPoints';
    
    // Modal elements
    const modal = document.getElementById('pickupPointModal');
    const modalTitle = document.getElementById('modalTitle');
    const pickupPointForm = document.getElementById('pickupPointForm');
    const pickupPointIdInput = document.getElementById('pickupPointId');
    const nomPointInput = document.getElementById('nomPoint');
    const adressePointInput = document.getElementById('adressePoint');
    const villePointInput = document.getElementById('villePoint');
    const horairesPointInput = document.getElementById('horairesPoint');
    const instructionsPointInput = document.getElementById('instructionsPoint');
    const saveButton = document.getElementById('savePickupPointButton');
    const cancelButton = document.getElementById('cancelFormButton');
    const closeModalButton = document.getElementById('closeModalButton');
    const addPickupPointButton = document.getElementById('addPickupPointButton');

    let currentPickupPoints = []; // Pour garder les points chargés

    async function fetchPickupPoints() {
        listContainer.innerHTML = '<p class="text-gray-500 p-4 text-center">Chargement...</p>';
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/shops/me/points-retrait`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) {
                const errData = await response.json().catch(() => ({}));
                throw new Error(errData.message || "Erreur chargement des points de retrait.");
            }
            const data = await response.json();
            if (data.success && data.pointsDeRetrait) {
                currentPickupPoints = data.pointsDeRetrait;
                displayPickupPoints(currentPickupPoints);
            } else {
                listContainer.innerHTML = `<p class="text-gray-500 p-4 text-center">${data.message || 'Aucun point de retrait configuré.'}</p>`;
            }
        } catch (error) {
            console.error("Erreur fetchPickupPoints:", error);
            showMessage(error.message, 'error', messageArea);
            listContainer.innerHTML = `<p class="text-red-500 p-4 text-center">Erreur de chargement.</p>`;
        }
    }

    function displayPickupPoints(points) {
        if (points.length === 0) {
            listContainer.innerHTML = `
                <div class="text-center py-6">
                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                        <path vector-effect="non-scaling-stroke" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path vector-effect="non-scaling-stroke" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
                    </svg>
                    <h3 class="mt-2 text-sm font-medium text-gray-900">Aucun point de retrait</h3>
                    <p class="mt-1 text-sm text-gray-500">Commencez par ajouter votre premier point de retrait.</p>
                </div>`;
            return;
        }
        let listHTML = '<ul class="divide-y divide-gray-200">';
        points.forEach(point => {
            listHTML += `
                <li class="py-4 px-2 sm:px-0">
                    <div class="flex items-center justify-between gap-4">
                        <div class="min-w-0 flex-1">
                            <p class="text-sm font-semibold text-emerald-700 truncate">${point.nom}</p>
                            <p class="text-xs text-gray-600 truncate">${point.adresse}${point.ville ? ', ' + point.ville : ''}</p>
                            ${point.horairesOuverture ? `<p class="text-xs text-gray-500">Horaires: ${point.horairesOuverture}</p>` : ''}
                            ${point.instructionsSupplementaires ? `<p class="text-xs text-gray-500 italic">Instructions: ${point.instructionsSupplementaires}</p>` : ''}
                        </div>
                        <div class="flex-shrink-0 flex space-x-2">
                            <button data-id="${point._id}" class="edit-point-btn p-1.5 text-indigo-600 hover:text-indigo-800 rounded-md hover:bg-indigo-50" title="Modifier">
                                <svg class="h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" /></svg>
                            </button>
                            <button data-id="${point._id}" class="delete-point-btn p-1.5 text-red-600 hover:text-red-800 rounded-md hover:bg-red-50" title="Supprimer">
                                 <svg class="h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" /></svg>
                            </button>
                        </div>
                    </div>
                </li>
            `;
        });
        listHTML += `</ul>`;
        listContainer.innerHTML = listHTML;
        addListActionListeners();
    }

    function addListActionListeners() {
        document.querySelectorAll('.edit-point-btn').forEach(button => {
            button.addEventListener('click', function() {
                const pointId = this.dataset.id;
                const pointToEdit = currentPickupPoints.find(p => p._id === pointId);
                if (pointToEdit) openModalForEdit(pointToEdit);
            });
        });
        document.querySelectorAll('.delete-point-btn').forEach(button => {
            button.addEventListener('click', function() {
                const pointId = this.dataset.id;
                if (confirm('Êtes-vous sûr de vouloir supprimer ce point de retrait ?')) {
                    deletePickupPoint(pointId);
                }
            });
        });
    }

    function openModalForAdd() {
        pickupPointForm.reset();
        pickupPointIdInput.value = ''; // Pas d'ID pour un ajout
        modalTitle.textContent = 'Ajouter un Nouveau Point de Retrait';
        saveButton.textContent = 'Ajouter';
        modal.classList.remove('hidden');
    }

    function openModalForEdit(point) {
        pickupPointForm.reset();
        pickupPointIdInput.value = point._id;
        nomPointInput.value = point.nom;
        adressePointInput.value = point.adresse;
        villePointInput.value = point.ville || '';
        horairesPointInput.value = point.horairesOuverture || '';
        instructionsPointInput.value = point.instructionsSupplementaires || '';
        modalTitle.textContent = 'Modifier le Point de Retrait';
        saveButton.textContent = 'Enregistrer les Modifications';
        modal.classList.remove('hidden');
    }

    function closeModal() {
        modal.classList.add('hidden');
    }

    if(addPickupPointButton) addPickupPointButton.addEventListener('click', openModalForAdd);
    if(closeModalButton) closeModalButton.addEventListener('click', closeModal);
    if(cancelButton) cancelButton.addEventListener('click', closeModal);
    if(modal) modal.addEventListener('click', (event) => { // Fermer si on clique sur le backdrop
        if (event.target === modal) closeModal();
    });


    if (pickupPointForm) {
        pickupPointForm.addEventListener('submit', async function(event) {
            event.preventDefault();
            const id = pickupPointIdInput.value;
            const pointData = {
                nom: nomPointInput.value,
                adresse: adressePointInput.value,
                ville: villePointInput.value,
                horairesOuverture: horairesPointInput.value,
                instructionsSupplementaires: instructionsPointInput.value
            };

            const method = id ? 'PUT' : 'POST';
            const url = id ? `${API_BASE_URL}/shops/me/points-retrait/${id}` : `${API_BASE_URL}/shops/me/points-retrait`;
            const actionText = id ? 'Mise à jour' : 'Ajout';

            saveButton.disabled = true;
            saveButton.textContent = 'Enregistrement...';
            showMessage(`${actionText} en cours...`, 'info', messageArea);

            try {
                const token = localStorage.getItem('authToken');
                const response = await fetch(url, {
                    method: method,
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify(pointData)
                });
                const data = await response.json();
                if (response.ok && data.success) {
                    showMessage(data.message || `Point de retrait ${id ? 'mis à jour' : 'ajouté'} avec succès!`, 'success', messageArea);
                    closeModal();
                    fetchPickupPoints(); // Recharger la liste
                } else {
                    showMessage(data.message || `Erreur lors de ${actionText.toLowerCase()}.`, 'error', messageArea);
                }
            } catch (error) {
                showMessage(`Erreur réseau lors de ${actionText.toLowerCase()}.`, 'error', messageArea);
            } finally {
                saveButton.disabled = false;
                saveButton.textContent = id ? 'Enregistrer les Modifications' : 'Ajouter';
            }
        });
    }
    
    async function deletePickupPoint(pointId) {
        showMessage('Suppression en cours...', 'info', messageArea);
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/shops/me/points-retrait/${pointId}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await response.json();
            if (response.ok && data.success) {
                showMessage(data.message || 'Point de retrait supprimé.', 'success', messageArea);
                fetchPickupPoints(); // Recharger la liste
            } else {
                showMessage(data.message || 'Erreur suppression.', 'error', messageArea);
            }
        } catch (error) {
            showMessage('Erreur réseau suppression.', 'error', messageArea);
        }
    }

    // Chargement initial
    fetchPickupPoints();
});