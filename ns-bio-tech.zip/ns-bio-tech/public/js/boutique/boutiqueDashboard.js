// public/js/boutique/boutiqueDashboard.js

document.addEventListener('DOMContentLoaded', async function() {
    const boutiqueUser = protectPage('boutique', 'authToken', 'userData', '/connexion.html');
    if (!boutiqueUser) return;

    renderBoutiqueSidebar('boutique_dashboard'); // Appel de la fonction de layout
    // renderFooter(); // Si vous avez un footer global

    const welcomeMessage = document.getElementById('boutiqueWelcomeMessage');
    // Infos abonnement (déjà dans le HTML, on les remplit)
    const aboTypeSpan = document.getElementById('aboType');
    const aboLimiteSpan = document.getElementById('aboLimite');
    const aboActifsSpan = document.getElementById('aboActifs');
    // Stats
    const statPendingBoutiqueOrdersSpan = document.getElementById('statPendingBoutiqueOrders');
    const statPendingValidationProductsSpan = document.getElementById('statPendingValidationProducts');
    // Listes
    const recentProductListDiv = document.getElementById('boutiqueRecentProductList');
    const recentOrdersListDiv = document.getElementById('boutiqueRecentOrdersList');
    const messageArea = 'messageAreaBoutiqueDashboard';

    if (welcomeMessage && boutiqueUser.nomBoutique) {
        welcomeMessage.textContent = `Bienvenue sur votre espace, ${boutiqueUser.nomBoutique} !`;
    } else if (welcomeMessage && boutiqueUser.email) {
        welcomeMessage.textContent = `Bienvenue, Boutique (${boutiqueUser.email}) !`;
    }

    function displaySubscriptionInfo(user) {
        if(aboTypeSpan) aboTypeSpan.textContent = user.typeAbonnement ? user.typeAbonnement.replace(/\b\w/g, l => l.toUpperCase()) : 'N/A';
        if(aboLimiteSpan) aboLimiteSpan.textContent = typeof user.limiteProduits === 'number' ? user.limiteProduits : 'N/A';
        // aboActifsSpan sera mis à jour après le fetch des produits
    }

    async function loadDashboardData() {
        const token = localStorage.getItem('authToken');
        if (!token) return;

        // Afficher les infos d'abonnement depuis l'utilisateur local (déjà à jour)
        displaySubscriptionInfo(boutiqueUser);

        try {
            // 1. Récupérer les produits de la boutique pour les stats et l'aperçu
            const productsResponse = await fetch(`${API_BASE_URL}/products/my-products?limit=5&sort=createdAt_desc`, { // Récupérer les 5 derniers
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const productsData = await productsResponse.json();
            if (productsResponse.ok && productsData.success) {
                if(aboActifsSpan) aboActifsSpan.textContent = productsData.products.length; // Ou un count total si l'API le donne
                
                const pendingValidationCount = productsData.products.filter(p => p.statutValidation === 'en_attente').length;
                if(statPendingValidationProductsSpan) statPendingValidationProductsSpan.textContent = pendingValidationCount;

                displayRecentItems(productsData.products, recentProductListDiv, formatProductItem);
            } else {
                showMessage(productsData.message || "Erreur chargement des produits.", 'error', messageArea);
            }

            // 2. Récupérer les commandes de la boutique pour les stats et l'aperçu
            const ordersResponse = await fetch(`${API_BASE_URL}/orders/my-orders/boutique?limit=5&sort=createdAt_desc`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const ordersData = await ordersResponse.json();
            if (ordersResponse.ok && ordersData.success) {
                const pendingOrdersCount = ordersData.orders.filter(o => 
                    o.statutCommande === 'simulation_payee' || o.statutCommande === 'en_preparation'
                ).length;
                if(statPendingBoutiqueOrdersSpan) statPendingBoutiqueOrdersSpan.textContent = pendingOrdersCount;

                displayRecentItems(ordersData.orders, recentOrdersListDiv, formatOrderItem);
            } else {
                showMessage(ordersData.message || "Erreur chargement des commandes.", 'error', messageArea);
            }

        } catch (error) {
            console.error("Erreur chargement données dashboard boutique:", error);
            showMessage("Erreur réseau lors du chargement du tableau de bord.", 'error', messageArea);
        }
    }

    function displayRecentItems(items, container, formatter) {
        if (!container) return;
        if (!items || items.length === 0) {
            container.innerHTML = `<p class="text-sm text-gray-500">Aucun élément récent à afficher.</p>`;
            return;
        }
        container.innerHTML = '';
        const ul = document.createElement('ul');
        ul.className = 'space-y-3';
        items.forEach(item => {
            ul.appendChild(formatter(item));
        });
        container.appendChild(ul);
    }

    function formatProductItem(product) {
        const li = document.createElement('li');
        li.className = 'flex items-center justify-between p-2.5 bg-gray-50 rounded-md hover:bg-gray-100';
        const statutText = product.statutValidation.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
        const statutColor = product.statutValidation === 'approuve' ? 'text-emerald-600' : product.statutValidation === 'rejete' ? 'text-red-600' : 'text-amber-600';
        li.innerHTML = `
            <div>
                <p class="font-medium text-sm text-gray-800">${product.nom}</p>
                <p class="text-xs text-gray-500">${product.prix.toFixed(2)} FCFA - <span class="${statutColor} font-semibold">${statutText}</span></p>
            </div>
            <a href="/boutique/edit-product.html?id=${product._id}" class="text-xs text-emerald-600 hover:underline">Gérer</a>
        `;
        return li;
    }

    function formatOrderItem(order) {
        const li = document.createElement('li');
        li.className = 'flex items-center justify-between p-2.5 bg-gray-50 rounded-md hover:bg-gray-100';
        const clientName = order.idClient ? (order.idClient.nomComplet || order.idClient.email) : 'Client inconnu';
        const statutText = order.statutCommande.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
        li.innerHTML = `
            <div>
                <p class="font-medium text-sm text-gray-800">Cmd #${order._id.slice(-6)} <span class="text-xs text-gray-500">par ${clientName}</span></p>
                <p class="text-xs text-gray-500">${order.totalCommande.toFixed(2)} FCFA - ${new Date(order.createdAt).toLocaleDateString()}</p>
            </div>
            <span class="text-xs font-semibold px-2 py-1 rounded-full ${order.statutCommande === 'livree' || order.statutCommande === 'retiree' ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'}">${statutText}</span>
        `;
        return li;
    }

    // Charger les données
    loadDashboardData();
});