// public/js/boutique/manageProduct.js
document.addEventListener('DOMContentLoaded', async function() {
    const boutiqueUser = protectPage('boutique', 'authToken', 'userData', '/connexion.html');
    if (!boutiqueUser) return;

    // Déterminer la clé de page pour le sidebar en fonction de l'URL
    const isEditMode = window.location.pathname.includes('edit-product.html');
    renderBoutiqueSidebar(isEditMode ? 'boutique_my_products' : 'boutique_add_product'); // Mettre en évidence 'Mes Produits' si édition
    // renderFooter();

    const productForm = document.getElementById('productForm');
    const pageTitleH1 = document.getElementById('pageTitle'); // Pour le titre "Ajouter" ou "Modifier"
    const formSubmitButton = document.getElementById('formSubmitButton');
    const messageArea = 'messageAreaProductForm';

    // Champs du formulaire
    const nomInput = document.getElementById('nom');
    const descriptionTextarea = document.getElementById('description');
    const prixInput = document.getElementById('prix');
    const imageUrlInput = document.getElementById('imageUrl');
    const categorieInput = document.getElementById('categorie');
    const typeElementSelect = document.getElementById('typeElement');
    const quantiteEnStockInput = document.getElementById('quantiteEnStock');
    const dureeServiceMinutesInput = document.getElementById('dureeServiceMinutes');
    const lieuServiceInput = document.getElementById('lieuService');
    const disponibleCheckbox = document.getElementById('disponible'); // Si vous ajoutez ce champ

    // Champs conditionnels (pour affichage/masquage)
    const stockFieldsDiv = document.getElementById('stockFields');
    const serviceFieldsDiv = document.getElementById('serviceFields');

    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id'); // Pour le mode édition

    function toggleConditionalFormFields() {
        const selectedType = typeElementSelect.value;
        if (stockFieldsDiv) stockFieldsDiv.classList.toggle('hidden', selectedType !== 'produit');
        if (serviceFieldsDiv) serviceFieldsDiv.classList.toggle('hidden', selectedType !== 'service');

        // Rendre quantiteEnStock requis uniquement si c'est un produit
        if (quantiteEnStockInput) quantiteEnStockInput.required = (selectedType === 'produit');
    }

    if (typeElementSelect) {
        typeElementSelect.addEventListener('change', toggleConditionalFormFields);
    }

    if (productId && isEditMode) {
        // --- MODE ÉDITION ---
        if (pageTitleH1) pageTitleH1.textContent = 'Modifier le Produit/Service';
        if (formSubmitButton) formSubmitButton.textContent = 'Enregistrer les Modifications';
        loadProductDataForEdit();
    } else {
        // --- MODE AJOUT ---
        if (pageTitleH1) pageTitleH1.textContent = 'Ajouter un Nouveau Produit/Service';
        if (formSubmitButton) formSubmitButton.textContent = 'Ajouter le Produit/Service';
        toggleConditionalFormFields(); // Appel initial pour afficher les bons champs
    }

    async function loadProductDataForEdit() {
        showMessage('Chargement des données du produit...', 'info', messageArea);
        try {
            const token = localStorage.getItem('authToken');
            // Utiliser l'endpoint /api/products/single/:id que l'admin utilise aussi, ou un dédié pour la boutique si besoin de logique différente
            const response = await fetch(`${API_BASE_URL}/products/single/${productId}`, {
                 headers: { 'Authorization': `Bearer ${token}` } // S'assurer que la boutique peut voir ses produits non approuvés
            });
            if (!response.ok) {
                const errData = await response.json().catch(() => ({}));
                throw new Error(errData.message || "Produit non trouvé ou erreur de chargement.");
            }
            const data = await response.json();

            if (data.success && data.product) {
                const p = data.product;
                // Vérifier si le produit appartient bien à la boutique connectée
                if (p.idVendeur._id !== boutiqueUser._id && p.idVendeur !== boutiqueUser._id) { // p.idVendeur peut être un objet ou un ID string
                    showMessage("Vous n'êtes pas autorisé à modifier ce produit.", 'error', messageArea);
                    if(formSubmitButton) formSubmitButton.disabled = true;
                    return;
                }

                if(nomInput) nomInput.value = p.nom || '';
                if(descriptionTextarea) descriptionTextarea.value = p.description || '';
                if(prixInput) prixInput.value = p.prix || '';
                if(imageUrlInput) imageUrlInput.value = p.imageUrl || '';
                if(categorieInput) categorieInput.value = p.categorie || '';
                if(typeElementSelect) typeElementSelect.value = p.typeElement || 'produit';
                if(quantiteEnStockInput) quantiteEnStockInput.value = p.quantiteEnStock !== undefined ? p.quantiteEnStock : '';
                if(dureeServiceMinutesInput) dureeServiceMinutesInput.value = p.dureeServiceMinutes || '';
                if(lieuServiceInput) lieuServiceInput.value = p.lieuService || '';
                if(disponibleCheckbox) disponibleCheckbox.checked = p.disponible !== undefined ? p.disponible : true;
                
                toggleConditionalFormFields(); // Mettre à jour l'affichage des champs conditionnels
                showMessage('Données du produit chargées.', 'success', messageArea);
            } else {
                throw new Error(data.message || "Impossible de récupérer les données du produit.");
            }
        } catch (error) {
            console.error("Erreur chargement produit pour édition:", error);
            showMessage(error.message, 'error', messageArea);
            if(formSubmitButton) formSubmitButton.disabled = true;
        }
    }


    if (productForm) {
        productForm.addEventListener('submit', async function(event) {
            event.preventDefault();
            const formData = new FormData(productForm);
            const productData = {};
            formData.forEach((value, key) => {
                // Conversion des nombres
                if (key === 'prix' || key === 'quantiteEnStock' || key === 'dureeServiceMinutes') {
                    productData[key] = value ? parseFloat(value) : null;
                } else if (key === 'disponible') {
                    productData[key] = disponibleCheckbox.checked;
                }
                else {
                    productData[key] = value;
                }
            });

            // Assurer que quantiteEnStock est un nombre ou null pour les services
            if (productData.typeElement === 'service') {
                productData.quantiteEnStock = null; // Ou 0, selon la logique de votre modèle/validation
            } else if (productData.typeElement === 'produit' && (productData.quantiteEnStock === null || productData.quantiteEnStock === undefined || isNaN(productData.quantiteEnStock))) {
                productData.quantiteEnStock = 0; // Valeur par défaut si non fourni pour un produit
            }


            const token = localStorage.getItem('authToken');
            const method = productId ? 'PUT' : 'POST';
            const url = productId ? `${API_BASE_URL}/products/${productId}` : `${API_BASE_URL}/products`;

            showMessage(productId ? 'Mise à jour en cours...' : 'Ajout en cours...', 'info', messageArea);
            if(formSubmitButton) {
                formSubmitButton.disabled = true;
                formSubmitButton.innerHTML = `<svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Enregistrement...`;
            }

            try {
                const response = await fetch(url, {
                    method: method,
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify(productData)
                });
                const data = await response.json();

                if (response.ok && data.success) {
                    showMessage(data.message || `Produit ${productId ? 'mis à jour' : 'ajouté'} avec succès !`, 'success', messageArea);
                    setTimeout(() => {
                        window.location.href = '/boutique/my-products.html'; // Rediriger vers la liste des produits
                    }, 1500);
                } else {
                    showMessage(data.message || `Erreur lors de ${productId ? 'la mise à jour' : 'l\'ajout'}.`, 'error', messageArea);
                }
            } catch (error) {
                console.error("Erreur soumission formulaire produit:", error);
                showMessage('Une erreur réseau est survenue.', 'error', messageArea);
            } finally {
                if(formSubmitButton) {
                    formSubmitButton.disabled = false;
                    formSubmitButton.textContent = productId ? 'Enregistrer les Modifications' : 'Ajouter le Produit/Service';
                }
            }
        });
    }
});