// public/js/boutique/myProducts.js
document.addEventListener('DOMContentLoaded', function() {
    const boutiqueUser = protectPage('boutique', 'authToken', 'userData', '/connexion.html');
    if (!boutiqueUser) return;

    renderBoutiqueSidebar('boutique_my_products');
    // renderFooter();

    const tableContainer = document.getElementById('myProductsTableContainer');
    const paginationDiv = document.getElementById('myProductsPagination');
    const statusFilterSelect = document.getElementById('productStatusFilter');
    const typeFilterSelect = document.getElementById('productTypeFilter');
    const messageArea = 'messageAreaMyProducts';

    let currentPage = 1;
    const limit = 10; // Éléments par page

    async function fetchMyProducts(page = 1) {
        tableContainer.innerHTML = '<p class="text-gray-500 p-6 text-center">Chargement...</p>';
        try {
            const token = localStorage.getItem('authToken');
            const params = new URLSearchParams({
                page: page.toString(),
                limit: limit.toString(),
                sort: 'createdAt_desc' // Trier par date de création (optionnel)
            });
            const statut = statusFilterSelect.value;
            const type = typeFilterSelect.value;

            if (statut) params.append('statutValidation', statut);
            if (type) params.append('typeElement', type);

            // L'API /api/products/my-products doit pouvoir gérer ces filtres côté backend
            const response = await fetch(`${API_BASE_URL}/products/my-products?${params.toString()}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) {
                const errData = await response.json().catch(() => ({}));
                throw new Error(errData.message || "Erreur chargement de vos produits.");
            }
            
            const data = await response.json();

            if (data.success && data.products) {
                // Supposons que l'API renvoie aussi totalProducts et totalPages si elle gère la pagination
                displayMyProducts(data.products);
                displayMyProductsPagination(data.currentPage || page, data.totalPages || Math.ceil(data.totalProducts / limit) || 1);
            } else {
                tableContainer.innerHTML = `<p class="text-gray-500 p-6 text-center">${data.message || 'Aucun produit ou service trouvé.'}</p>`;
                displayMyProductsPagination(1,1);
            }
        } catch (error) {
            console.error("Erreur fetchMyProducts:", error);
            showMessage(error.message, 'error', messageArea);
            tableContainer.innerHTML = `<p class="text-red-500 p-6 text-center">Erreur de chargement.</p>`;
        }
    }

    function displayMyProducts(products) {
        if (products.length === 0) {
            tableContainer.innerHTML = '<p class="text-gray-500 p-6 text-center">Aucun produit ou service ne correspond à vos filtres. <a href="/boutique/add-product.html" class="text-emerald-600 hover:underline">Ajoutez-en un !</a></p>';
            return;
        }
        let tableHTML = `
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Image</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nom</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Prix</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock/Durée</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut Valid.</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dispo.</th>
                        <th class="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">`;
        
        products.forEach(product => {
            const statutClass = product.statutValidation === 'approuve' ? 'bg-emerald-100 text-emerald-800' :
                                product.statutValidation === 'rejete' ? 'bg-red-100 text-red-800' :
                                'bg-yellow-100 text-yellow-800'; // en_attente
            const statutText = product.statutValidation.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
            const stockOuDuree = product.typeElement === 'produit' ? 
                `Stock: ${product.quantiteEnStock}` : 
                (product.dureeServiceMinutes ? `Durée: ${product.dureeServiceMinutes} min` : 'N/A');
            const dispoText = product.disponible ? 
                '<span class="px-2 py-0.5 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Oui</span>' :
                '<span class="px-2 py-0.5 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">Non</span>';


            tableHTML += `
                <tr id="product-row-${product._id}">
                    <td class="px-3 py-3"><img class="h-10 w-10 rounded-md object-cover" src="${product.imageUrl || 'https://via.placeholder.com/40'}" alt="${product.nom}"></td>
                    <td class="px-3 py-3 whitespace-nowrap text-sm font-medium text-gray-900">${product.nom}</td>
                    <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-700">${product.prix.toFixed(2)} FCFA</td>
                    <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-500 capitalize">${product.typeElement}</td>
                    <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-500">${stockOuDuree}</td>
                    <td class="px-3 py-3 whitespace-nowrap"><span class="status-badge ${statutClass}">${statutText}</span></td>
                    <td class="px-3 py-3 whitespace-nowrap text-sm">${dispoText}</td>
                    <td class="px-3 py-3 whitespace-nowrap text-center text-sm font-medium">
                        <a href="/boutique/edit-product.html?id=${product._id}" class="text-indigo-600 hover:text-indigo-900 mr-2" title="Modifier">
                            <svg class="inline-block h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" /></svg>
                        </a>
                        <button data-id="${product._id}" class="delete-my-product-btn text-red-600 hover:text-red-900" title="Supprimer">
                            <svg class="inline-block h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" /></svg>
                        </button>
                    </td>
                </tr>
            `;
        });
        tableHTML += `</tbody></table>`;
        tableContainer.innerHTML = tableHTML;
        addTableActionListeners();
    }

    function addTableActionListeners() {
        document.querySelectorAll('.delete-my-product-btn').forEach(button => {
            button.addEventListener('click', async function() {
                const productId = this.dataset.id;
                if (confirm('Êtes-vous sûr de vouloir supprimer cet élément ? Cette action est irréversible.')) {
                    showMessage('Suppression en cours...', 'info', messageArea);
                    try {
                        const token = localStorage.getItem('authToken');
                        const response = await fetch(`${API_BASE_URL}/products/${productId}`, {
                            method: 'DELETE',
                            headers: { 'Authorization': `Bearer ${token}` }
                        });
                        const data = await response.json();
                        if (response.ok && data.success) {
                            showMessage(data.message || 'Élément supprimé avec succès.', 'success', messageArea);
                            // Supprimer la ligne du tableau ou recharger
                            document.getElementById(`product-row-${productId}`)?.remove();
                            // fetchMyProducts(currentPage); // Optionnel: recharger toute la liste
                        } else {
                            showMessage(data.message || 'Erreur lors de la suppression.', 'error', messageArea);
                        }
                    } catch (error) {
                         showMessage('Erreur réseau lors de la suppression.', 'error', messageArea);
                    }
                }
            });
        });
    }

    // Pagination (similaire à celle des autres listes)
    function displayMyProductsPagination(currentPageNum, totalPagesNum) {
        paginationDiv.innerHTML = '';
        if (totalPagesNum <= 1) return;
        // ... (Copiez et adaptez la logique de displayPagination)
        // Les appels dans les addEventListener doivent être : fetchMyProducts(numero_page)
    }

    if (statusFilterSelect) {
        statusFilterSelect.addEventListener('change', () => { currentPage = 1; fetchMyProducts(currentPage); });
    }
    if (typeFilterSelect) {
        typeFilterSelect.addEventListener('change', () => { currentPage = 1; fetchMyProducts(currentPage); });
    }

    // Chargement initial
    fetchMyProducts(currentPage);
});