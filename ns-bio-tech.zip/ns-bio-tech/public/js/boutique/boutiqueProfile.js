// public/js/boutique/boutiqueProfile.js
document.addEventListener('DOMContentLoaded', async function() {
    const boutiqueUser = protectPage('boutique', 'authToken', 'userData', '/connexion.html');
    if (!boutiqueUser) return;

    renderBoutiqueSidebar('boutique_profile');
    // renderFooter();

    const messageArea = 'messageAreaBoutiqueProfile';

    // Éléments du DOM
    const profileForm = document.getElementById('boutiqueProfileForm');
    const nomCompletInput = document.getElementById('nomComplet'); // Gérant
    const telephoneInput = document.getElementById('telephone');   // Gérant
    const emailInput = document.getElementById('email');         // Connexion (readonly)
    const changePasswordLink = document.getElementById('changePasswordLink');
    const saveProfileButton = document.getElementById('saveProfileButton');

    // Champs spécifiques boutique
    const nomBoutiqueInput = document.getElementById('profileNomBoutique');
    const descriptionBoutiqueInput = document.getElementById('profileDescriptionBoutique');
    const logoUrlInput = document.getElementById('logoUrlBoutique');
    const horairesInput = document.getElementById('horairesOuvertureBoutique');
    const profileAvatarImg = document.getElementById('profileAvatarImg');


    // Champs paiement simulé
    const typePaiementSelect = document.getElementById('typePaiementPrincipal');
    const mobileMoneyFieldsDiv = document.getElementById('detailsMobileMoneyFields');
    const carteBancaireFieldsDiv = document.getElementById('detailsCarteBancaireFields');
    const mobileMoneyNumeroInput = document.getElementById('mobileMoneyNumero');
    const mobileMoneyOperateurInput = document.getElementById('mobileMoneyOperateur');
    const carteTypeInput = document.getElementById('carteType');
    const carteDerniersChiffresInput = document.getElementById('carteDerniersChiffres');
    const carteDateExpirationInput = document.getElementById('carteDateExpiration');
    const soldeSimuleSpan = document.getElementById('soldeSimule');

    // Injecter les icônes
    // if (ICONS_SVG) {
    //     document.getElementById('cameraIconPlaceholder')?.innerHTML = ICONS_SVG.Camera || '';
    //     document.getElementById('userIconContact')?.innerHTML = ICONS_SVG.User || '';
    //     document.getElementById('phoneIconContact')?.innerHTML = ICONS_SVG.Phone || '';
    //     document.getElementById('mailIconContact')?.innerHTML = ICONS_SVG.Mail || '';
    //     document.getElementById('saveIconProfile')?.innerHTML = ICONS_SVG.Save || ICONS_SVG.Check;
    // }


    async function loadBoutiqueProfile() {
        const token = localStorage.getItem('authToken');
        try {
            const response = await fetch(`${API_BASE_URL}/users/me`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await response.json();
            if (data.success && data.user) {
                populateProfileForm(data.user);
                updatePaymentFieldsVisibility(data.user.informationsPaiementSimulees?.typePaiementPrincipal);
            } else {
                showMessage(data.message || "Profil boutique non trouvé.", 'error', messageArea);
            }
        } catch (error) { showMessage(error.message, 'error', messageArea); }
    }

    function populateProfileForm(userData) {
        // Infos gérant (de l'objet User principal)
        if (nomCompletInput) nomCompletInput.value = userData.nomComplet || '';
        if (telephoneInput) telephoneInput.value = userData.telephone || '';
        if (emailInput) emailInput.value = userData.email || '';

        // Infos boutique (spécifiques au rôle boutique sur l'objet User)
        if (nomBoutiqueInput) nomBoutiqueInput.value = userData.nomBoutique || '';
        if (descriptionBoutiqueInput) descriptionBoutiqueInput.value = userData.descriptionBoutique || '';
        if (logoUrlInput) logoUrlInput.value = userData.logoUrlBoutique || '';
        if (horairesInput) horairesInput.value = userData.horairesOuvertureBoutique || '';
        if (profileAvatarImg && userData.logoUrlBoutique) { // Afficher le logo si URL existe
            profileAvatarImg.src = userData.logoUrlBoutique;
        } else if (profileAvatarImg) {
            profileAvatarImg.src = `https://via.placeholder.com/112/E2E8F0/1B4332?text=${(userData.nomBoutique || 'B').charAt(0)}`;
        }


        // Infos de paiement
        if (userData.informationsPaiementSimulees) {
            const paiementInfo = userData.informationsPaiementSimulees;
            if (typePaiementSelect) typePaiementSelect.value = paiementInfo.typePaiementPrincipal || 'non_configure';
            if (mobileMoneyNumeroInput) mobileMoneyNumeroInput.value = paiementInfo.detailsMobileMoney?.numero || '';
            if (mobileMoneyOperateurInput) mobileMoneyOperateurInput.value = paiementInfo.detailsMobileMoney?.operateur || '';
            if (carteTypeInput) carteTypeInput.value = paiementInfo.detailsCarteBancaire?.typeCarte || '';
            if (carteDerniersChiffresInput) carteDerniersChiffresInput.value = paiementInfo.detailsCarteBancaire?.quatreDerniersChiffres || '';
            if (carteDateExpirationInput) carteDateExpirationInput.value = paiementInfo.detailsCarteBancaire?.dateExpiration || '';
            if (soldeSimuleSpan) soldeSimuleSpan.textContent = `${(paiementInfo.soldeCompteSimule !== undefined ? paiementInfo.soldeCompteSimule : 0).toFixed(2)} FCFA`;
        } else {
             if (soldeSimuleSpan) soldeSimuleSpan.textContent = `0.00 FCFA`;
             if (typePaiementSelect) typePaiementSelect.value = 'non_configure';
        }
        updatePaymentFieldsVisibility(typePaiementSelect ? typePaiementSelect.value : 'non_configure');
    }

    function updatePaymentFieldsVisibility(selectedPaymentType) {
        if(mobileMoneyFieldsDiv) mobileMoneyFieldsDiv.classList.toggle('hidden', selectedPaymentType !== 'mobile_money');
        if(carteBancaireFieldsDiv) carteBancaireFieldsDiv.classList.toggle('hidden', selectedPaymentType !== 'carte_bancaire');
    }

    if(typePaiementSelect) {
        typePaiementSelect.addEventListener('change', function() {
            updatePaymentFieldsVisibility(this.value);
        });
    }

    async function handleProfileUpdate(event) {
        event.preventDefault();
        showMessage('Mise à jour du profil boutique...', 'info', messageArea);
        // ... (logique de désactivation bouton)

        const payload = {
            // Champs utilisateur général
            nomComplet: nomCompletInput.value,
            telephone: telephoneInput.value,
            // Champs spécifiques boutique
            nomBoutique: nomBoutiqueInput.value,
            descriptionBoutique: descriptionBoutiqueInput.value,
            logoUrlBoutique: logoUrlInput.value,
            horairesOuvertureBoutique: horairesInput.value,
            // CoordonneesBoutique (objet) à gérer si vous avez des champs pour ça

            informationsPaiementSimulees: { /* ... comme dans clientProfile.js ... */ }
        };
        // Nettoyer payload.informationsPaiementSimulees
        // ...

        const token = localStorage.getItem('authToken');
        try {
            const response = await fetch(`${API_BASE_URL}/users/me`, { // Même endpoint pour tous les users
                method: 'PUT',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`},
                body: JSON.stringify(payload)
            });
            const data = await response.json();
            if (response.ok && data.success) {
                showMessage('Profil boutique mis à jour avec succès !', 'success', messageArea);
                localStorage.setItem('userData', JSON.stringify(data.user));
                populateProfileForm(data.user);
                // renderBoutiqueSidebar('boutique_profile'); // Pour rafraîchir le titre de la page si besoin
            } else {
                showMessage(data.message || 'Erreur lors de la mise à jour.', 'error', messageArea);
            }
        } catch (error) { showMessage('Une erreur réseau est survenue.', 'error', messageArea); }
        // ... (logique réactivation bouton)
    }

    if (profileForm) profileForm.addEventListener('submit', handleProfileUpdate);
    if (changePasswordLink) {
        changePasswordLink.addEventListener('click', () => {
             window.location.href = '/client/changer-mot-de-passe.html'; // Page partagée
        });
    }
    
    // Gérer le clic sur le bouton de l'avatar (pour le proto, juste un log)
    const avatarUploadLabel = document.querySelector('label[for="avatarUpload"]');
    if (avatarUploadLabel) {
        avatarUploadLabel.addEventListener('click', () => {
            console.log("Tentative de changement d'avatar/logo (non fonctionnel pour ce prototype).");
            // document.getElementById('avatarUpload').click(); // Si on voulait ouvrir le sélecteur de fichier
        });
    }


    loadBoutiqueProfile();
});