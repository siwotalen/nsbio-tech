// public/js/boutique/boutiqueOrders.js
document.addEventListener('DOMContentLoaded', function() {
    const boutiqueUser = protectPage('boutique', 'authToken', 'userData', '/connexion.html');
    if (!boutiqueUser) return;

    renderBoutiqueSidebar('boutique_orders');
    // renderFooter();

    const tableContainer = document.getElementById('boutiqueOrdersTableContainer');
    const paginationDiv = document.getElementById('boutiqueOrdersPagination');
    const statusFilterSelect = document.getElementById('orderStatusFilter');
    const searchInput = document.getElementById('orderSearchInput');
    const messageArea = 'messageAreaBoutiqueOrders';

    let currentPage = 1;
    const limit = 10;

    const orderStatutsValidesPourMaj = ['simulation_payee', 'en_preparation', 'prete_pour_retrait', 'expediee', 'livree', 'retiree', 'annulee'];
    const statutOptionsHTML = orderStatutsValidesPourMaj.map(s => `<option value="${s}">${s.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</option>`).join('');


    async function fetchBoutiqueOrders(page = 1) {
        tableContainer.innerHTML = '<p class="text-gray-500 p-6 text-center">Chargement...</p>';
        try {
            const token = localStorage.getItem('authToken');
            const params = new URLSearchParams({
                page: page.toString(),
                limit: limit.toString(),
                sort: 'createdAt_desc'
            });
            const statut = statusFilterSelect.value;
            const searchTerm = searchInput.value.trim();

            if (statut) params.append('statutCommande', statut);
            if (searchTerm) params.append('search', searchTerm); // L'API doit gérer ce 'search'

            const response = await fetch(`${API_BASE_URL}/orders/my-orders/boutique?${params.toString()}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) {
                const errData = await response.json().catch(() => ({}));
                throw new Error(errData.message || "Erreur chargement des commandes.");
            }
            
            const data = await response.json();

            if (data.success && data.orders) {
                displayBoutiqueOrders(data.orders);
                displayBoutiqueOrdersPagination(data.currentPage || page, data.totalPages || Math.ceil(data.totalOrders / limit) || 1);
            } else {
                tableContainer.innerHTML = `<p class="text-gray-500 p-6 text-center">${data.message || 'Aucune commande trouvée.'}</p>`;
                displayBoutiqueOrdersPagination(1,1);
            }
        } catch (error) {
            console.error("Erreur fetchBoutiqueOrders:", error);
            showMessage(error.message, 'error', messageArea);
            tableContainer.innerHTML = `<p class="text-red-500 p-6 text-center">Erreur de chargement.</p>`;
        }
    }

    function getStatusBadgeClass(status) {
        switch (status) {
            case 'simulation_payee': return 'bg-blue-100 text-blue-800';
            case 'en_preparation': return 'bg-yellow-100 text-yellow-800';
            case 'prete_pour_retrait': return 'bg-indigo-100 text-indigo-800';
            case 'expediee': return 'bg-purple-100 text-purple-800';
            case 'livree': case 'retiree': return 'bg-emerald-100 text-emerald-800';
            case 'annulee': return 'bg-red-100 text-red-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    }

    function displayBoutiqueOrders(orders) {
        if (orders.length === 0) {
            tableContainer.innerHTML = '<p class="text-gray-500 p-6 text-center">Aucune commande ne correspond à vos filtres.</p>';
            return;
        }
        let tableHTML = `
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID Commande</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Client</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Produits</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                        <th class="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">`;
        
        orders.forEach(order => {
            const clientName = order.idClient ? (order.idClient.nomComplet || order.idClient.email) : 'Client inconnu';
            const statutText = order.statutCommande.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
            const produitsText = order.produits.map(p => `${p.quantite}x ${p.nomProduit}`).join(', ');

            tableHTML += `
                <tr id="order-row-${order._id}">
                    <td class="px-3 py-3 whitespace-nowrap text-xs text-blue-600 hover:underline cursor-pointer" title="Voir détails (non implémenté)">...${order._id.slice(-8)}</td>
                    <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-900">${clientName}</td>
                    <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-500">${new Date(order.createdAt).toLocaleDateString()}</td>
                    <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-900 font-semibold">${order.totalCommande.toFixed(2)} FCFA</td>
                    <td class="px-3 py-3 text-xs text-gray-500 max-w-xs truncate" title="${produitsText}">${produitsText}</td>
                    <td class="px-3 py-3 whitespace-nowrap">
                        <span class="order-status-badge px-2.5 py-0.5 text-xs font-semibold rounded-full inline-block ${getStatusBadgeClass(order.statutCommande)}">
                            ${statutText}
                        </span>
                    </td>
                    <td class="px-3 py-3 whitespace-nowrap text-center text-sm font-medium">
                        <select data-order-id="${order._id}" class="update-order-status-select form-input py-1 px-2 border-gray-300 text-xs rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500" 
                            ${order.statutCommande === 'livree' || order.statutCommande === 'retiree' || order.statutCommande === 'annulee' ? 'disabled' : ''}>
                            <option value="">Changer statut</option>
                            ${statutOptionsHTML}
                        </select>
                    </td>
                </tr>
            `;
        });
        tableHTML += `</tbody></table>`;
        tableContainer.innerHTML = tableHTML;
        addTableActionListeners();
    }

    function addTableActionListeners() {
        document.querySelectorAll('.update-order-status-select').forEach(select => {
            select.addEventListener('change', async function() {
                const orderId = this.dataset.orderId;
                const nouveauStatut = this.value;
                if (!nouveauStatut) return; // Si l'option "Changer statut" est sélectionnée

                if (confirm(`Confirmer le changement de statut de la commande #${orderId.slice(-6)} à "${nouveauStatut.replace('_',' ')}"?`)) {
                    await updateOrderStatus(orderId, nouveauStatut, this);
                } else {
                    this.value = ''; // Réinitialiser le select si annulé
                }
            });
        });
    }

    async function updateOrderStatus(orderId, nouveauStatut, selectElement) {
        showMessage('Mise à jour du statut...', 'info', messageArea);
        selectElement.disabled = true;
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/orders/${orderId}/status`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ nouveauStatut })
            });
            const data = await response.json();
            if (response.ok && data.success) {
                showMessage(data.message || 'Statut de commande mis à jour.', 'success', messageArea);
                fetchBoutiqueOrders(currentPage); // Recharger la liste pour voir le changement
            } else {
                showMessage(data.message || "Erreur lors de la mise à jour du statut.", 'error', messageArea);
                selectElement.value = ''; // Réinitialiser en cas d'erreur
            }
        } catch (error) {
            showMessage("Erreur réseau lors de la mise à jour.", 'error', messageArea);
            selectElement.value = '';
        } finally {
            selectElement.disabled = data.order.statutCommande === 'livree' || data.order.statutCommande === 'retiree' || data.order.statutCommande === 'annulee';
        }
    }
    
    function displayBoutiqueOrdersPagination(currentPageNum, totalPagesNum) {
        // ... (Copiez et adaptez la logique de displayPagination)
        // Les appels dans les addEventListener doivent être : fetchBoutiqueOrders(numero_page)
    }

    if (statusFilterSelect) {
        statusFilterSelect.addEventListener('change', () => { currentPage = 1; fetchBoutiqueOrders(currentPage); });
    }
    if (searchInput) {
        let debounceTimer;
        searchInput.addEventListener('input', function() {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                currentPage = 1;
                fetchBoutiqueOrders(currentPage);
            }, 500);
        });
    }

    fetchBoutiqueOrders(currentPage);
});