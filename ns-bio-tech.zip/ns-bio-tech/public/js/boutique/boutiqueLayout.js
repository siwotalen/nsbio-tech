// public/js/boutique/boutiqueLayout.js

// Définir les items de navigation spécifiques à la boutique
const BOUTIQUE_NAV_ITEMS = [
    { icon: 'LayoutDashboard', label: 'Tableau de bord', href: '/boutique/dashboard.html', key: 'boutique_dashboard' },
    { icon: 'PlusCircle', label: 'Ajouter Produit/Service', href: '/boutique/add-product.html', key: 'boutique_add_product' },
    { icon: 'ListOrdered', label: 'Mes Produits/Services', href: '/boutique/my-products.html', key: 'boutique_my_products' }, // Page à créer listant tous les produits pour édition/suppression
    { icon: 'ShoppingCart', label: 'Mes Commandes Reçues', href: '/boutique/orders.html', key: 'boutique_orders' },
    { icon: 'MapPin', label: 'Mes Points de Retrait', href: '/boutique/pickup-points.html', key: 'boutique_pickup' },
    { icon: 'CreditCard', label: 'Mon Abonnement', href: '/boutique/subscription.html', key: 'boutique_subscription' },
    { icon: 'User', label: 'Mon Profil Boutique', href: '/boutique/profile.html', key: 'boutique_profile' },
    { icon: 'Bell', label: 'Mes Notifications', href: '/boutique/notifications.html', key: 'boutique_notifications' }
];

// Assurez-vous que ICONS_SVG est accessible (depuis data.js ou main.js)
// S'il n'est pas global, vous devrez l'importer ou le définir ici.

function renderBoutiqueSidebar(currentPageKey) {
    const sidebarDiv = document.getElementById('boutiqueSidebar'); // Doit correspondre à l'ID dans le HTML du layout boutique
    const mobileMenuDiv = document.getElementById('boutiqueMobileMenu');
    const pageTitleH1 = document.getElementById('pageTitle'); // Élément H1 pour le titre de la page principale

    if (!sidebarDiv) {
        console.error("Élément boutiqueSidebar non trouvé.");
        return;
    }

    let sidebarLinksHtml = '';
    let pageTitle = "Espace Boutique"; // Titre par défaut

    BOUTIQUE_NAV_ITEMS.forEach(item => {
        const IconSVG = ICONS_SVG && ICONS_SVG[item.icon] ? ICONS_SVG[item.icon].replace('class="lucide', 'class="lucide h-5 w-5') : `<span class="w-5 h-5 inline-block mr-3">Icon</span>`; // Fallback
        const isActive = currentPageKey === item.key;
        if (isActive && pageTitleH1) pageTitle = item.label;

        sidebarLinksHtml += `
            <li>
                <a href="${item.href}"
                   class="flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-colors text-sm font-medium
                          ${isActive ? 'bg-emerald-50 text-emerald-700' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}">
                    ${IconSVG}
                    <span>${item.label}</span>
                </a>
            </li>
        `;
    });

    sidebarDiv.innerHTML = `
        <div class="p-4 border-b border-gray-200">
            <a href="/index.html" class="text-2xl font-bold text-emerald-600">NSBIO-TECH</a>
            <p class="text-xs text-gray-500 mt-1">Espace Boutique</p>
        </div>
        <nav class="flex-1 p-3 space-y-1">
            <ul>${sidebarLinksHtml}</ul>
        </nav>
        <div class="p-4 border-t border-gray-200">
            <button id="boutiqueSidebarLogoutButton" 
                    class="w-full flex items-center space-x-2 text-gray-600 hover:bg-red-50 hover:text-red-600 p-2 rounded-md transition-colors text-sm font-medium">
                ${ICONS_SVG && ICONS_SVG.LogOut ? ICONS_SVG.LogOut.replace('class="lucide', 'class="lucide h-5 w-5') : '🚪'}
                <span>Déconnexion</span>
            </button>
        </div>
    `;
    
    if (pageTitleH1) pageTitleH1.textContent = pageTitle;

    // Configuration du menu burger pour le layout boutique
    const boutiqueMobileBurger = document.getElementById('boutiqueMobileBurger');
    if (boutiqueMobileBurger && mobileMenuDiv) {
        mobileMenuDiv.innerHTML = `<ul class="flex flex-col p-2 space-y-1">${sidebarLinksHtml}</ul>`;
        mobileMenuDiv.querySelectorAll('a').forEach(link => {
            link.classList.add('w-full', 'text-left');
            link.addEventListener('click', () => mobileMenuDiv.classList.add('hidden'));
        });
        boutiqueMobileBurger.addEventListener('click', () => {
            mobileMenuDiv.classList.toggle('hidden');
        });
    }
}