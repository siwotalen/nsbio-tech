// public/js/boutique/boutiqueSubscription.js
document.addEventListener('DOMContentLoaded', function() {
    const boutiqueUser = protectPage('boutique', 'authToken', 'userData', '/connexion.html');
    if (!boutiqueUser) return;

    renderBoutiqueSidebar('boutique_subscription');
    // renderFooter();

    const messageArea = 'messageAreaSubscription';
    const currentAboTypeSpan = document.getElementById('currentAboType');
    const currentAboLimitSpan = document.getElementById('currentAboLimit');
    const currentPaymentInfoSpan = document.getElementById('currentPaymentInfo');
    const subscriptionOptionsContainer = document.getElementById('subscriptionOptionsContainer');

    // Définition des plans d'abonnement (pourrait aussi venir d'une API)
    const SUBSCRIPTION_PLANS = [
        {
            id: 'classic',
            nom: 'Classic',
            prixMensuel: 0, // FCFA
            limiteProduits: 3,
            description: 'Idéal pour démarrer et tester la plateforme.',
            features: [
                'Jusqu\'à 3 produits/services',
                'Fonctionnalités de base',
                'Support standard'
            ]
        },
        {
            id: 'gold',
            nom: 'Gold',
            prixMensuel: 10000, // FCFA - Correspond à COUTS_ABONNEMENT_SIMULES du backend
            limiteProduits: 100,
            description: 'Pour les boutiques en croissance avec plus de produits.',
            features: [
                'Jusqu\'à 100 produits/services',
                'Mise en avant occasionnelle',
                'Support prioritaire'
            ],
            isPopular: true
        },
        {
            id: 'platinum',
            nom: 'Platinum',
            prixMensuel: 25000, // FCFA
            limiteProduits: 500,
            description: 'La solution complète pour les boutiques établies.',
            features: [
                'Jusqu\'à 500 produits/services',
                'Mise en avant premium',
                'Statistiques avancées (à venir)',
                'Support dédié'
            ]
        }
    ];

    function displayCurrentSubscriptionInfo(user) {
        if (currentAboTypeSpan) currentAboTypeSpan.textContent = user.typeAbonnement ? user.typeAbonnement.replace(/\b\w/g, l => l.toUpperCase()) : 'N/A';
        if (currentAboLimitSpan) currentAboLimitSpan.textContent = typeof user.limiteProduits === 'number' ? user.limiteProduits.toString() : 'N/A';
        
        let paiementText = "Non configuré";
        if (user.informationsPaiementSimulees) {
            const pInfo = user.informationsPaiementSimulees;
            if (pInfo.typePaiementPrincipal && pInfo.typePaiementPrincipal !== 'non_configure') {
                paiementText = pInfo.typePaiementPrincipal.replace('_', ' ');
                if (pInfo.typePaiementPrincipal === 'mobile_money' && pInfo.detailsMobileMoney?.numero) {
                    paiementText += ` (...${pInfo.detailsMobileMoney.numero.slice(-4)})`;
                } else if (pInfo.typePaiementPrincipal === 'carte_bancaire' && pInfo.detailsCarteBancaire?.quatreDerniersChiffres) {
                    paiementText += ` (se terminant par ${pInfo.detailsCarteBancaire.quatreDerniersChiffres})`;
                }
            }
        }
        if(currentPaymentInfoSpan) currentPaymentInfoSpan.textContent = paiementText;
    }

    function displaySubscriptionOptions(currentUserSubscriptionType) {
        if (!subscriptionOptionsContainer) return;
        subscriptionOptionsContainer.innerHTML = ''; // Vider

        SUBSCRIPTION_PLANS.forEach(plan => {
            const isCurrentPlan = plan.id === currentUserSubscriptionType;
            const card = document.createElement('div');
            card.className = `subscription-card bg-white p-6 rounded-lg shadow-md border flex flex-col ${isCurrentPlan ? 'border-2 border-emerald-500 ring-2 ring-emerald-200' : 'border-gray-200'}`;
            
            let featuresHtml = '<ul class="space-y-2 text-sm text-gray-600 mb-6 flex-grow">';
            plan.features.forEach(feature => {
                featuresHtml += `
                    <li class="flex items-center">
                        <svg class="h-5 w-5 text-emerald-500 mr-2 flex-shrink-0" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z" clip-rule="evenodd" /></svg>
                        ${feature}
                    </li>`;
            });
            featuresHtml += '</ul>';

            card.innerHTML = `
                ${plan.isPopular ? '<div class="text-xs text-indigo-600 bg-indigo-100 font-semibold px-3 py-1 rounded-full self-start mb-3">Le Plus Populaire</div>' : ''}
                <h3 class="text-xl font-semibold text-emerald-700 mb-2">${plan.nom}</h3>
                <p class="price text-3xl font-bold text-gray-800 my-3">${plan.prixMensuel.toLocaleString('fr-FR')} <span class="period text-sm font-normal text-gray-500">FCFA/mois</span></p>
                <p class="text-xs text-gray-500 mb-4">${plan.description}</p>
                ${featuresHtml}
                <button data-plan-id="${plan.id}" 
                        class="change-sub-btn mt-auto w-full font-semibold py-2.5 px-4 rounded-lg transition-colors
                               ${isCurrentPlan ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-emerald-600 hover:bg-emerald-700 text-white'}"
                        ${isCurrentPlan ? 'disabled' : ''}>
                    ${isCurrentPlan ? 'Votre Plan Actuel' : `Choisir ${plan.nom}`}
                </button>
            `;
            subscriptionOptionsContainer.appendChild(card);
        });
        addSubscriptionButtonListeners();
    }
    
    function addSubscriptionButtonListeners(){
        document.querySelectorAll('.change-sub-btn').forEach(button => {
            if(button.disabled) return;
            button.addEventListener('click', async function() {
                const newPlanId = this.dataset.planId;
                const planDetails = SUBSCRIPTION_PLANS.find(p => p.id === newPlanId);
                if (!planDetails) return;

                if (!confirm(`Confirmez-vous le passage à l'abonnement "${planDetails.nom}" pour ${planDetails.prixMensuel.toLocaleString('fr-FR')} FCFA/mois ? Un paiement simulé sera effectué si nécessaire.`)) {
                    return;
                }
                
                this.disabled = true;
                this.innerHTML = `<svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Changement...`;
                showMessage('Mise à jour de l\'abonnement en cours...', 'info', messageArea);

                try {
                    const token = localStorage.getItem('authToken');
                    const response = await fetch(`${API_BASE_URL}/users/me/subscription`, {
                        method: 'PATCH',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${token}`
                        },
                        body: JSON.stringify({ newSubscriptionType: newPlanId })
                    });
                    const data = await response.json();

                    if (response.ok && data.success) {
                        showMessage(data.message || 'Abonnement mis à jour avec succès !', 'success', messageArea);
                        // Mettre à jour les données utilisateur dans localStorage
                        localStorage.setItem('userData', JSON.stringify(data.user));
                        // Recharger les infos et options pour refléter le changement
                        displayCurrentSubscriptionInfo(data.user);
                        displaySubscriptionOptions(data.user.typeAbonnement);
                    } else {
                        showMessage(data.message || "Erreur lors de la mise à jour de l'abonnement.", 'error', messageArea);
                         this.disabled = false;
                         this.textContent = `Choisir ${planDetails.nom}`;
                    }
                } catch (error) {
                    console.error("Erreur changement abonnement:", error);
                    showMessage('Une erreur réseau est survenue.', 'error', messageArea);
                    this.disabled = false;
                    this.textContent = `Choisir ${planDetails.nom}`;
                }
            });
        });
    }

    // Initialisation
    if (boutiqueUser) {
        displayCurrentSubscriptionInfo(boutiqueUser); // Utiliser les données de l'utilisateur déjà chargées
        displaySubscriptionOptions(boutiqueUser.typeAbonnement);

        // Optionnel: re-fetcher les infos utilisateur pour s'assurer qu'elles sont à jour, surtout le solde
        // async function refreshUserData() {
        //     const token = localStorage.getItem('authToken');
        //     try {
        //         const response = await fetch(`${API_BASE_URL}/users/me`, { headers: { 'Authorization': `Bearer ${token}` }});
        //         const data = await response.json();
        //         if (data.success && data.user) {
        //             localStorage.setItem('userData', JSON.stringify(data.user));
        //             displayCurrentSubscriptionInfo(data.user);
        //             displaySubscriptionOptions(data.user.typeAbonnement);
        //         }
        //     } catch(e) { console.error("Erreur refresh user data:", e); }
        // }
        // refreshUserData();
    }
});