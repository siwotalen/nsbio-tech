
const ADMIN_NAV_ITEMS = [
    { icon: 'BarChart2', label: 'Tableau de Bord', href: '/admin/dashboard.html', key: 'admin_dashboard' },
    { icon: 'ShoppingBag', label: 'Validation Produits', href: '/admin/product-validation.html', key: 'admin_validation' },
    { icon: 'Gift', label: 'Paiements Commissions', href: '/admin/commission-payouts.html', key: 'admin_commissions' },
    { icon: 'Users', label: 'Gestion Utilisateurs', href: '/admin/user-management.html', key: 'admin_users' },
    { icon: 'FileText', label: 'Registre Événements', href: '/admin/ledger-viewer.html', key: 'admin_ledger'},
    { icon: 'Package', label: 'Suivi Commandes Global', href: '/admin/orders-overview.html', key: 'admin_orders_overview' }, // À venir
    { icon: 'MessageSquare', label: 'Messages', href: '/admin/messages.html', key: 'admin_messages' }, // À venir
    { icon: 'Settings', label: 'Paramètres Plateforme', href: '/admin/settings.html', key: 'admin_settings' } // À venir
];
// SVG des icônes (vous pouvez les stocker dans data.js ou ici)
const ADMIN_ICONS_SVG = {
    BarChart2: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" x2="12" y1="20" y2="10"></line><line x1="18" x2="18" y1="20" y2="4"></line><line x1="6" x2="6" y1="20" y2="16"></line></svg>',
    Users: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M22 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>',
    ShoppingBag: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"></path><path d="M3 6h18"></path><path d="M16 10a4 4 0 0 1-8 0"></path></svg>',
    Package: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="16.5" x2="7.5" y1="9.5" y2="9.5"></line><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" x2="12" y1="22.08" y2="12"></line></svg>',
    MessageSquare: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>',
    Settings: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.38a2 2 0 0 0-.73-2.73l-.15-.09a2 2 0 0 1-1-1.74v-.51a2 2 0 0 1 1-1.72l.15-.1a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path><circle cx="12" cy="12" r="3"></circle></svg>',
    FileText: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path><path d="M14 2v4a2 2 0 0 0 2 2h4"></path><path d="M10 9H8"></path><path d="M16 13H8"></path><path d="M16 17H8"></path></svg>',
    Gift: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 12 20 22 4 22 4 12"></polyline><rect width="20" height="5" x="2" y="7"></rect><line x1="12" x2="12" y1="22" y2="7"></line><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"></path><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"></path></svg>'
};

function renderAdminSidebar(currentPageKey) {
    const sidebarDiv = document.getElementById('adminSidebar'); // Doit exister dans le HTML de la page admin
    const mobileMenuDiv = document.getElementById('adminMobileMenu'); // Doit exister
    const pageTitleH1 = document.getElementById('pageTitleAdmin'); // Doit exister pour le titre H1 principal

    if (!sidebarDiv || !mobileMenuDiv) {
        console.error("Éléments du layout admin (sidebar ou mobileMenu) non trouvés !");
        return;
    }

    let sidebarLinksHtml = '';
    let activePageLabel = "Administration"; // Titre par défaut

    ADMIN_NAV_ITEMS.forEach(item => {
        const IconSVGString = ICONS_SVG && ICONS_SVG[item.icon] ? ICONS_SVG[item.icon] : '<span class="w-5 h-5">?</span>';
        const IconSVG = IconSVGString.replace('<svg', '<svg class="lucide h-5 w-5 mr-3 flex-shrink-0"'); // Ajoute classes de base
        const isActive = currentPageKey === item.key;
        if (isActive && pageTitleH1) activePageLabel = item.label;

        sidebarLinksHtml += `
            <li>
                <a href="${item.href}"
                   class="flex items-center px-3 py-2.5 rounded-lg transition-colors text-sm font-medium
                          ${isActive ? 'bg-emerald-100 text-emerald-700 font-semibold' : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'}">
                    ${IconSVG}
                    <span>${item.label}</span>
                </a>
            </li>
        `;
    });

    sidebarDiv.innerHTML = `
        <div class="flex items-center justify-center h-16 border-b border-gray-200 px-4">
             <a href="/admin/dashboard.html" class="text-xl font-bold text-emerald-600">NSBIO Admin</a>
        </div>
        <nav class="flex-1 p-3 space-y-1" id="adminNavLinksContainer">
            <ul>${sidebarLinksHtml}</ul>
        </nav>
        <div class="p-4 border-t border-gray-200">
            <button id="adminSidebarLogoutButton" 
                    class="w-full flex items-center justify-center space-x-2 text-gray-600 hover:bg-red-50 hover:text-red-700 p-2 rounded-md transition-colors text-sm font-medium">
                ${ICONS_SVG && ICONS_SVG.LogOut ? ICONS_SVG.LogOut.replace('<svg', '<svg class="lucide h-5 w-5 mr-2 flex-shrink-0"') : '🚪'}
                <span>Déconnexion</span>
            </button>
        </div>
    `;
    
    if (pageTitleH1) pageTitleH1.textContent = activePageLabel;


    // Configuration du menu burger pour le layout admin
    const adminMobileBurger = document.getElementById('adminMobileBurger'); // Doit exister dans le HTML de la page
    if (adminMobileBurger && document.getElementById('adminNavLinksContainer')) {
        const desktopNavLinksHtmlForMobile = document.getElementById('adminNavLinksContainer').innerHTML;
        const mobileLogoutButtonHtml = `
            <div class="p-2 border-t border-gray-100 mt-2">
                <button id="adminMobileLogoutButton" class="w-full flex items-center justify-center space-x-2 text-gray-600 hover:bg-red-50 hover:text-red-600 p-2 rounded-md transition-colors text-sm font-medium">
                    ${ICONS_SVG && ICONS_SVG.LogOut ? ICONS_SVG.LogOut.replace('<svg', '<svg class="lucide h-5 w-5 mr-2 flex-shrink-0"') : '🚪'}
                    <span>Déconnexion</span>
                </button>
            </div>`;
        mobileMenuDiv.innerHTML = `<ul class="flex flex-col p-2 space-y-1">${desktopNavLinksHtmlForMobile}</ul> ${mobileLogoutButtonHtml}`;
        
        mobileMenuDiv.querySelectorAll('ul a').forEach(link => {
            link.classList.add('w-full', 'text-left', 'py-2', 'px-3', 'hover:bg-gray-100', 'rounded-md');
            link.addEventListener('click', () => mobileMenuDiv.classList.add('hidden'));
        });
        
        adminMobileBurger.addEventListener('click', () => {
            mobileMenuDiv.classList.toggle('hidden');
        });
    }
    attachAdminLayoutEventListeners(); // Attacher les listeners après avoir injecté le HTML
}

function attachAdminLayoutEventListeners() {
    const adminSidebarLogoutBtn = document.getElementById('adminSidebarLogoutButton');
    if (adminSidebarLogoutBtn) {
        adminSidebarLogoutBtn.addEventListener('click', () => handleLogout('adminAuthToken', 'adminUserData', '/admin/login.html'));
    }

    const adminMobileLogoutBtn = document.getElementById('adminMobileLogoutButton');
    if (adminMobileLogoutBtn) {
        adminMobileLogoutBtn.addEventListener('click', () => {
             const mobileMenu = document.getElementById('adminMobileMenu');
             if(mobileMenu) mobileMenu.classList.add('hidden');
             handleLogout('adminAuthToken', 'adminUserData', '/admin/login.html');
        });
    }
}