// public/js/admin/adminOrdersOverview.js
document.addEventListener('DOMContentLoaded', function() {
    const adminUser = protectPage('admin', 'adminAuthToken', 'adminUserData', '/admin/login.html');
    if (!adminUser) return;

    renderAdminSidebar('admin_orders_overview'); // Mettez à jour la clé si différente dans adminLayout.js
    // renderFooter();

    const tableContainer = document.getElementById('adminOrdersTableContainer');
    const paginationDiv = document.getElementById('adminOrdersPagination');
    const filterForm = document.getElementById('adminOrderFiltersForm');
    const searchInput = document.getElementById('adminOrderSearchInput');
    const statusFilterSelect = document.getElementById('adminOrderStatusFilter');
    const dateFromInput = document.getElementById('adminOrderDateFrom');
    const messageArea = 'messageAreaAdminOrders';

    // Modal Détails Commande
    const orderDetailModal = document.getElementById('orderDetailModalAdmin');
    const orderModalTitle = document.getElementById('orderModalTitle');
    const orderModalContent = document.getElementById('orderModalContent');
    const closeOrderDetailModalButton = document.getElementById('closeOrderDetailModalButton');
    const closeOrderDetailModalButtonBottom = document.getElementById('closeOrderDetailModalButtonBottom');


    let currentPage = 1;
    const limit = 15; // Commandes par page

    async function fetchAllOrders(page = 1) {
        tableContainer.innerHTML = '<p class="text-gray-500 p-6 text-center">Chargement des commandes...</p>';
        try {
            const token = localStorage.getItem('adminAuthToken');
            const params = new URLSearchParams({
                page: page.toString(),
                limit: limit.toString(),
                sort: 'createdAt_desc',
                populateClient: 'true', // Demander au backend de populer le client
                populateBoutique: 'true' // Demander au backend de populer la boutique
            });
            const statut = statusFilterSelect.value;
            const searchTerm = searchInput.value.trim();
            const dateFrom = dateFromInput.value;

            if (statut) params.append('statutCommande', statut);
            if (searchTerm) params.append('search', searchTerm);
            if (dateFrom) params.append('dateFrom', dateFrom);
            // Ajouter dateTo si vous avez un champ pour ça

            // Endpoint API à créer côté backend pour lister TOUTES les commandes avec filtres
            const response = await fetch(`${API_BASE_URL}/admin/orders?${params.toString()}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) {
                const errData = await response.json().catch(() => ({}));
                throw new Error(errData.message || "Erreur chargement des commandes.");
            }
            
            const data = await response.json();

            if (data.success && data.orders) {
                displayAllOrders(data.orders);
                displayOrdersPagination(data.currentPage || page, data.totalPages || Math.ceil(data.totalOrders / limit) || 1);
            } else {
                tableContainer.innerHTML = `<p class="text-gray-500 p-6 text-center">${data.message || 'Aucune commande trouvée.'}</p>`;
                displayOrdersPagination(1,1);
            }
        } catch (error) {
            console.error("Erreur fetchAllOrders:", error);
            showMessage(error.message, 'error', messageArea);
            tableContainer.innerHTML = `<p class="text-red-500 p-6 text-center">Erreur de chargement.</p>`;
        }
    }
    
    // Copier getStatusBadgeClass de boutiqueOrders.js ou le mettre dans main.js
    function getStatusBadgeClass(status) { /* ... */ }


    function displayAllOrders(orders) {
        if (orders.length === 0) {
            tableContainer.innerHTML = '<p class="text-gray-500 p-6 text-center">Aucune commande ne correspond à vos filtres.</p>';
            return;
        }
        let tableHTML = `
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID Cmd.</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Client</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Boutique</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                        <th class="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Détails</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">`;
        
        orders.forEach(order => {
            const clientName = order.idClient ? (order.idClient.nomComplet || order.idClient.email) : 'N/A';
            const boutiqueName = order.idBoutiqueAssociee ? (order.idBoutiqueAssociee.nomBoutique || order.idBoutiqueAssociee.email) : 'N/A';
            const statutText = order.statutCommande.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

            tableHTML += `
                <tr id="order-admin-row-${order._id}">
                    <td class="px-3 py-3 whitespace-nowrap text-xs text-blue-600">...${order._id.slice(-8)}</td>
                    <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-700">${clientName}</td>
                    <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-500">${boutiqueName}</td>
                    <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-500">${new Date(order.createdAt).toLocaleDateString('fr-FR')}</td>
                    <td class="px-3 py-3 whitespace-nowrap text-sm text-gray-900 font-semibold">${order.totalCommande.toFixed(2)} FCFA</td>
                    <td class="px-3 py-3 whitespace-nowrap">
                        <span class="order-status-badge px-2 py-0.5 text-xs font-semibold rounded-full inline-block ${getStatusBadgeClass(order.statutCommande)}">
                            ${statutText}
                        </span>
                    </td>
                    <td class="px-3 py-3 whitespace-nowrap text-center text-sm font-medium">
                        <button data-order-id="${order._id}" class="view-order-details-btn text-emerald-600 hover:text-emerald-800" title="Voir détails">
                            <svg class="inline-block h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M2 10a8 8 0 1116 0 8 8 0 01-16 0zm8-7a7 7 0 00-7 7h14a7 7 0 00-7-7zM8.002 11a.75.75 0 01.75-.75h2.496a.75.75 0 010 1.5H8.752a.75.75 0 01-.75-.75zm.004 3.5a.75.75 0 000 1.5h3.992a.75.75 0 000-1.5H8.006z" clip-rule="evenodd" /></svg>
                        </button>
                    </td>
                </tr>
            `;
        });
        tableHTML += `</tbody></table>`;
        tableContainer.innerHTML = tableHTML;
        addTableActionListeners();
    }

    function addTableActionListeners() {
        document.querySelectorAll('.view-order-details-btn').forEach(button => {
            button.addEventListener('click', function() {
                openOrderDetailModal(this.dataset.orderId);
            });
        });
    }

    async function openOrderDetailModal(orderId) {
        if (!orderDetailModal || !orderModalContent || !orderModalTitle) return;
        orderModalContent.innerHTML = '<p class="text-gray-500">Chargement des détails...</p>';
        orderModal.classList.remove('hidden');
        orderModalTitle.textContent = `Détails Commande #${orderId.slice(-8)}`;

        try {
            const token = localStorage.getItem('adminAuthToken');
            // Endpoint API à créer pour récupérer UNE commande par son ID (admin)
            const response = await fetch(`${API_BASE_URL}/admin/orders/${orderId}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if(!response.ok) throw new Error("Erreur chargement détail commande.");
            const data = await response.json();

            if(data.success && data.order) {
                const order = data.order;
                let detailsHtml = `
                    <p><strong>Client:</strong> ${order.idClient.nomComplet || order.idClient.email}</p>
                    <p><strong>Boutique:</strong> ${order.idBoutiqueAssociee.nomBoutique || order.idBoutiqueAssociee.email}</p>
                    <p><strong>Date:</strong> ${new Date(order.createdAt).toLocaleString('fr-FR')}</p>
                    <p><strong>Statut:</strong> ${order.statutCommande.replace('_',' ')}</p>
                    <p><strong>Total:</strong> ${order.totalCommande.toFixed(2)} FCFA</p>
                    ${order.codePromoUtilise ? `<p><strong>Code Promo:</strong> ${order.codePromoUtilise} (-${order.reductionAppliquee.toFixed(2)} FCFA)</p>` : ''}
                    <h4 class="font-semibold mt-3 mb-1">Produits:</h4>
                    <ul class="list-disc list-inside text-xs">`;
                order.produits.forEach(p => {
                    detailsHtml += `<li>${p.quantite} x ${p.nomProduit} (${p.prixUnitaire.toFixed(2)} FCFA)</li>`;
                });
                detailsHtml += `</ul>`;
                if(order.pointDeRetraitChoisi?.nom) {
                    detailsHtml += `<h4 class="font-semibold mt-3 mb-1">Point de Retrait:</h4><p class="text-xs">${order.pointDeRetraitChoisi.nom} - ${order.pointDeRetraitChoisi.adresse}</p>`;
                }
                if(order.adresseLivraisonChoisie?.rue) {
                    detailsHtml += `<h4 class="font-semibold mt-3 mb-1">Adresse Livraison:</h4><p class="text-xs">${order.adresseLivraisonChoisie.rue}, ${order.adresseLivraisonChoisie.ville || ''} ${order.adresseLivraisonChoisie.codePostal || ''}</p>`;
                }
                orderModalContent.innerHTML = detailsHtml;
            } else {
                 orderModalContent.innerHTML = `<p class="text-red-500">${data.message || "Détails non trouvés."}</p>`;
            }
        } catch(e) {
            orderModalContent.innerHTML = `<p class="text-red-500">Erreur réseau.</p>`;
        }
    }
    
    function closeOrderDetail() {
        if(orderDetailModal) orderDetailModal.classList.add('hidden');
    }
    if(closeOrderDetailModalButton) closeOrderDetailModalButton.addEventListener('click', closeOrderDetail);
    if(closeOrderDetailModalButtonBottom) closeOrderDetailModalButtonBottom.addEventListener('click', closeOrderDetail);
    if(orderDetailModal) orderDetailModal.addEventListener('click', (e) => { if(e.target === orderDetailModal) closeOrderDetail(); });


    function displayOrdersPagination(currentPageNum, totalPagesNum) {
        // ... (Copiez et adaptez la logique de displayPagination)
        // Les appels dans les addEventListener doivent être : fetchAllOrders(numero_page)
    }

    if (filterForm) {
        filterForm.addEventListener('submit', (e) => {
            e.preventDefault();
            currentPage = 1;
            fetchAllOrders(currentPage);
        });
    }

    fetchAllOrders(currentPage);
});