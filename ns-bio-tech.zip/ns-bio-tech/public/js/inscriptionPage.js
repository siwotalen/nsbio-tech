// public/js/inscriptionPage.js
document.addEventListener('DOMContentLoaded', function() {
    renderNavbar('inscription'); // Clé pour la navbar
    renderFooter();

    const signupForm = document.getElementById('signupForm');
    const roleSelect = document.getElementById('signupRole');

    // Divs conditionnelles
    const clientFieldsDiv = document.getElementById('clientFields');
    const boutiqueFieldsDiv = document.getElementById('boutiqueFields');
    const parrainFieldsDiv = document.getElementById('parrainFields');
    
    // Inputs dont l'attribut 'required' peut changer
    const nomBoutiqueInput = document.getElementById('nomBoutique');

    // Déclarer toggleConditionalFields DANS le scope où elle est utilisée ou globalement (dans main.js si besoin ailleurs)
    // Pour l'instant, on la met ici car elle est spécifique à cette page.
    window.toggleConditionalFields = function() { // Rendre globale si appelée par handleSignup depuis auth.js
        if(!roleSelect || !clientFieldsDiv || !boutiqueFieldsDiv || !parrainFieldsDiv) return; // Vérifier que les éléments existent

        const selectedRole = roleSelect.value;

        clientFieldsDiv.classList.add('hidden');
        boutiqueFieldsDiv.classList.add('hidden');
        parrainFieldsDiv.classList.add('hidden');

        if(nomBoutiqueInput) nomBoutiqueInput.required = false;

        if (selectedRole === 'client') {
            clientFieldsDiv.classList.remove('hidden');
        } else if (selectedRole === 'boutique') {
            boutiqueFieldsDiv.classList.remove('hidden');
            if(nomBoutiqueInput) nomBoutiqueInput.required = true;
        } else if (selectedRole === 'parrain') {
            parrainFieldsDiv.classList.remove('hidden');
        }
    }

    if (roleSelect) {
        roleSelect.addEventListener('change', window.toggleConditionalFields);
        window.toggleConditionalFields(); // Appel initial pour configurer les champs selon le rôle par défaut
    }

    if (signupForm) {
        signupForm.addEventListener('submit', handleSignup); // handleSignup est dans auth.js
    }
});