async function handleLogout(tokenKey = 'authToken', userKey = 'userData', redirectPath = '/connexion.html') {
    const token = localStorage.getItem(tokenKey);

    if (token) {
        try {
            // Appel à l'API de déconnexion du backend
            // Votre backend /api/auth/signout efface déjà le cookie HTTP-Only si vous en utilisez.
            // Pour une API purement JWT, cet appel est une bonne pratique pour invalider le token côté serveur si vous avez une telle logique (ex: blacklistage de token),
            // mais pour un prototype simple, ce n'est pas toujours critique si le token a une courte durée de vie.
            // Notre backend actuel ne fait que clearCookie, ce qui est pertinent si le token était aussi dans un cookie.
            const response = await fetch(`${API_BASE_URL}/auth/signout`, {
                method: 'POST', // Assurez-vous que votre route /api/auth/signout accepte POST
                headers: {
                    'Authorization': `Bearer ${token}`
                    // Pas besoin de Content-Type si le body est vide
                }
            });
            if (!response.ok) {
                // Logguer l'erreur mais continuer la déconnexion locale
                const errorData = await response.json().catch(() => ({}));
                console.warn('L\'appel API de déconnexion a échoué ou retourné une erreur:', errorData.message || response.statusText);
            } else {
                console.log("Déconnexion API réussie.");
            }
        } catch (error) {
            console.error('Erreur réseau lors de l\'appel API de déconnexion:', error);
        }
    }

    // Toujours effectuer la déconnexion locale (suppression des items du localStorage)
    localStorage.removeItem(tokenKey);
    localStorage.removeItem(userKey);
    console.log(`Token (${tokenKey}) et données utilisateur (${userKey}) supprimés du localStorage.`);

    // Rediriger vers la page de connexion ou la page d'accueil
    window.location.href = redirectPath;
}
