// public/js/parrainDashboard.js

document.addEventListener('DOMContentLoaded', function() {
    const parrainUser = protectPage('parrain', 'authToken', 'userData', '/connexion.html');
    if (!parrainUser) return;

    const parrainDashboardTitle = document.getElementById('parrainDashboardTitle');
    const parrainWelcomeMessage = document.getElementById('parrainWelcomeMessage');
    const referralCodeDisplay = document.getElementById('referralCodeDisplay');
    const copyFeedback = document.getElementById('copyFeedback');

    // Stats
    const totalCommissionsGagneesSpan = document.getElementById('totalCommissionsGagnees');
    const commissionsEnAttentePaiementSpan = document.getElementById('commissionsEnAttentePaiement');
    const commissionsPayeesSpan = document.getElementById('commissionsPayees');
    const totalFilleulsSpan = document.getElementById('totalFilleuls');

    const referredUsersListDiv = document.getElementById('parrainReferredUsersList');
    const messageArea = document.getElementById('messageAreaDashboardParrain');

    /**
     * Charge les informations du dashboard du parrain.
     */
    async function loadParrainDashboardData() {
        if (parrainDashboardTitle && parrainUser.nomComplet) {
            parrainDashboardTitle.textContent = `Tableau de Bord Parrain : ${parrainUser.nomComplet}`;
        }
        if (parrainWelcomeMessage && parrainUser.email) {
            parrainWelcomeMessage.textContent = `Bienvenue, ${parrainUser.nomComplet || parrainUser.email} ! Gérez votre activité de parrainage.`;
        }

        // Afficher le code de parrainage
        if (referralCodeDisplay && parrainUser.codePromoPersonnel) {
            referralCodeDisplay.textContent = parrainUser.codePromoPersonnel;
            referralCodeDisplay.addEventListener('click', () => copyToClipboard(parrainUser.codePromoPersonnel));
        } else if (referralCodeDisplay) {
            referralCodeDisplay.textContent = "Génération..."; // Ou message d'erreur si absent
            referralCodeDisplay.style.cursor = 'default';
        }

        fetchMyCommissionsSummary();
        fetchMyReferredUsersSummary();
    }

    /**
     * Récupère et affiche un résumé des commissions.
     */
    async function fetchMyCommissionsSummary() {
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/users/me/commissions?limit=10000`, { // Récupérer toutes pour le résumé
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) throw new Error('Erreur chargement commissions');
            const data = await response.json();

            if (data.success && data.commissions) {
                let totalValidees = 0;
                let totalDemandees = 0;
                let totalPayees = 0;

                data.commissions.forEach(comm => {
                    if (comm.statut === 'validee') {
                        totalValidees += comm.montantCommission;
                    } else if (comm.statut === 'demandee_en_paiement') {
                        totalDemandees += comm.montantCommission;
                    } else if (comm.statut === 'payee') {
                        totalPayees += comm.montantCommission;
                    }
                });

                if(totalCommissionsGagneesSpan) totalCommissionsGagneesSpan.textContent = totalValidees.toFixed(2);
                if(commissionsEnAttentePaiementSpan) commissionsEnAttentePaiementSpan.textContent = totalDemandees.toFixed(2);
                if(commissionsPayeesSpan) commissionsPayeesSpan.textContent = totalPayees.toFixed(2);

            } else {
                console.warn("Pas de données de commission ou erreur:", data.message);
            }
        } catch (error) {
            console.error("Erreur fetchMyCommissionsSummary:", error);
            if(totalCommissionsGagneesSpan) totalCommissionsGagneesSpan.textContent = "Erreur";
        }
    }

    /**
     * Récupère et affiche un résumé des filleuls.
     */
    async function fetchMyReferredUsersSummary() {
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/users/me/referred-users?limit=5`, { // Afficher les 5 derniers
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) throw new Error('Erreur chargement filleuls');
            const data = await response.json();

            if (data.success) {
                if(totalFilleulsSpan) totalFilleulsSpan.textContent = data.totalFilleuls || 0;
                displayReferredUsers(data.filleuls || []);
            } else {
                 if(totalFilleulsSpan) totalFilleulsSpan.textContent = "0";
                 referredUsersListDiv.innerHTML = '<p>Aucun filleul trouvé pour le moment.</p>';
            }
        } catch (error) {
            console.error("Erreur fetchMyReferredUsersSummary:", error);
            if(totalFilleulsSpan) totalFilleulsSpan.textContent = "Erreur";
            referredUsersListDiv.innerHTML = '<p>Erreur lors du chargement des filleuls.</p>';
        }
    }
    
    /**
     * Affiche une liste de filleuls.
     * @param {Array} filleuls - Le tableau de filleuls.
     */
    function displayReferredUsers(filleuls) {
        if (filleuls.length === 0) {
            referredUsersListDiv.innerHTML = '<p>Vous n\'avez pas encore de filleuls.</p>';
            return;
        }

        let tableHtml = `
            <table>
                <thead>
                    <tr>
                        <th>Nom du Filleul</th>
                        <th>Email</th>
                        <th>Date d'Inscription</th>
                    </tr>
                </thead>
                <tbody>
        `;
        filleuls.forEach(filleul => {
            tableHtml += `
                <tr>
                    <td>${filleul.nomComplet || 'N/A'}</td>
                    <td>${filleul.email}</td>
                    <td>${new Date(filleul.createdAt).toLocaleDateString()}</td>
                </tr>
            `;
        });
        tableHtml += `</tbody></table>`;
        referredUsersListDiv.innerHTML = tableHtml;
    }


    /**
     * Copie le texte dans le presse-papier.
     * @param {string} text - Le texte à copier.
     */
    function copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(function() {
            copyFeedback.textContent = "Code copié !";
            copyFeedback.style.display = 'block';
            setTimeout(() => { copyFeedback.style.display = 'none'; copyFeedback.textContent = ''; }, 2000);
        }, function(err) {
            copyFeedback.textContent = "Erreur de copie.";
            copyFeedback.style.color = 'var(--error-color)';
            copyFeedback.style.display = 'block';
            console.error('Erreur de copie: ', err);
        });
    }

    // Charger les données au démarrage
    loadParrainDashboardData();
});