// public/js/connexionPage.js
document.addEventListener('DOMContentLoaded', function() {
    renderNavbar('connexion'); // Clé pour la navbar
    renderFooter(); // Décommentez si vous avez un <div id="footer-placeholder"></div>

    const loginForm = document.getElementById('mainLoginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleMainLogin); // handleMainLogin est dans auth.js
    }

    // Redirection si déjà connecté
    const user = getAuthenticatedUser();
    if (user && !window.location.pathname.includes('/admin/')) {
        const messageAreaId = loginForm ? loginForm.dataset.messageAreaId || 'loginMessageArea' : 'loginMessageArea';
        showMessage('Vous êtes déjà connecté. Redirection...', 'info', messageAreaId);
        setTimeout(() => {
            switch (user.role) {
                case 'client': window.location.href = '/catalogue.html'; break;
                case 'boutique': window.location.href = '/boutique/dashboard.html'; break;
                case 'parrain': window.location.href = '/parrain/dashboard.html'; break;
                default: window.location.href = '/index.html';
            }
        }, 1500);
    }
});