// public/js/parrain/parrainNotifications.js
document.addEventListener('DOMContentLoaded', function() {
    const parrainUser = protectPage('parrain', 'authToken', 'userData', '/connexion.html');
    if (!parrainUser) return;

    renderParrainSidebar('parrain_notifications'); // <<--- APPEL SPÉCIFIQUE AU LAYOUT PARRAIN

    const notificationsListContainer = document.getElementById('notificationsListContainer');
    const paginationDiv = document.getElementById('notificationsPagination');
    const filterSelect = document.getElementById('notificationFilter');
    const markAllReadBtn = document.getElementById('markAllReadButton');
    const totalNotificationsSpan = document.getElementById('totalNotificationsDisplay');
    const unreadNotificationsSpan = document.getElementById('unreadNotificationsDisplay');
    const messageArea = 'messageAreaParrainNotifications'; // ID spécifique pour les messages de cette page

    let currentPage = 1;
    const limit = 10; 

    async function fetchUserNotifications(page = 1, filter = '') { // Renommé pour plus de généricité si copié
        notificationsListContainer.innerHTML = '<p class="text-gray-500 py-4 text-center">Chargement...</p>';
        if(markAllReadBtn) markAllReadBtn.disabled = true;
        try {
            const token = localStorage.getItem('authToken'); // Utiliser le token du parrain
            const params = new URLSearchParams({
                page: page.toString(),
                limit: limit.toString(),
                sort: 'createdAt_desc'
            });
            if (filter) params.append('filter', filter);

            const response = await fetch(`${API_BASE_URL}/users/me/notifications?${params.toString()}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) throw new Error('Erreur lors du chargement des notifications.');
            
            const data = await response.json();

            if (data.success && data.notifications) {
                displayNotifications(data.notifications);
                displayNotificationsPagination(data.currentPage, data.totalPages); // Utiliser le nom de fonction correct
                if(totalNotificationsSpan) totalNotificationsSpan.textContent = data.totalNotifications || 0;
                if(unreadNotificationsSpan) unreadNotificationsSpan.textContent = data.unreadCount || 0;
                if(markAllReadBtn) markAllReadBtn.disabled = data.unreadCount === 0;
                updateNotificationCounterInNav(); 
            } else {
                notificationsListContainer.innerHTML = `<p class="text-gray-500 py-4 text-center">${data.message || 'Aucune notification trouvée.'}</p>`;
                displayNotificationsPagination(1,1);
            }
        } catch (error) {
            console.error("Erreur fetchUserNotifications:", error);
            showMessage(error.message, 'error', messageArea);
            notificationsListContainer.innerHTML = `<p class="text-red-500 py-4 text-center">Erreur de chargement.</p>`;
        }
    }

    function displayNotifications(notifications) {
        if (notifications.length === 0) {
            notificationsListContainer.innerHTML = '<p class="text-gray-500 py-4 text-center">Aucune notification à afficher.</p>';
            return;
        }
        notificationsListContainer.innerHTML = ''; 
        const ul = document.createElement('ul');
        ul.className = 'divide-y divide-gray-200';
        
        notifications.forEach(notif => {
            const li = document.createElement('li');
            li.className = `notification-item p-4 hover:bg-gray-50 transition-colors ${!notif.estLue ? 'bg-emerald-50 border-l-4 border-emerald-500' : 'bg-white'}`;
            li.dataset.notificationId = notif._id;

            const iconHtml = ICONS_SVG && ICONS_SVG[notif.typeNotification.startsWith('COMMISSION') ? 'DollarSign' : 'Bell'] 
                           ? ICONS_SVG[notif.typeNotification.startsWith('COMMISSION') ? 'DollarSign' : 'Bell'].replace('class="lucide', `class="lucide h-6 w-6 mr-3 flex-shrink-0 ${!notif.estLue ? 'text-emerald-600' : 'text-gray-400'}`) 
                           : (notif.typeNotification.startsWith('COMMISSION') ? '💰' : '🔔');


            li.innerHTML = `
                <a href="/parrain/notification-detail.html?id=${notif._id}" class="block group"> {/* Lien vers page détail parrain */}
                    <div class="flex items-start space-x-3">
                        ${iconHtml}
                        <div class="flex-1 min-w-0">
                            <div class="flex justify-between items-center">
                                <p class="text-sm font-semibold text-gray-800 group-hover:text-emerald-600 truncate ${!notif.estLue ? 'font-bold' : ''}">
                                    ${notif.titre || 'Notification NSBIO-TECH'}
                                </p>
                                <p class="text-xs text-gray-400 whitespace-nowrap">${new Date(notif.createdAt).toLocaleString('fr-FR')}</p>
                            </div>
                            <p class="text-sm text-gray-600 mt-1 line-clamp-2">${notif.message}</p>
                        </div>
                        ${!notif.estLue ? `
                            <button data-id="${notif._id}" class="mark-as-read-btn ml-2 p-1 text-xs text-emerald-600 hover:text-emerald-800 font-medium" title="Marquer comme lue">
                                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                            </button>
                        ` : ''}
                    </div>
                </a>
            `;
            li.querySelector('a').addEventListener('click', async function(e) {
                if (!notif.estLue) {
                    // Ne pas empêcher la navigation, mais marquer comme lue en arrière-plan
                    markNotificationRead(notif._id, null, false); // null pour l'élément, false pour ne pas recharger la liste
                }
            });
             const markReadBtn = li.querySelector('.mark-as-read-btn');
            if (markReadBtn) {
                markReadBtn.addEventListener('click', async (e) => {
                    e.stopPropagation(); 
                    e.preventDefault();
                    await markNotificationRead(notif._id, li, true); // true pour recharger/mettre à jour UI
                });
            }
            ul.appendChild(li);
        });
        notificationsListContainer.appendChild(ul);
    }

    async function markNotificationRead(notificationId, listItemElement, refreshList = true) {
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/users/me/notifications/${notificationId}/read`, {
                method: 'PATCH',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await response.json();
            if (response.ok && data.success) {
                if (listItemElement) { 
                    listItemElement.classList.remove('bg-emerald-50', 'border-l-4', 'border-emerald-500');
                    listItemElement.classList.add('bg-white');
                    const titleP = listItemElement.querySelector('p.font-semibold');
                    if (titleP) titleP.classList.remove('font-bold');
                    const markReadBtn = listItemElement.querySelector('.mark-as-read-btn');
                    if(markReadBtn) markReadBtn.remove();
                }
                if (refreshList) { // Ne recharger que si explicitement demandé (ex: clic sur le bouton coche)
                    fetchUserNotifications(currentPage, filterSelect.value);
                } else {
                    updateNotificationCounterInNav(); // Juste mettre à jour le compteur si on navigue
                }
            } else {
                showMessage(data.message || "Erreur pour marquer comme lue.", 'error', messageArea);
            }
        } catch (error) {
            showMessage("Erreur réseau pour marquer comme lue.", 'error', messageArea);
        }
    }
    
    async function markAllAsRead() {
        if (!confirm("Êtes-vous sûr de vouloir marquer toutes les notifications comme lues ?")) return;
        markAllReadBtn.disabled = true;
        markAllReadBtn.textContent = "Traitement...";
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/users/me/notifications/read-all`, {
                method: 'PATCH',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await response.json();
            if (response.ok && data.success) {
                showMessage(data.message, 'success', messageArea);
                fetchUserNotifications(1, ''); 
                if(filterSelect) filterSelect.value = '';
            } else {
                showMessage(data.message || "Erreur pour marquer toutes comme lues.", 'error', messageArea);
            }
        } catch (error) {
            showMessage("Erreur réseau pour marquer toutes comme lues.", 'error', messageArea);
        } finally {
            if(markAllReadBtn){
                markAllReadBtn.disabled = false;
                markAllReadBtn.textContent = "Tout Marquer comme Lu";
            }
        }
    }

    function displayNotificationsPagination(currentPageNum, totalPagesNum) {
        paginationDiv.innerHTML = '';
        if (totalPagesNum <= 1) return;
        // ... (Copiez la fonction de pagination de parrainCommissionsDetail.js)
        // Assurez-vous que les appels dans les addEventListener sont :
        // fetchUserNotifications(numero_page, filterSelect.value)
        // ...
    }
    
    if(filterSelect) {
        filterSelect.addEventListener('change', function() {
            currentPage = 1;
            fetchUserNotifications(currentPage, this.value);
        });
    }
    if(markAllReadBtn) {
        markAllReadBtn.addEventListener('click', markAllAsRead);
    }

    fetchUserNotifications(currentPage, filterSelect ? filterSelect.value : '');
});