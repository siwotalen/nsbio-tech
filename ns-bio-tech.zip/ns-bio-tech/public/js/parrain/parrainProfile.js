// public/js/parrain/parrainProfile.js
document.addEventListener('DOMContentLoaded', async function() {
    const parrainUser = protectPage('parrain', 'authToken', 'userData', '/connexion.html');
    if (!parrainUser) return;

    renderParrainSidebar('parrain_profile');
    // renderFooter();

    const messageArea = 'messageAreaParrainProfile';

    // Éléments du DOM
    const profileForm = document.getElementById('parrainProfileForm');
    const nomCompletInput = document.getElementById('nomComplet');
    const telephoneInput = document.getElementById('telephone');
    const emailInput = document.getElementById('email');
    const profileAvatarImg = document.getElementById('profileAvatarImg'); // Optionnel pour parrain
    const changePasswordLink = document.getElementById('changePasswordLink');
    const saveProfileButton = document.getElementById('saveProfileButton');

    // Champs spécifiques parrain
    const codePromoPersonnelDisplay = document.getElementById('profileCodePromoPersonnel');

    // Champs paiement simulé (pour recevoir les commissions)
    const typePaiementSelect = document.getElementById('typePaiementPrincipal');
    const mobileMoneyFieldsDiv = document.getElementById('detailsMobileMoneyFields');
    const carteBancaireFieldsDiv = document.getElementById('detailsCarteBancaireFields'); // Pourrait être "Virement Bancaire"
    const mobileMoneyNumeroInput = document.getElementById('mobileMoneyNumero');
    const mobileMoneyOperateurInput = document.getElementById('mobileMoneyOperateur');
    const ibanInput = document.getElementById('iban'); // Changé pour IBAN
    const nomBanqueInput = document.getElementById('nomBanque'); // Changé pour Nom Banque
    const soldeCommissionsSimuleSpan = document.getElementById('soldeCommissionsSimule');


    // // Injecter les icônes
    // if (ICONS_SVG) {
    //     // document.getElementById('userIconProfile')?.innerHTML = ICONS_SVG.User || '';
    //     document.getElementById('phoneIconProfile')?.innerHTML = ICONS_SVG.Phone || '';
    //     document.getElementById('mailIconProfile')?.innerHTML = ICONS_SVG.Mail || '';
    //     document.getElementById('saveIconPlaceholder')?.innerHTML = ICONS_SVG.Save || ICONS_SVG.Check;
    // }

    async function loadParrainProfile() {
        const token = localStorage.getItem('authToken');
        try {
            const response = await fetch(`${API_BASE_URL}/users/me`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await response.json();
            if (data.success && data.user) {
                populateProfileForm(data.user);
                updatePaymentFieldsVisibility(data.user.informationsPaiementSimulees?.typePaiementPrincipal);
                // Calculer et afficher le solde des commissions validées
                fetchAndDisplayCommissionBalance(token);
            } else {
                showMessage(data.message || "Profil parrain non trouvé.", 'error', messageArea);
            }
        } catch (error) { showMessage(error.message, 'error', messageArea); }
    }

    async function fetchAndDisplayCommissionBalance(token) {
        try {
            const commissionsResponse = await fetch(`${API_BASE_URL}/users/me/commissions?statut=validee`, { // Uniquement les validées
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const commissionsData = await commissionsResponse.json();
            if (commissionsResponse.ok && commissionsData.success) {
                const totalValidees = commissionsData.commissions.reduce((sum, comm) => sum + comm.montantCommission, 0);
                if (soldeCommissionsSimuleSpan) soldeCommissionsSimuleSpan.textContent = `${totalValidees.toFixed(2)} FCFA (Validées)`;
            } else {
                if (soldeCommissionsSimuleSpan) soldeCommissionsSimuleSpan.textContent = 'Erreur chargement solde';
            }
        } catch(e) {
            console.error("Erreur solde commissions:", e);
            if (soldeCommissionsSimuleSpan) soldeCommissionsSimuleSpan.textContent = 'Erreur réseau';
        }
    }


    function populateProfileForm(userData) {
        if (nomCompletInput) nomCompletInput.value = userData.nomComplet || '';
        if (telephoneInput) telephoneInput.value = userData.telephone || '';
        if (emailInput) emailInput.value = userData.email || ''; // Readonly
        if (codePromoPersonnelDisplay) codePromoPersonnelDisplay.value = userData.codePromoPersonnel || 'N/A (sera généré)';

        if (userData.informationsPaiementSimulees) {
            const paiementInfo = userData.informationsPaiementSimulees;
            if (typePaiementSelect) typePaiementSelect.value = paiementInfo.typePaiementPrincipal || 'non_configure';
            if (mobileMoneyNumeroInput) mobileMoneyNumeroInput.value = paiementInfo.detailsMobileMoney?.numero || '';
            if (mobileMoneyOperateurInput) mobileMoneyOperateurInput.value = paiementInfo.detailsMobileMoney?.operateur || '';
            // Pour le parrain, on utilise IBAN et Nom Banque au lieu de détails carte
            if (ibanInput) ibanInput.value = paiementInfo.detailsCarteBancaire?.iban || paiementInfo.detailsVirement?.iban || ''; // Supporte ancien et nouveau nom
            if (nomBanqueInput) nomBanqueInput.value = paiementInfo.detailsCarteBancaire?.nomBanque || paiementInfo.detailsVirement?.nomBanque || '';
        } else {
             if (typePaiementSelect) typePaiementSelect.value = 'non_configure';
        }
        updatePaymentFieldsVisibility(typePaiementSelect ? typePaiementSelect.value : 'non_configure');
    }

    function updatePaymentFieldsVisibility(selectedPaymentType) {
        if(mobileMoneyFieldsDiv) mobileMoneyFieldsDiv.classList.toggle('hidden', selectedPaymentType !== 'mobile_money');
        // Pour le parrain, "carte_bancaire" pourrait signifier "virement bancaire"
        if(carteBancaireFieldsDiv) carteBancaireFieldsDiv.classList.toggle('hidden', selectedPaymentType !== 'carte_bancaire');
    }

    if(typePaiementSelect) {
        typePaiementSelect.addEventListener('change', function() {
            updatePaymentFieldsVisibility(this.value);
        });
    }

    async function handleProfileUpdate(event) {
        event.preventDefault();
        showMessage('Mise à jour du profil...', 'info', messageArea);
        // ... (logique de désactivation bouton)

        const payload = {
            nomComplet: nomCompletInput.value,
            telephone: telephoneInput.value,
            informationsPaiementSimulees: {
                typePaiementPrincipal: typePaiementSelect.value,
                detailsMobileMoney: typePaiementSelect.value === 'mobile_money' ? {
                    numero: mobileMoneyNumeroInput.value, operateur: mobileMoneyOperateurInput.value
                } : undefined,
                // Pour le parrain, on sauvegarde les infos de virement sous `detailsCarteBancaire`
                // ou vous pourriez créer un champ `detailsVirement` dans le modèle User.
                // Ici, on réutilise `detailsCarteBancaire` mais avec des champs IBAN/NomBanque.
                detailsCarteBancaire: typePaiementSelect.value === 'carte_bancaire' ? { // Renommer en 'virement_bancaire' dans l'enum serait mieux
                    iban: ibanInput.value, // Champ à ajouter potentiellement à detailsCarteBancaire ou créer detailsVirement
                    nomBanque: nomBanqueInput.value // Champ à ajouter
                } : undefined,
            }
        };
        // Nettoyer payload.informationsPaiementSimulees si des sous-objets sont vides
        // ...

        const token = localStorage.getItem('authToken');
        try {
            const response = await fetch(`${API_BASE_URL}/users/me`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`},
                body: JSON.stringify(payload)
            });
            const data = await response.json();
            if (response.ok && data.success) {
                showMessage('Profil parrain mis à jour avec succès !', 'success', messageArea);
                localStorage.setItem('userData', JSON.stringify(data.user));
                populateProfileForm(data.user);
            } else {
                showMessage(data.message || 'Erreur lors de la mise à jour.', 'error', messageArea);
            }
        } catch (error) { showMessage('Une erreur réseau est survenue.', 'error', messageArea); }
        // ... (logique réactivation bouton)
    }

    if (profileForm) profileForm.addEventListener('submit', handleProfileUpdate);
    if (changePasswordLink) {
        changePasswordLink.addEventListener('click', () => {
             window.location.href = '/client/changer-mot-de-passe.html'; // Peut être une page partagée
        });
    }

    loadParrainProfile();
});