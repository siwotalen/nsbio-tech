// public/js/parrain/parrainCommissionsDetail.js
document.addEventListener('DOMContentLoaded', function() {
    const parrainUser = protectPage('parrain', 'authToken', 'userData', '/connexion.html');
    if (!parrainUser) return;
        renderParrainSidebar('parrain_commissions'); // <<--- APPEL IMPORTANT

    const commissionsTableContainer = document.getElementById('commissionsTableContainer');
    const commissionPaginationDiv = document.getElementById('commissionPagination');
    const statusFilter = document.getElementById('commissionStatusFilter');
    const totalValideesDisplay = document.getElementById('totalValideesDisplay');
    const messageArea = 'messageAreaCommissions';

    let currentPage = 1;
    const limit = 10; // Nombre de commissions par page

    async function fetchParrainCommissions(page = 1, statut = '') {
        commissionsTableContainer.innerHTML = '<p class="text-gray-500 py-4">Chargement des commissions...</p>';
        try {
            const token = localStorage.getItem('authToken');
            const params = new URLSearchParams({
                page: page.toString(),
                limit: limit.toString(),
            });
            if (statut) {
                params.append('statut', statut); // Supposer que l'API peut filtrer par statut
            }

            // Utiliser l'endpoint qui récupère les commissions du parrain connecté
            const response = await fetch(`${API_BASE_URL}/users/me/commissions?${params.toString()}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) throw new Error('Erreur lors du chargement des commissions.');
            
            const data = await response.json();

            if (data.success && data.commissions) {
                displayCommissions(data.commissions);
                displayPagination(data.currentPage, data.totalPages);
                if (totalValideesDisplay && data.totalGainsValidesSimules !== undefined) {
                     totalValideesDisplay.textContent = `${parseFloat(data.totalGainsValidesSimules).toFixed(2)} FCFA`;
                } else if (totalValideesDisplay) { // Fallback si non retourné par API
                    const valideesSum = data.commissions.filter(c => c.statut === 'validee').reduce((sum, c) => sum + c.montantCommission, 0);
                    totalValideesDisplay.textContent = `${valideesSum.toFixed(2)} FCFA`;
                }
            } else {
                commissionsTableContainer.innerHTML = `<p class="text-gray-500 py-4">${data.message || 'Aucune commission trouvée.'}</p>`;
                displayPagination(1, 1); // Afficher une pagination vide
            }
        } catch (error) {
            console.error("Erreur fetchParrainCommissions:", error);
            showMessage(error.message, 'error', messageArea);
            commissionsTableContainer.innerHTML = `<p class="text-red-500 py-4">Erreur de chargement des commissions.</p>`;
        }
    }

    function displayCommissions(commissions) {
        if (commissions.length === 0) {
            commissionsTableContainer.innerHTML = '<p class="text-gray-500 py-4 text-center">Aucune commission ne correspond à vos filtres.</p>';
            return;
        }
        let tableHTML = `
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date Création</th>
                        <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Origine (Client)</th>
                        <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Montant Comm.</th>
                        <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                        <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Commande Associée</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">`;
        
        commissions.forEach(comm => {
            const clientInfo = comm.idClientReffere ? (comm.idClientReffere.nomComplet || comm.idClientReffere.email || 'N/A') : 'N/A';
            const orderId = comm.idOrderAssocie || (comm.detailsCommandeSimulee ? 'Détails en notif' : 'N/A');
            const statutText = comm.statut.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
            tableHTML += `
                <tr>
                    <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-500">${new Date(comm.createdAt).toLocaleDateString()}</td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-900">${clientInfo}</td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm text-emerald-600 font-semibold">${comm.montantCommission.toFixed(2)} FCFA</td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm">
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                            ${comm.statut === 'validee' ? 'bg-green-100 text-green-800' : 
                              comm.statut === 'demandee_en_paiement' ? 'bg-yellow-100 text-yellow-800' :
                              comm.statut === 'payee' ? 'bg-blue-100 text-blue-800' :
                              comm.statut === 'annulee' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'}">
                            ${statutText}
                        </span>
                    </td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-500">${typeof orderId === 'object' && orderId !== null ? 'N/A (détails)' : orderId }</td>
                </tr>
            `;
        });
        tableHTML += `</tbody></table>`;
        commissionsTableContainer.innerHTML = tableHTML;
    }

    function displayPagination(currentPageNum, totalPagesNum) {
        commissionPaginationDiv.innerHTML = '';
        if (totalPagesNum <= 1) return;

        // Bouton Précédent
        const prevButton = document.createElement('button');
        prevButton.innerHTML = '« Préc.';
        prevButton.className = 'px-4 py-2 mx-1 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed';
        prevButton.disabled = currentPageNum === 1;
        prevButton.addEventListener('click', () => fetchParrainCommissions(currentPageNum - 1, statusFilter.value));
        commissionPaginationDiv.appendChild(prevButton);

        // Afficher quelques numéros de page (simplifié)
        let startPage = Math.max(1, currentPageNum - 2);
        let endPage = Math.min(totalPagesNum, currentPageNum + 2);

        if (currentPageNum <=3) endPage = Math.min(totalPagesNum, 5);
        if (currentPageNum >= totalPagesNum - 2) startPage = Math.max(1, totalPagesNum - 4);


        if (startPage > 1) {
            const firstButton = document.createElement('button');
            firstButton.textContent = '1';
            firstButton.className = 'px-4 py-2 mx-1 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50';
            firstButton.addEventListener('click', () => fetchParrainCommissions(1, statusFilter.value));
            commissionPaginationDiv.appendChild(firstButton);
            if (startPage > 2) {
                const ellipsis = document.createElement('span');
                ellipsis.textContent = '...';
                ellipsis.className = 'px-4 py-2 mx-1 text-sm text-gray-500';
                commissionPaginationDiv.appendChild(ellipsis);
            }
        }

        for (let i = startPage; i <= endPage; i++) {
            const pageButton = document.createElement('button');
            pageButton.textContent = i;
            pageButton.className = `px-4 py-2 mx-1 text-sm font-medium border border-gray-300 rounded-md hover:bg-gray-50 ${i === currentPageNum ? 'bg-emerald-600 text-white border-emerald-600' : 'text-gray-700 bg-white'}`;
            if (i === currentPageNum) pageButton.disabled = true;
            pageButton.addEventListener('click', () => fetchParrainCommissions(i, statusFilter.value));
            commissionPaginationDiv.appendChild(pageButton);
        }

        if (endPage < totalPagesNum) {
            if (endPage < totalPagesNum - 1) {
                const ellipsis = document.createElement('span');
                ellipsis.textContent = '...';
                ellipsis.className = 'px-4 py-2 mx-1 text-sm text-gray-500';
                commissionPaginationDiv.appendChild(ellipsis);
            }
            const lastButton = document.createElement('button');
            lastButton.textContent = totalPagesNum;
            lastButton.className = 'px-4 py-2 mx-1 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50';
            lastButton.addEventListener('click', () => fetchParrainCommissions(totalPagesNum, statusFilter.value));
            commissionPaginationDiv.appendChild(lastButton);
        }

        // Bouton Suivant
        const nextButton = document.createElement('button');
        nextButton.innerHTML = 'Suiv. »';
        nextButton.className = 'px-4 py-2 mx-1 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed';
        nextButton.disabled = currentPageNum === totalPagesNum;
        nextButton.addEventListener('click', () => fetchParrainCommissions(currentPageNum + 1, statusFilter.value));
        commissionPaginationDiv.appendChild(nextButton);
    }
    
    if(statusFilter){
        statusFilter.addEventListener('change', function(){
            currentPage = 1; // Reset to first page on filter change
            fetchParrainCommissions(currentPage, this.value);
        });
    }

    // Chargement initial
    fetchParrainCommissions(currentPage, statusFilter ? statusFilter.value : '');
});