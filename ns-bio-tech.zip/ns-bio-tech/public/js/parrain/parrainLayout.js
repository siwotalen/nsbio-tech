// public/js/parrain/parrainLayout.js

// Assurez-vous que ICONS_SVG est accessible (chargé avant, ex: via data.js)

const PARRAIN_NAV_ITEMS = [
    { icon: 'LayoutDashboard', label: 'Tableau de bord', href: '/parrain/dashboard.html', key: 'parrain_dashboard' },
    { icon: 'DollarSign', label: 'Mes Commissions', href: '/parrain/commissions-detail.html', key: 'parrain_commissions' },
    { icon: 'Users', label: 'Mes Filleuls', href: '/parrain/filleuls-detail.html', key: 'parrain_filleuls' },
    { icon: 'Send', label: 'Demander un Paiement', href: '/parrain/demander-paiement.html', key: 'parrain_payout_request' },
    { icon: 'User', label: 'Mon Profil Parrain', href: '/parrain/profile.html', key: 'parrain_profile' },
    { icon: 'Bell', label: 'Notifications', href: '/parrain/notifications.html', key: 'parrain_notifications' }
];

function renderParrainSidebar(currentPageKey) {
    const sidebarDiv = document.getElementById('parrainSidebar');
    const mobileMenuDiv = document.getElementById('parrainMobileMenu');
    const pageTitleH1 = document.getElementById('pageTitle');

    if (!sidebarDiv) {
        console.error("Élément parrainSidebar non trouvé.");
        return;
    }

    let sidebarLinksHtml = '';
    let pageTitle = "Espace Parrain";

    PARRAIN_NAV_ITEMS.forEach(item => {
        const IconSVGString = ICONS_SVG && ICONS_SVG[item.icon] ? ICONS_SVG[item.icon] : '<span class="w-5 h-5">?</span>'; // Fallback simple
        const IconSVG = IconSVGString.replace('<svg', '<svg class="lucide h-5 w-5 mr-3 flex-shrink-0"'); // Ajoute classe et marge
        const isActive = currentPageKey === item.key;
        if (isActive && pageTitleH1) pageTitle = item.label;

        sidebarLinksHtml += `
            <li>
                <a href="${item.href}"
                   class="flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-colors text-sm font-medium
                          ${isActive ? 'bg-emerald-50 text-emerald-700' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}">
                    ${IconSVG}
                    <span>${item.label}</span>
                </a>
            </li>
        `;
    });

    sidebarDiv.innerHTML = `
        <div class="p-4 border-b border-gray-200">
             <a href="/index.html" class="text-2xl font-bold text-emerald-600">NSBIO-TECH</a>
             <p class="text-xs text-gray-500 mt-1">Espace Parrain</p>
        </div>
        <nav class="flex-1 p-3 space-y-1" id="parrainNavLinksContainer">
            <ul>${sidebarLinksHtml}</ul>
        </nav>
        <div class="p-4 border-t border-gray-200">
            <button id="parrainSidebarLogoutButton" 
                    class="w-full flex items-center justify-center space-x-2 text-gray-600 hover:bg-red-50 hover:text-red-600 p-2 rounded-md transition-colors text-sm font-medium">
                ${ICONS_SVG && ICONS_SVG.LogOut ? ICONS_SVG.LogOut.replace('<svg', '<svg class="lucide h-5 w-5 mr-2 flex-shrink-0"') : '🚪'}
                <span>Déconnexion</span>
            </button>
        </div>
    `;
    
    if (pageTitleH1) pageTitleH1.textContent = pageTitle;

    const parrainMobileBurger = document.getElementById('parrainMobileBurger');
    if (parrainMobileBurger && mobileMenuDiv && document.getElementById('parrainNavLinksContainer')) {
        const desktopNavLinksHtmlForMobile = document.getElementById('parrainNavLinksContainer').innerHTML;
        const mobileLogoutButtonHtml = `
            <div class="p-2 border-t border-gray-100 mt-2">
                <button id="parrainMobileLogoutButton" class="w-full flex items-center justify-center space-x-2 text-gray-600 hover:bg-red-50 hover:text-red-600 p-2 rounded-md transition-colors text-sm font-medium">
                    ${ICONS_SVG && ICONS_SVG.LogOut ? ICONS_SVG.LogOut.replace('<svg', '<svg class="lucide h-5 w-5 mr-2 flex-shrink-0"') : '🚪'}
                    <span>Déconnexion</span>
                </button>
            </div>`;
        mobileMenuDiv.innerHTML = `<ul class="flex flex-col p-2 space-y-1">${desktopNavLinksHtmlForMobile}</ul> ${mobileLogoutButtonHtml}`;
        
        mobileMenuDiv.querySelectorAll('ul a').forEach(link => {
            link.classList.add('w-full', 'text-left', 'py-2', 'px-3', 'hover:bg-gray-100', 'rounded-md');
            link.addEventListener('click', () => mobileMenuDiv.classList.add('hidden'));
        });
        
        parrainMobileBurger.addEventListener('click', () => {
            mobileMenuDiv.classList.toggle('hidden');
        });
    }
    attachParrainLayoutEventListeners(); // Important
}

function attachParrainLayoutEventListeners() {
    const parrainSidebarLogoutBtn = document.getElementById('parrainSidebarLogoutButton');
    if (parrainSidebarLogoutBtn) {
        parrainSidebarLogoutBtn.addEventListener('click', () => handleLogout('authToken', 'userData', '/connexion.html'));
    }

    const parrainMobileLogoutBtn = document.getElementById('parrainMobileLogoutButton');
    if (parrainMobileLogoutBtn) {
        parrainMobileLogoutBtn.addEventListener('click', () => {
             const mobileMenu = document.getElementById('parrainMobileMenu');
             if(mobileMenu) mobileMenu.classList.add('hidden');
             handleLogout('authToken', 'userData', '/connexion.html');
        });
    }
}