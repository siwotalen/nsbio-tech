// public/js/parrain/parrainDashboard.js
document.addEventListener('DOMContentLoaded', async function() {
    const parrainUser = protectPage('parrain', 'authToken', 'userData', '/connexion.html');
    if (!parrainUser) return;

    renderParrainSidebar('parrain_dashboard');
    // renderFooter();

    const welcomeMessage = document.getElementById('parrainWelcomeMessage');
    const referralCodeDisplay = document.getElementById('referralCodeDisplay');
    const copyCodeBtn = document.getElementById('copyCodeBtn');
    const copyFeedbackDiv = document.getElementById('copyFeedback');

    const statTotalFilleuls = document.getElementById('totalFilleuls'); // Pour le compteur à côté du titre
    const statCommissionsValideesSpan = document.getElementById('statCommissionsValidees');
    const statCommissionsDemandeesSpan = document.getElementById('statCommissionsDemandees');
    const statCommissionsPayeesSpan = document.getElementById('statCommissionsPayees');
    
    const referredUsersListMiniDiv = document.getElementById('parrainReferredUsersListMini'); // Pour l'aperçu
    const messageArea = 'messageAreaDashboardParrain';


    if (welcomeMessage && parrainUser.nomComplet) {
        welcomeMessage.textContent = `Bienvenue, ${parrainUser.nomComplet} !`;
    } else if (welcomeMessage && parrainUser.email) {
        welcomeMessage.textContent = `Bienvenue, Parrain (${parrainUser.email}) !`;
    }

    if (referralCodeDisplay && parrainUser.codePromoPersonnel) {
        referralCodeDisplay.textContent = parrainUser.codePromoPersonnel;
        if(copyCodeBtn) copyCodeBtn.classList.remove('hidden');
        if(copyCodeBtn) copyCodeBtn.onclick = () => copyToClipboard(parrainUser.codePromoPersonnel);
        referralCodeDisplay.onclick = () => copyToClipboard(parrainUser.codePromoPersonnel); // Copier au clic sur le code aussi
    } else if (referralCodeDisplay) {
        referralCodeDisplay.textContent = "Génération...";
        referralCodeDisplay.style.cursor = 'default';
    }

    async function loadDashboardData() {
        const token = localStorage.getItem('authToken');
        if (!token) return;

        // --- Récupérer les commissions pour les statistiques ---
        try {
            const commissionsResponse = await fetch(`${API_BASE_URL}/users/me/commissions?limit=10000`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const commissionsData = await commissionsResponse.json();

            if (commissionsResponse.ok && commissionsData.success && commissionsData.commissions) {
                let totalValidees = 0, totalDemandees = 0, totalPayees = 0;
                commissionsData.commissions.forEach(comm => {
                    if (comm.statut === 'validee') totalValidees += comm.montantCommission;
                    if (comm.statut === 'demandee_en_paiement') totalDemandees += comm.montantCommission;
                    if (comm.statut === 'payee') totalPayees += comm.montantCommission;
                });
                if(statCommissionsValidees) statCommissionsValidees.textContent = `${totalValidees.toFixed(2)} FCFA`;
                if(statCommissionsDemandees) statCommissionsDemandees.textContent = `${totalDemandees.toFixed(2)} FCFA`;
                if(statCommissionsPayees) statCommissionsPayees.textContent = `${totalPayees.toFixed(2)} FCFA`;
            } else {
                console.warn("Pas de données de commission ou erreur:", commissionsData.message);
                 if(statCommissionsValidees) statCommissionsValidees.textContent = "0.00 FCFA";
                 if(statCommissionsDemandees) statCommissionsDemandees.textContent = "0.00 FCFA";
                 if(statCommissionsPayees) statCommissionsPayees.textContent = "0.00 FCFA";
            }
        } catch (error) {
            console.error("Erreur API commissions (dashboard):", error);
            showMessage('Erreur chargement des stats commissions.', 'error', messageArea);
        }

        // --- Récupérer les filleuls pour les statistiques et l'aperçu ---
        try {
            const filleulsResponse = await fetch(`${API_BASE_URL}/users/me/referred-users?limit=5&sort=createdAt_desc`, { // Les 5 plus récents
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const filleulsData = await filleulsResponse.json();

            if (filleulsResponse.ok && filleulsData.success) {
                if(statTotalFilleuls) statTotalFilleuls.textContent = filleulsData.totalFilleuls || 0;
                displayRecentReferredUsers(filleulsData.filleuls || []);
            } else {
                if(statTotalFilleuls) statTotalFilleuls.textContent = "0";
                if(referredUsersListMiniDiv) referredUsersListMiniDiv.innerHTML = `<p class="text-xs text-gray-500">${filleulsData.message || 'Aucun filleul trouvé.'}</p>`;
            }
        } catch (error) {
            console.error("Erreur API filleuls (dashboard):", error);
            showMessage('Erreur chargement des stats filleuls.', 'error', messageArea);
        }
    }

    function displayRecentReferredUsers(filleuls) {
        if (!referredUsersListMiniDiv) return;
        if (filleuls.length === 0) {
            referredUsersListMiniDiv.innerHTML = '<p class="text-sm text-gray-500 text-center py-4">Vous n\'avez pas encore de filleuls.</p>';
            return;
        }
        let listHTML = '<ul class="space-y-2">';
        filleuls.forEach(filleul => {
            listHTML += `
                <li class="flex justify-between items-center p-2 bg-gray-50 rounded-md">
                    <span class="text-sm text-gray-700">${filleul.nomComplet || filleul.email}</span>
                    <span class="text-xs text-gray-500">Inscrit le: ${new Date(filleul.createdAt).toLocaleDateString()}</span>
                </li>
            `;
        });
        listHTML += `</ul>`;
        referredUsersListMiniDiv.innerHTML = listHTML;
    }

    function copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            if(copyFeedbackDiv) copyFeedbackDiv.textContent = "Code copié !";
            setTimeout(() => { if(copyFeedbackDiv) copyFeedbackDiv.textContent = ''; }, 2000);
        }).catch(err => {
            if(copyFeedbackDiv) {
                copyFeedbackDiv.textContent = "Erreur de copie.";
                copyFeedbackDiv.style.color = 'var(--error-color)';
            }
            console.error('Erreur de copie: ', err);
        });
    }

    loadDashboardData();
});