// public/js/boutiqueDashboard.js

document.addEventListener('DOMContentLoaded', function() {
    // Protéger la page et récupérer les données de l'utilisateur boutique
    const boutiqueUser = protectPage('boutique', 'authToken', 'userData', '/connexion.html');
    if (!boutiqueUser) return; // Si protectPage redirige, arrêter l'exécution

    const boutiqueDashboardTitle = document.getElementById('boutiqueDashboardTitle');
    const boutiqueWelcomeMessage = document.getElementById('boutiqueWelcomeMessage');
    const boutiqueProductListDiv = document.getElementById('boutiqueProductList');
    const messageArea = document.getElementById('messageAreaDashboard');

    // Infos abonnement
    const aboTypeSpan = document.getElementById('aboType');
    const aboLimiteSpan = document.getElementById('aboLimite');
    const aboActifsSpan = document.getElementById('aboActifs');


    /**
     * Récupère et affiche les produits/services de la boutique.
     */
    async function fetchBoutiqueProducts() {
        boutiqueProductListDiv.innerHTML = '<p>Chargement de vos produits...</p>';
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/products/my-products`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({ message: 'Erreur serveur' }));
                throw new Error(errorData.message || `Erreur HTTP ${response.status}`);
            }
            const data = await response.json();

            if (data.success && data.products) {
                displayBoutiqueProducts(data.products);
                if(aboActifsSpan) aboActifsSpan.textContent = data.products.length; // Mettre à jour le nombre de produits actifs
            } else {
                showMessage(data.message || 'Impossible de charger vos produits.', 'error', 'messageAreaDashboard');
                boutiqueProductListDiv.innerHTML = '<p>Aucun produit ou service trouvé.</p>';
                 if(aboActifsSpan) aboActifsSpan.textContent = '0';
            }
        } catch (error) {
            console.error('Erreur de récupération des produits boutique:', error);
            showMessage(`Erreur: ${error.message}`, 'error', 'messageAreaDashboard');
            boutiqueProductListDiv.innerHTML = '<p>Une erreur est survenue lors du chargement de vos produits.</p>';
        }
    }

    /**
     * Affiche les produits de la boutique dans un tableau.
     * @param {Array} products - Le tableau de produits.
     */
    function displayBoutiqueProducts(products) {
        if (products.length === 0) {
            boutiqueProductListDiv.innerHTML = '<p>Vous n\'avez pas encore ajouté de produits ou services. <a href="/boutique/add-product.html">Ajoutez-en un maintenant !</a></p>';
            return;
        }

        let tableHtml = `
            <table>
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Nom</th>
                        <th>Prix</th>
                        <th>Type</th>
                        <th>Stock/Durée</th>
                        <th>Statut Validation</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
        `;

        products.forEach(product => {
            const statutClass = `status-${product.statutValidation.toLowerCase()}`;
            const statutText = product.statutValidation.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
            const stockOuDuree = product.typeElement === 'produit' ? 
                `Stock: ${product.quantiteEnStock}` : 
                (product.dureeServiceMinutes ? `Durée: ${product.dureeServiceMinutes} min` : 'N/A');

            tableHtml += `
                <tr>
                    <td><img src="${product.imageUrl || 'https://via.placeholder.com/40'}" alt="${product.nom}"></td>
                    <td>${product.nom}</td>
                    <td>${product.prix.toFixed(2)} FCFA</td>
                    <td>${product.typeElement.replace(/\b\w/g, l => l.toUpperCase())}</td>
                    <td>${stockOuDuree}</td>
                    <td><span class="${statutClass}">${statutText}</span></td>
                    <td class="actions">
                        <a href="/boutique/edit-product.html?id=${product._id}" class="btn btn-sm btn-info">Modifier</a>
                        <button data-product-id="${product._id}" class="btn btn-sm btn-danger delete-product-btn">Suppr.</button>
                    </td>
                </tr>
            `;
        });

        tableHtml += `</tbody></table>`;
        boutiqueProductListDiv.innerHTML = tableHtml;

        // Ajouter les écouteurs pour les boutons de suppression
        addDeleteEventListeners();
    }

    /**
     * Ajoute les écouteurs d'événements pour les boutons de suppression de produit.
     */
    function addDeleteEventListeners() {
        document.querySelectorAll('.delete-product-btn').forEach(button => {
            button.addEventListener('click', async function() {
                const productId = this.dataset.productId;
                if (confirm('Êtes-vous sûr de vouloir supprimer ce produit/service ?')) {
                    await deleteProduct(productId);
                }
            });
        });
    }

    /**
     * Supprime un produit/service via l'API.
     * @param {string} productId - L'ID du produit à supprimer.
     */
    async function deleteProduct(productId) {
        try {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/products/${productId}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await response.json();

            if (response.ok && data.success) {
                showMessage(data.message || 'Produit supprimé avec succès.', 'success', 'messageAreaDashboard');
                fetchBoutiqueProducts(); // Recharger la liste
            } else {
                showMessage(data.message || 'Erreur lors de la suppression.', 'error', 'messageAreaDashboard');
            }
        } catch (error) {
            console.error('Erreur de suppression du produit:', error);
            showMessage('Une erreur réseau est survenue.', 'error', 'messageAreaDashboard');
        }
    }
    
    /**
     * Charge les informations initiales du dashboard.
     */
    function loadDashboardData() {
        if (boutiqueDashboardTitle && boutiqueUser.nomBoutique) {
            boutiqueDashboardTitle.textContent = `Tableau de Bord : ${boutiqueUser.nomBoutique}`;
        }
        if (boutiqueWelcomeMessage && boutiqueUser.email) {
            boutiqueWelcomeMessage.textContent = `Bienvenue, ${boutiqueUser.nomComplet || boutiqueUser.email} ! Gérez votre boutique ici.`;
        }
        if(aboTypeSpan) aboTypeSpan.textContent = boutiqueUser.typeAbonnement ? boutiqueUser.typeAbonnement.replace(/\b\w/g, l => l.toUpperCase()) : 'N/A';
        if(aboLimiteSpan) aboLimiteSpan.textContent = typeof boutiqueUser.limiteProduits === 'number' ? boutiqueUser.limiteProduits : 'N/A';

        fetchBoutiqueProducts();
    }

    // Charger les données au démarrage
    loadDashboardData();
});