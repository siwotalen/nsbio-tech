const API_BASE_URL = 'http://localhost:8000/api'; // Port a adapter

function showMessage(message, type, areaId = 'messageAreaGlobal') {
    const messageArea = document.getElementById(areaId);
    if (messageArea) {
        messageArea.textContent = message;
        messageArea.className = 'message-area-style my-4 p-3 rounded-md text-sm';
        messageArea.classList.remove('hidden', 'bg-emerald-50', 'text-emerald-700', 'bg-red-50', 'text-red-700', 'bg-blue-50', 'text-blue-700');
        if (type === 'success') messageArea.classList.add('bg-emerald-50', 'text-emerald-700');
        else if (type === 'error') messageArea.classList.add('bg-red-50', 'text-red-700');
        else if (type === 'info') messageArea.classList.add('bg-blue-50', 'text-blue-700');
        messageArea.classList.remove('hidden');
        setTimeout(() => { if(messageArea) messageArea.classList.add('hidden'); }, 5000);
    } else {
        console.warn(`Message area with ID '${areaId}' not found for message: ${message}`);
    }
}

function getAuthenticatedUser(tokenKey = 'authToken', userKey = 'userData') {
    const token = localStorage.getItem(tokenKey);
    const userDataString = localStorage.getItem(userKey);
    if (token && userDataString) {
        try { return JSON.parse(userDataString); }
        catch (e) { localStorage.removeItem(tokenKey); localStorage.removeItem(userKey); return null; }
    }
    return null;
}

function protectPage(requiredRole = null, tokenKey = 'authToken', userKey = 'userData', loginPath = '/connexion.html') {
    const user = getAuthenticatedUser(tokenKey, userKey);
    if (!user) { window.location.href = loginPath; return null; }
    if (requiredRole && user.role !== requiredRole) {
        alert(`Accès non autorisé. Rôle '${requiredRole}' requis.`);
        window.location.href = loginPath; return null;
    }
    return user;
}

async function handleLogout(tokenKey = 'authToken', userKey = 'userData', redirectPath = '/connexion.html') {
    const token = localStorage.getItem(tokenKey);
    if (token) {
        try {
            const response = await fetch(`${API_BASE_URL}/auth/signout`, {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                console.warn('API de déconnexion a échoué:', errorData.message || response.statusText);
            } else {
                console.log("Déconnexion API réussie.");
            }
        } catch (error) {
            console.error('Erreur réseau API déconnexion:', error);
        }
    }
    localStorage.removeItem(tokenKey);
    localStorage.removeItem(userKey);
    console.log(`Token (${tokenKey}) et données (${userKey}) supprimés.`);
    window.location.href = redirectPath;
}

function setupBurgerMenu(navbarElementId = 'navbar-placeholder') { // Permet de cibler une navbar spécifique
    const navbarContainer = document.getElementById(navbarElementId) || document.querySelector('.navbar'); // Fallback
    if (!navbarContainer) return;

    const burgerButton = navbarContainer.querySelector('#navbarBurger');
    const mobileMenu = navbarContainer.querySelector('#mobileMenu');
    const navLinksDesktopContainer = navbarContainer.querySelector('.nav-links-desktop');

    if (burgerButton && mobileMenu && navLinksDesktopContainer) {
        const mobileNavLinksContent = navLinksDesktopContainer.innerHTML;
        if (mobileMenu.querySelector('ul')) {
            mobileMenu.querySelector('ul').innerHTML = mobileNavLinksContent;
        } else {
            mobileMenu.innerHTML = `<ul class="flex flex-col items-start w-full p-4 space-y-1">${mobileNavLinksContent}</ul>`;
        }
        
        mobileMenu.querySelectorAll('a, button').forEach(el => {
            el.classList.add('w-full', 'text-left', 'py-2', 'px-3', 'hover:bg-gray-100', 'rounded-md');
            if(el.tagName === 'BUTTON') el.classList.add('text-center', 'justify-center');
            el.addEventListener('click', () => mobileMenu.classList.add('hidden'));
        });

        burgerButton.addEventListener('click', function() {
            mobileMenu.classList.toggle('hidden');
        });
    }
}

async function updateNotificationCounterInNav() {
    const user = getAuthenticatedUser(); // Pour client, boutique, parrain
    const adminUser = getAuthenticatedUser('adminAuthToken', 'adminUserData');
    const currentUser = user || adminUser;
    const tokenKey = user ? 'authToken' : (adminUser ? 'adminAuthToken' : null);

    const counterElement = document.getElementById('navNotificationCounter');
    const dropdownElement = document.getElementById('navNotificationDropdown'); // Pour le contenu du dropdown

    if (!currentUser || !tokenKey) {
        if (counterElement) counterElement.classList.add('hidden');
        if (dropdownElement) dropdownElement.innerHTML = '<p class="text-xs text-gray-500 p-3 text-center">Connectez-vous pour voir vos notifications.</p>';
        return;
    }
    const token = localStorage.getItem(tokenKey);

    try {
        // Récupérer le compte et les 5 dernières notifications non lues
        const response = await fetch(`${API_BASE_URL}/users/me/notifications?limit=5&filter=non_lues&sort=createdAt_desc`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        if (!response.ok) {
            if (counterElement) counterElement.classList.add('hidden');
            if (dropdownElement) dropdownElement.innerHTML = '<p class="text-xs text-red-500 p-3 text-center">Erreur chargement notifications.</p>';
            return;
        }
        const data = await response.json();

        if (data.success) {
            // Mettre à jour le compteur
            if (counterElement) {
                if (data.unreadCount > 0) {
                    counterElement.textContent = data.unreadCount > 9 ? '9+' : data.unreadCount.toString();
                    counterElement.classList.remove('hidden');
                } else {
                    counterElement.classList.add('hidden');
                }
            }

            // Remplir le dropdown
            if (dropdownElement) {
                if (data.notifications && data.notifications.length > 0) {
                    let dropdownHtml = '';
                    data.notifications.forEach(notif => {
                        dropdownHtml += `
                            <a href="/client/notification-detail.html?id=${notif._id}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 ${!notif.estLue ? 'font-semibold' : ''}" data-notification-id="${notif._id}">
                                <p class="font-medium truncate">${notif.titre || 'Notification'}</p>
                                <p class="text-xs text-gray-500 truncate">${notif.message}</p>
                            </a>
                        `;
                    });
                    dropdownHtml += '<a href="/client/notifications.html" class="block w-full text-center px-4 py-2 text-xs font-medium text-emerald-600 bg-gray-50 hover:bg-gray-100">Voir toutes les notifications</a>';
                    dropdownElement.innerHTML = dropdownHtml;

                    // Ajouter des écouteurs pour marquer comme lue au clic (optionnel)
                    dropdownElement.querySelectorAll('a[data-notification-id]').forEach(link => {
                        link.addEventListener('click', async function(e) {
                            // e.preventDefault(); // Empêcher la navigation si on veut juste marquer comme lu
                            const notifId = this.dataset.notificationId;
                            // Marquer comme lue (ne pas attendre la réponse pour la redirection)
                            fetch(`${API_BASE_URL}/users/me/notifications/${notifId}/read`, {
                                method: 'PATCH',
                                headers: { 'Authorization': `Bearer ${token}` }
                            }).then(() => updateNotificationCounterInNav()); // Mettre à jour le compteur après
                            // window.location.href = this.href; // Continuer la navigation
                        });
                    });

                } else {
                    dropdownElement.innerHTML = '<p class="text-xs text-gray-500 p-3 text-center">Aucune nouvelle notification.</p><a href="/client/notifications.html" class="block w-full text-center px-4 py-2 text-xs font-medium text-emerald-600 bg-gray-50 hover:bg-gray-100">Voir toutes les notifications</a>';
                }
            }
        }
    } catch (error) {
        console.error("Erreur récupération notifications pour navbar:", error);
        if (counterElement) counterElement.classList.add('hidden');
        if (dropdownElement) dropdownElement.innerHTML = '<p class="text-xs text-red-500 p-3 text-center">Erreur chargement.</p>';
    }
}

function updateCartCounterInNav() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const cartItemCount = cart.reduce((total, item) => total + item.quantity, 0);
    const cartCounterElement = document.getElementById('cart-counter');
    if (cartCounterElement) {
        cartCounterElement.textContent = cartItemCount > 0 ? cartItemCount.toString() : '';
        cartCounterElement.style.display = cartItemCount > 0 ? 'inline-flex' : 'none'; // inline-flex pour aligner avec le texte
    }
}
function renderNavbar(currentPageKey) {
    const user = getAuthenticatedUser();
    const adminUser = getAuthenticatedUser('adminAuthToken', 'adminUserData');
    let navHtml = '';

    navHtml += `
        <nav class="navbar bg-white py-3 px-4 shadow-sm fixed top-0 left-0 right-0 z-50 h-[var(--navbar-height)]">
            <div class="max-w-7xl mx-auto flex justify-between items-center h-full">
                <div class="flex items-center">
                    <a href="/index.html" class="text-2xl font-bold text-emerald-600">NSBIO-TECH</a>
                </div>
                <div class="nav-links-desktop hidden md:flex items-center space-x-4"> 
    `;
    // Liens Visiteur Non Connecté
    if (!user && !adminUser) {
        navHtml += `<a href="/index.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium ${currentPageKey === 'accueil' ? 'bg-emerald-50 text-emerald-700' : ''}">Accueil</a>`;
        navHtml += `<a href="/catalogue.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium ${currentPageKey === 'catalogue' ? 'bg-emerald-50 text-emerald-700' : ''}">Catalogue</a>`;
        navHtml += `<a href="/connexion.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium ${currentPageKey === 'connexion' ? 'bg-emerald-50 text-emerald-700' : ''}">Connexion</a>`;
        navHtml += `<a href="/inscription.html" class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors ${currentPageKey === 'inscription' ? 'ring-2 ring-offset-2 ring-emerald-400' : ''}">Inscription</a>`;
    }
    if (user) {
          navHtml += `<a href="/catalogue.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium ${currentPageKey === 'catalogue' ? 'bg-emerald-50 text-emerald-700' : ''}">Catalogue</a>`;
        if (user.role === 'client') {
             navHtml += `<a href="/client/dashboard.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium ${currentPageKey === 'dashboard_client' ? 'bg-emerald-50 text-emerald-700' : ''}">Mon Espace</a>`;
        }
        if (user.role === 'boutique') {
            navHtml += `<a href="/boutique/dashboard.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium ${currentPageKey === 'boutique_dashboard' ? 'bg-emerald-50 text-emerald-700' : ''}">Ma Boutique</a>`;
        }
        if (user.role === 'parrain') {
            navHtml += `<a href="/parrain/dashboard.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium ${currentPageKey === 'parrain_dashboard' ? 'bg-emerald-50 text-emerald-700' : ''}">Mon Parrainage</a>`;
        }
        navHtml += `
            <div class="relative notification-dropdown-trigger">
                <a href="/client/notifications.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium relative ${currentPageKey === 'notifications' ? 'bg-emerald-50 text-emerald-700' : ''}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="inline-block"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"></path><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"></path></svg>
                    <span id="navNotificationCounter" class="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2 bg-red-500 text-white text-xs font-bold rounded-full px-1.5 py-0.5 hidden items-center justify-center" style="min-width: 18px; height: 18px; line-height:1;">0</span>
                </a>
                <!-- Dropdown de Notifications -->
                <div id="navNotificationDropdown" class="absolute right-0 mt-2 w-80 bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 hidden z-40 py-1">
                    <p class="text-xs text-gray-500 p-3 text-center">Chargement...</p>
                </div>
            </div>
        `;
        navHtml += `<a href="/panier.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium relative ${currentPageKey === 'panier' ? 'bg-emerald-50 text-emerald-700' : ''}">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="inline-block"><circle cx="8" cy="21" r="1"></circle><circle cx="19" cy="21" r="1"></circle><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"></path></svg>
                        <span id="cart-counter" class="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2 bg-red-500 text-white text-xs font-bold rounded-full px-1.5 py-0.5 hidden items-center justify-center" style="min-width: 18px; height: 18px; line-height:1;">0</span>
                    </a>`;
        navHtml += `<button id="logoutButtonUser" class="ml-3 bg-emerald-500 hover:bg-emerald-600 text-white px-3 py-1.5 rounded-md text-sm font-medium transition-colors">Déconnexion</button>`;
    }
    if (adminUser) {
        navHtml += `<a href="/admin/dashboard.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium ${currentPageKey === 'admin_dashboard' ? 'bg-emerald-50 text-emerald-700' : ''}">Dashboard Admin</a>`;
        navHtml += `<a href="/admin/product-validation.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium ${currentPageKey === 'admin_validation' ? 'bg-emerald-50 text-emerald-700' : ''}">Validation</a>`;
        navHtml += `<button id="logoutButtonAdmin" class="ml-3 bg-emerald-500 hover:bg-emerald-600 text-white px-3 py-1.5 rounded-md text-sm font-medium transition-colors">Déconnexion Admin</button>`;
        navHtml += `
            <div class="relative notification-dropdown-trigger">
                <a href="/client/notifications.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium relative ${currentPageKey === 'notifications' ? 'bg-emerald-50 text-emerald-700' : ''}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="inline-block"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"></path><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"></path></svg>
                    <span id="navNotificationCounter" class="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2 bg-red-500 text-white text-xs font-bold rounded-full px-1.5 py-0.5 hidden items-center justify-center" style="min-width: 18px; height: 18px; line-height:1;">0</span>
                </a>
                <!-- Dropdown de Notifications -->
                <div id="navNotificationDropdown" class="absolute right-0 mt-2 w-80 bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 hidden z-40 py-1">
                    <p class="text-xs text-gray-500 p-3 text-center">Chargement...</p>
                </div>
            </div>
        `;
    }
    navHtml += `
                </div>
                <div class="md:hidden">
                    <button id="navbarBurger" aria-label="menu" class="text-gray-700 focus:outline-none p-2">
                        <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" /></svg>
                    </button>
                </div>
            </div>
            <div id="mobileMenu" class="hidden md:hidden bg-white shadow-lg absolute top-full left-0 right-0 z-30 border-t border-gray-200"></div>
        </nav>
    `;

    const navbarPlaceholder = document.getElementById('navbar-placeholder');
    if (navbarPlaceholder) navbarPlaceholder.innerHTML = navHtml;
    else if (document.body) document.body.insertAdjacentHTML('afterbegin', navHtml);
    else document.addEventListener('DOMContentLoaded', () => document.body.insertAdjacentHTML('afterbegin', navHtml));
    
    attachNavbarEventListeners();
    setupBurgerMenu('navbar-placeholder');
    updateCartCounterInNav();
    updateNotificationCounterInNav(); // Appel initial pour les notifs

    // Gérer l'ouverture/fermeture du dropdown de notifications
    const notifTrigger = document.querySelector('.notification-dropdown-trigger');
    const notifDropdown = document.getElementById('navNotificationDropdown');
    if (notifTrigger && notifDropdown) {
        notifTrigger.addEventListener('click', (event) => {
            event.stopPropagation(); // Empêcher le clic de se propager au document
            notifDropdown.classList.toggle('hidden');
        });
        // Fermer le dropdown si on clique ailleurs
        document.addEventListener('click', (event) => {
            if (!notifDropdown.classList.contains('hidden') && !notifTrigger.contains(event.target)) {
                notifDropdown.classList.add('hidden');
            }
        });
    }
}

function attachNavbarEventListeners() {
    const logoutBtnUser = document.getElementById('logoutButtonUser');
    if (logoutBtnUser) {
        logoutBtnUser.addEventListener('click', () => handleLogout('authToken', 'userData', '/connexion.html'));
    }

    const logoutBtnAdmin = document.getElementById('logoutButtonAdmin');
    if (logoutBtnAdmin) {
        logoutBtnAdmin.addEventListener('click', () => handleLogout('adminAuthToken', 'adminUserData', '/admin/login.html'));
    }
    
    // Vous pouvez ajouter d'autres écouteurs ici pour les liens si nécessaire,
    // mais les <a> avec href fonctionnent nativement.
}

function renderFooter() {
    const footerPlaceholder = document.getElementById('footer-placeholder');
    if (!footerPlaceholder) {
        const tempFooterDiv = document.createElement('div');
        tempFooterDiv.id = 'footer-placeholder';
        if (document.body) {
            document.body.appendChild(tempFooterDiv);
        } else {
            document.addEventListener('DOMContentLoaded', () => document.body.appendChild(tempFooterDiv));
        }
    }
    // S'assurer qu'il existe maintenant
    const finalPlaceholder = document.getElementById('footer-placeholder');
    if (!finalPlaceholder) {
        console.warn("Placeholder du footer non trouvé pour injecter le footer.");
        return;
    }

    const svgs = {
         facebook: '<svg class="lucide h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>',
        instagram: '<svg class="lucide h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>',
        twitter: '<svg class="lucide h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8z"></path></svg>',
        mapPin: '<svg class="lucide h-5 w-5 text-emerald-400 mr-2 mt-0.5 flex-shrink-0" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path><circle cx="12" cy="10" r="3"></circle></svg>',
        phone: '<svg class="lucide h-5 w-5 text-emerald-400 mr-2 flex-shrink-0" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>',
        mail: '<svg class="lucide h-5 w-5 text-emerald-400 mr-2 flex-shrink-0" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"></rect><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path></svg>' 
    }; // Copiez la définition des SVGs d'une réponse précédente

    const footerHtml = `
    <footer class="bg-gray-900 text-gray-300 mt-auto"> 
      <div class="max-w-7xl mx-auto px-6 py-12">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 class="text-white text-lg font-semibold mb-4">À propos</h3>
            <p class="text-gray-400 mb-4 text-sm">
              NSBIO-TECH est votre partenaire santé, dédié à vous offrir des produits naturels de qualité pour améliorer votre bien-être au quotidien.
            </p>
            <div class="flex space-x-4">
              <a href="#" class="text-gray-400 hover:text-white transition-colors">${svgs.facebook}</a>
              <a href="#" class="text-gray-400 hover:text-white transition-colors">${svgs.instagram}</a>
              <a href="#" class="text-gray-400 hover:text-white transition-colors">${svgs.twitter}</a>
            </div>
          </div>
          <div>
            <h3 class="text-white text-lg font-semibold mb-4">Liens Rapides</h3>
            <ul class="space-y-2 text-sm">
              <li><a href="/" class="text-gray-400 hover:text-white transition-colors">Accueil</a></li>
              <li><a href="/catalogue.html" class="text-gray-400 hover:text-white transition-colors">Catalogue</a></li>
              <li><a href="#" class="text-gray-400 hover:text-white transition-colors">À propos</a></li>
              <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Blog</a></li>
              <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>
          <div>
            <h3 class="text-white text-lg font-semibold mb-4">Catégories</h3>
             <ul class="space-y-2 text-sm">
              <li><a href="/catalogue.html?category=Huiles Essentielles" class="text-gray-400 hover:text-white transition-colors">Huiles Essentielles</a></li>
              <li><a href="/catalogue.html?category=Thés" class="text-gray-400 hover:text-white transition-colors">Thés & Infusions</a></li>
              <li><a href="/catalogue.html?category=Compléments" class="text-gray-400 hover:text-white transition-colors">Compléments Alimentaires</a></li>
            </ul>
          </div>
          <div>
            <h3 class="text-white text-lg font-semibold mb-4">Contact Info</h3>
            <ul class="space-y-3 text-sm">
              <li class="flex items-start">${svgs.mapPin}<span class="text-gray-400">123 Rue de la Nature, VotreVille</span></li>
              <li class="flex items-center">${svgs.phone}<span class="text-gray-400">+XX XXX XX XX XX</span></li>
              <li class="flex items-center">${svgs.mail}<span class="text-gray-400">contact@nsbio.tech</span></li>
            </ul>
          </div>
        </div>
        <div class="border-t border-gray-800 mt-10 pt-8 text-center md:flex md:justify-between md:items-center">
          <p class="text-sm text-gray-500 mb-4 md:mb-0">
            © ${new Date().getFullYear()} NSBIO-TECH. Tous droits réservés.
          </p>
          <ul class="flex justify-center space-x-6">
            <li><a href="#" class="text-sm text-gray-500 hover:text-white transition-colors">CGV</a></li>
            <li><a href="#" class="text-sm text-gray-500 hover:text-white transition-colors">Confidentialité</a></li>
            <li><a href="#" class="text-sm text-gray-500 hover:text-white transition-colors">Mentions légales</a></li>
          </ul>
        </div>
      </div>
    </footer>
    `;
    finalPlaceholder.innerHTML = footerHtml;
}



// function renderNavbar(currentPageKey) {
//     const user = getAuthenticatedUser();
//     const adminUser = getAuthenticatedUser('adminAuthToken', 'adminUserData');
//     let navHtml = '';

//     navHtml += `
//         <nav class="navbar bg-white py-3 px-4 shadow-sm fixed top-0 left-0 right-0 z-50 h-[var(--navbar-height)]">
//             <div class="max-w-7xl mx-auto flex justify-between items-center h-full">
//                 <div class="flex items-center">
//                     <a href="/index.html" class="text-2xl font-bold text-emerald-600">NSBIO-TECH</a>
//                 </div>
//                 <div class="nav-links-desktop hidden md:flex items-center space-x-4">
//     `;
//     // ... (Liens Visiteur, Admin) ...

//     if (user || adminUser) { // Si un utilisateur (standard ou admin) est connecté
//         // ... (autres liens pour user/admin) ...
//         navHtml += `
//             <div class="relative notification-dropdown-trigger">
//                 <a href="/client/notifications.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium relative ${currentPageKey === 'notifications' ? 'bg-emerald-50 text-emerald-700' : ''}">
//                     <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="inline-block"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"></path><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"></path></svg>
//                     <span id="navNotificationCounter" class="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2 bg-red-500 text-white text-xs font-bold rounded-full px-1.5 py-0.5 hidden items-center justify-center" style="min-width: 18px; height: 18px; line-height:1;">0</span>
//                 </a>
//                 <!-- Dropdown de Notifications -->
//                 <div id="navNotificationDropdown" class="absolute right-0 mt-2 w-80 bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 hidden z-40 py-1">
//                     {/* Contenu injecté par updateNotificationCounterInNav */}
//                     <p class="text-xs text-gray-500 p-3 text-center">Chargement...</p>
//                 </div>
//             </div>
//         `;
//          if (user) { // Seulement pour utilisateurs non-admin
//             navHtml += `<a href="/panier.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium relative ${currentPageKey === 'panier' ? 'bg-emerald-50 text-emerald-700' : ''}">
//                             <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="inline-block"><circle cx="8" cy="21" r="1"></circle><circle cx="19" cy="21" r="1"></circle><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"></path></svg>
//                             <span id="cart-counter" class="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2 bg-red-500 text-white text-xs font-bold rounded-full px-1.5 py-0.5 hidden items-center justify-center" style="min-width: 18px; height: 18px; line-height:1;">0</span>
//                         </a>`;
//             navHtml += `<button id="logoutButtonUser" class="ml-3 bg-emerald-500 hover:bg-emerald-600 text-white px-3 py-1.5 rounded-md text-sm font-medium transition-colors">Déconnexion</button>`;
//         }
//         if (adminUser) {
//              navHtml += `<button id="logoutButtonAdmin" class="ml-3 bg-emerald-500 hover:bg-emerald-600 text-white px-3 py-1.5 rounded-md text-sm font-medium transition-colors">Déconnexion Admin</button>`;
//         }
//     } else { // Visiteur non connecté
//          navHtml += `<a href="/index.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium ${currentPageKey === 'accueil' ? 'bg-emerald-50 text-emerald-700' : ''}">Accueil</a>`;
//         navHtml += `<a href="/catalogue.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium ${currentPageKey === 'catalogue' ? 'bg-emerald-50 text-emerald-700' : ''}">Catalogue</a>`;
//         navHtml += `<a href="/connexion.html" class="text-gray-700 hover:text-emerald-600 px-3 py-2 rounded-md text-sm font-medium ${currentPageKey === 'connexion' ? 'bg-emerald-50 text-emerald-700' : ''}">Connexion</a>`;
//         navHtml += `<a href="/inscription.html" id="navSignupButton" class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors ${currentPageKey === 'inscription' ? 'ring-2 ring-offset-2 ring-emerald-400' : ''}">Inscription</a>`;
//     }


//     navHtml += `
//                 </div>
//                 <div class="md:hidden">
//                     <button id="navbarBurger" aria-label="menu" class="text-gray-700 focus:outline-none p-2">
//                         {/* ... SVG burger ... */}
//                     </button>
//                 </div>
//             </div>
//             <div id="mobileMenu" class="hidden md:hidden bg-white shadow-lg absolute top-full left-0 right-0 z-30 border-t border-gray-200"></div>
//         </nav>
//     `;

    
// }
 