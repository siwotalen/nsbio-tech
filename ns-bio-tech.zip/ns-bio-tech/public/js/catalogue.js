// public/js/catalogue.js

document.addEventListener('DOMContentLoaded', function() {
    renderNavbar('catalogue'); // Appel pour la navbar
    renderFooter();          // Appel pour le footer

    const productListDiv = document.getElementById('productList');
    const searchForm = document.getElementById('searchForm');
    const searchInput = document.getElementById('searchInput');
    const categoryFilterSelect = document.getElementById('categoryFilter'); // Supposons que vous l'ajoutiez au HTML

    // Pour stocker les catégories uniques récupérées de l'API (si vous implémentez le filtre catégorie)
    let availableCategories = new Set();

    /**
     * Affiche les produits dans le DOM.
     * @param {Array} products - Le tableau de produits à afficher.
     */
    function displayProducts(products) {
        productListDiv.innerHTML = ''; // Vider la liste actuelle

        if (!products || products.length === 0) {
            productListDiv.innerHTML = '<p class="no-products col-span-full text-center py-10 text-gray-500">Aucun produit ou service ne correspond à vos critères.</p>';
            return;
        }

        products.forEach(product => {
            const productCard = document.createElement('div');
            productCard.className = 'product-card'; // Classe définie dans style.css (ou Tailwind classes directes)

            const typeBadgeClass = product.typeElement === 'produit' ? 'product-type-produit' : 'product-type-service';
            const typeText = product.typeElement === 'produit' ? 'Produit' : 'Service';

            let description = product.description || 'Aucune description disponible.';
            // La limitation de lignes se fait via CSS (.line-clamp-2 ou 3 dans la carte)

            // Gestion des étoiles (simplifiée)
            let starsHtml = '';
            const rating = product.rating || 0;
            for (let i = 0; i < 5; i++) {
                starsHtml += `<span class="inline-block ${i < Math.floor(rating) ? 'text-amber-500 fill-amber-500' : 'text-gray-300'}">
                                ${ICONS_SVG && ICONS_SVG.Star ? ICONS_SVG.Star : '★'}
                             </span>`;
            }


            productCard.innerHTML = `
                <a href="/produit-detail.html?id=${product._id}" class="block h-full flex flex-col">
                    <div class="product-image-container">
                        <img src="${product.imageUrl || 'https://via.placeholder.com/300x200?text=NSBIO'}" alt="${product.nom}" class="w-full h-full object-cover">
                    </div>
                    <div class="product-info p-4 flex-grow flex flex-col">
                        <h3 class="font-semibold text-lg mb-1 text-gray-800 group-hover:text-emerald-600 transition-colors">${product.nom}</h3>
                        ${product.categorie ? `<span class="text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full inline-block mb-2 capitalize">${product.categorie}</span>` : ''}
                        <p class="text-gray-600 text-sm mb-4 line-clamp-3 flex-grow">${description}</p> {/* line-clamp-3 pour 3 lignes */}
                        <div class="flex items-center mb-2">
                            ${starsHtml}
                            <span class="text-xs text-gray-500 ml-1">(${rating.toFixed(1)})</span>
                        </div>
                        <div class="mt-auto flex items-center justify-between">
                            <span class="font-bold text-emerald-600 text-lg">${product.prix.toFixed(2)} FCFA</span>
                            <span class="product-type-badge ${typeBadgeClass} text-xs px-2 py-1 rounded-full font-medium">${typeText}</span>
                        </div>
                    </div>
                </a>
            `;
            // Ajouter un data-attribute pour la catégorie pour un filtrage client simple (si pas de filtre backend)
            // productCard.dataset.category = product.categorie.toLowerCase();

            productListDiv.appendChild(productCard);
        });
    }
    
    /**
     * Remplit le sélecteur de catégories (si implémenté).
     */
    function populateCategoryFilter() {
        if (!categoryFilterSelect || availableCategories.size === 0) return;

        // Garder l'option "Toutes catégories"
        categoryFilterSelect.innerHTML = '<option value="">Toutes les catégories</option>';
        availableCategories.forEach(category => {
            if(category){ // S'assurer que la catégorie n'est pas vide/null
                const option = document.createElement('option');
                option.value = category;
                option.textContent = category.charAt(0).toUpperCase() + category.slice(1); // Capitalize
                categoryFilterSelect.appendChild(option);
            }
        });
    }


    /**
     * Récupère les produits depuis l'API avec les filtres actuels.
     */
    async function fetchAndDisplayProducts() {
        const searchTerm = searchInput ? searchInput.value.trim() : '';
        const selectedCategory = categoryFilterSelect ? categoryFilterSelect.value : '';

        productListDiv.innerHTML = '<p class="no-products col-span-full text-center py-10 text-gray-500">Chargement des produits...</p>';
        try {
            const params = new URLSearchParams();
            if (searchTerm) params.append('search', searchTerm);
            if (selectedCategory) params.append('category', selectedCategory);
            // Ajoutez ici d'autres filtres si besoin (ex: tri, fourchette de prix)

            const apiUrl = `${API_BASE_URL}/products?${params.toString()}`;
            const response = await fetch(apiUrl);

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({})); // Tenter de parser l'erreur JSON
                throw new Error(errorData.message || `Erreur HTTP ${response.status}`);
            }
            const data = await response.json();

            if (data.success && data.products) {
                displayProducts(data.products);
                
                // Collecter les catégories uniques pour le filtre (si le filtre est côté client ou pour peupler le select)
                // Si le backend ne renvoie pas les catégories disponibles, on les déduit des produits chargés
                if (availableCategories.size === 0 && data.products.length > 0) { // Ne le faire qu'une fois
                     data.products.forEach(p => {
                        if (p.categorie) availableCategories.add(p.categorie.trim());
                     });
                     populateCategoryFilter(); // Mettre à jour le select
                }

            } else {
                showMessage(data.message || 'Impossible de charger les produits.', 'error', 'messageAreaGlobal'); // Utiliser une zone globale
                productListDiv.innerHTML = '<p class="no-products col-span-full text-center py-10 text-gray-500">Aucun produit trouvé.</p>';
            }
        } catch (error) {
            console.error('Erreur de récupération des produits:', error);
            showMessage(`Erreur: ${error.message}`, 'error', 'messageAreaGlobal');
            productListDiv.innerHTML = '<p class="no-products col-span-full text-center py-10 text-red-500">Une erreur est survenue lors du chargement des produits.</p>';
        }
    }

    // Gérer la soumission du formulaire de recherche
    if (searchForm) {
        searchForm.addEventListener('submit', function(event) {
            event.preventDefault();
            fetchAndDisplayProducts(); // L'API backend gère les filtres
        });
    }
    
    // Gérer le changement de filtre catégorie (si le select existe)
    if (categoryFilterSelect) {
        categoryFilterSelect.addEventListener('change', function() {
            fetchAndDisplayProducts();
        });
    }

    // Chargement initial des produits et des catégories pour le filtre
    fetchAndDisplayProducts();
});