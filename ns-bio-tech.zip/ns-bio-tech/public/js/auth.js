async function handleMainLogin(event) {
    event.preventDefault();
    const form = event.target;
    const email = form.email.value;
    const password = form.password.value;
    const messageAreaId = form.dataset.messageAreaId || 'loginMessageArea';

    showMessage('Connexion en cours...', 'info', messageAreaId);

    try {
        const response = await fetch(`${API_BASE_URL}/auth/signin`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password }),
        });
        const data = await response.json();

        if (response.ok && data.success && data.token && data.user) {
            localStorage.setItem('authToken', data.token);
            localStorage.setItem('userData', JSON.stringify(data.user));
            showMessage('Connexion réussie ! Redirection...', 'success', messageAreaId);

            switch (data.user.role) {
                case 'client': window.location.href = '/catalogue.html'; break;
                case 'boutique': window.location.href = '/boutique/dashboard.html'; break;
                case 'parrain': window.location.href = '/parrain/dashboard.html'; break;
                default: window.location.href = '/index.html';
            }
        } else {
            showMessage(data.message || 'Email ou mot de passe incorrect.', 'error', messageAreaId);
        }
    } catch (error) {
        console.error('Erreur de connexion:', error);
        showMessage('Une erreur réseau est survenue. Veuillez réessayer.', 'error', messageAreaId);
    }
}

async function handleAdminLogin(event) {
    event.preventDefault();
    const form = event.target;
    const email = form.email.value;
    const password = form.password.value;
    const messageAreaId = form.dataset.messageAreaId || 'adminLoginMessageArea';

    showMessage('Connexion admin en cours...', 'info', messageAreaId);

    try {
        const response = await fetch(`${API_BASE_URL}/auth/signin`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password }),
        });
        const data = await response.json();

        if (response.ok && data.success && data.token && data.user) {
            if (data.user.role === 'admin') {
                localStorage.setItem('adminAuthToken', data.token);
                localStorage.setItem('adminUserData', JSON.stringify(data.user));
                showMessage('Connexion admin réussie ! Redirection...', 'success', messageAreaId);
                window.location.href = '/admin/dashboard.html';
            } else {
                showMessage('Accès non autorisé pour ce compte.', 'error', messageAreaId);
            }
        } else {
            showMessage(data.message || 'Identifiants admin incorrects ou accès refusé.', 'error', messageAreaId);
        }
    } catch (error) {
        console.error('Erreur de connexion admin:', error);
        showMessage('Une erreur réseau est survenue. Veuillez réessayer.', 'error', messageAreaId);
    }
}

async function handleSignup(event) {
    event.preventDefault();
    const form = event.target;
    const messageAreaId = form.dataset.messageAreaId || 'signupMessageArea';

    const formData = {
        email: form.email.value,
        password: form.password.value,
        confirmPassword: form.confirmPassword.value, // Important pour la validation backend
        role: form.role.value,
        nomComplet: form.nomComplet.value,
        telephone: form.telephone.value || undefined,
        codeParrainSaisi: form.codeParrainSaisi?.value || undefined,
        nomBoutique: form.nomBoutique?.value || undefined,
        descriptionBoutique: form.descriptionBoutique?.value || undefined,
        codePromoPersonnel: form.codePromoPersonnelInput?.value || undefined,
    };

    if (formData.password !== formData.confirmPassword) {
        showMessage('Les mots de passe ne correspondent pas.', 'error', messageAreaId);
        return;
    }
    // On peut supprimer confirmPassword avant l'envoi si le backend ne s'y attend pas après validation
    // delete formData.confirmPassword; // Si Joi s'en occupe et qu'on ne veut pas le polluer

    for (const key in formData) { // Nettoyer les undefined
        if (formData[key] === undefined) {
            delete formData[key];
        }
    }

    showMessage('Inscription en cours...', 'info', messageAreaId);

    try {
        const response = await fetch(`${API_BASE_URL}/auth/signup`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });
        const data = await response.json();

        if (response.status === 201 && data.success) {
            showMessage(data.message + ' Vous pouvez maintenant vous connecter.', 'success', messageAreaId);
            form.reset();
            // Relancer toggleConditionalFields pour réinitialiser l'affichage des champs
            if (typeof toggleConditionalFields === "function") { // Vérifier si la fonction existe globalement
                toggleConditionalFields();
            } else { // Ou cibler directement les divs
                document.getElementById('clientFields')?.classList.add('hidden');
                document.getElementById('boutiqueFields')?.classList.add('hidden');
                document.getElementById('parrainFields')?.classList.add('hidden');
            }
        } else {
            showMessage(data.message || `Erreur d'inscription (HTTP ${response.status})`, 'error', messageAreaId);
        }
    } catch (error) {
        console.error('Erreur inscription:', error);
        showMessage('Une erreur réseau est survenue lors de l\'inscription.', 'error', messageAreaId);
    }
}
// function showMessage(message, type = 'info', messageAreaId = 'messageArea') {
//     const messageArea = document.getElementById(messageAreaId);
//     if (messageArea) {
//         messageArea.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
//         setTimeout(() => { messageArea.innerHTML = ''; }, 5000); // Effacer après 5 secondes
//     } else {
//         console.warn(`Alerte de type "${type}" : ${message}`);
//     }
// }   