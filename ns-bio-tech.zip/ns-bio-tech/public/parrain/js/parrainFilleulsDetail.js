// public/js/parrain/parrainFilleulsDetail.js
document.addEventListener('DOMContentLoaded', function() {
    const parrainUser = protectPage('parrain', 'authToken', 'userData', '/connexion.html');
    if (!parrainUser) return;

    renderNavbar('parrain_filleuls');
    renderFooter();

    const filleulsTableContainer = document.getElementById('filleulsTableContainer');
    const filleulPaginationDiv = document.getElementById('filleulPagination');
    const totalFilleulsDisplay = document.getElementById('totalFilleulsDisplay');
    const messageArea = 'messageAreaFilleuls';

    let currentPage = 1;
    const limit = 10;

    async function fetchParrainFilleuls(page = 1) {
        filleulsTableContainer.innerHTML = '<p class="text-gray-500 py-4">Chargement de vos filleuls...</p>';
        try {
            const token = localStorage.getItem('authToken');
            const params = new URLSearchParams({
                page: page.toString(),
                limit: limit.toString(),
            });

            const response = await fetch(`${API_BASE_URL}/users/me/referred-users?${params.toString()}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) throw new Error('Erreur lors du chargement des filleuls.');
            
            const data = await response.json();

            if (data.success && data.filleuls) {
                displayFilleuls(data.filleuls);
                displayPagination(data.currentPage, data.totalPages); // Réutiliser la fonction de pagination
                if(totalFilleulsDisplay) totalFilleulsDisplay.textContent = data.totalFilleuls || 0;
            } else {
                filleulsTableContainer.innerHTML = `<p class="text-gray-500 py-4">${data.message || 'Aucun filleul trouvé.'}</p>`;
                displayPagination(1,1);
                 if(totalFilleulsDisplay) totalFilleulsDisplay.textContent = '0';
            }
        } catch (error) {
            console.error("Erreur fetchParrainFilleuls:", error);
            showMessage(error.message, 'error', messageArea);
            filleulsTableContainer.innerHTML = `<p class="text-red-500 py-4">Erreur de chargement des filleuls.</p>`;
        }
    }

    function displayFilleuls(filleuls) {
        if (filleuls.length === 0) {
            filleulsTableContainer.innerHTML = '<p class="text-gray-500 py-4 text-center">Vous n\'avez pas encore de filleuls.</p>';
            return;
        }
        let tableHTML = `
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nom Complet</th>
                        <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                        <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date d'Inscription</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">`;
        
        filleuls.forEach(filleul => {
            tableHTML += `
                <tr>
                    <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-900">${filleul.nomComplet || 'N/A'}</td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-500">${filleul.email}</td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-500">${new Date(filleul.createdAt).toLocaleDateString()}</td>
                </tr>
            `;
        });
        tableHTML += `</tbody></table>`;
        filleulsTableContainer.innerHTML = tableHTML;
    }

    // La fonction displayPagination est la même que pour les commissions.
    // Vous pouvez la rendre globale dans main.js ou la copier ici.
    // Pour cet exemple, je suppose qu'elle est copiée ou importée si main.js est un module.
    // Par simplicité, je la copie ici :
    function displayPagination(currentPageNum, totalPagesNum) {
        filleulPaginationDiv.innerHTML = '';
        if (totalPagesNum <= 1) return;
        // ... (même code que displayPagination dans parrainCommissionsDetail.js, mais utiliser fetchParrainFilleuls pour les clics)
        // Remplacer les appels : fetchParrainCommissions(..., statusFilter.value) par fetchParrainFilleuls(...)

        // Bouton Précédent
        const prevButton = document.createElement('button');
        prevButton.innerHTML = '« Préc.';
        prevButton.className = 'px-4 py-2 mx-1 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed';
        prevButton.disabled = currentPageNum === 1;
        prevButton.addEventListener('click', () => fetchParrainFilleuls(currentPageNum - 1)); // Appel correct
        filleulPaginationDiv.appendChild(prevButton);

        let startPage = Math.max(1, currentPageNum - 2);
        let endPage = Math.min(totalPagesNum, currentPageNum + 2);
        if (currentPageNum <=3) endPage = Math.min(totalPagesNum, 5);
        if (currentPageNum >= totalPagesNum - 2) startPage = Math.max(1, totalPagesNum - 4);

        if (startPage > 1) {
            const firstButton = document.createElement('button'); /* ... */ firstButton.textContent = '1';
            firstButton.className = 'px-4 py-2 mx-1 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50';
            firstButton.addEventListener('click', () => fetchParrainFilleuls(1)); filleulPaginationDiv.appendChild(firstButton);
            if (startPage > 2) { /* ... ellipsis ... */ }
        }
        for (let i = startPage; i <= endPage; i++) {
            const pageButton = document.createElement('button'); pageButton.textContent = i;
            pageButton.className = `px-4 py-2 mx-1 text-sm font-medium border border-gray-300 rounded-md hover:bg-gray-50 ${i === currentPageNum ? 'bg-emerald-600 text-white border-emerald-600' : 'text-gray-700 bg-white'}`;
            if (i === currentPageNum) pageButton.disabled = true;
            pageButton.addEventListener('click', () => fetchParrainFilleuls(i)); filleulPaginationDiv.appendChild(pageButton);
        }
        if (endPage < totalPagesNum) {
            if (endPage < totalPagesNum - 1) { /* ... ellipsis ... */ }
            const lastButton = document.createElement('button'); /* ... */ lastButton.textContent = totalPagesNum;
            lastButton.className = 'px-4 py-2 mx-1 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50';
            lastButton.addEventListener('click', () => fetchParrainFilleuls(totalPagesNum)); filleulPaginationDiv.appendChild(lastButton);
        }

        const nextButton = document.createElement('button');
        nextButton.innerHTML = 'Suiv. »';
        nextButton.className = 'px-4 py-2 mx-1 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed';
        nextButton.disabled = currentPageNum === totalPagesNum;
        nextButton.addEventListener('click', () => fetchParrainFilleuls(currentPageNum + 1)); // Appel correct
        filleulPaginationDiv.appendChild(nextButton);
    }

    // Chargement initial
    fetchParrainFilleuls(currentPage);
});