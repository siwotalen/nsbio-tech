// public/js/parrain/requestPayout.js
document.addEventListener('DOMContentLoaded', function() {
    const parrainUser = protectPage('parrain', 'authToken', 'userData', '/connexion.html');
    if (!parrainUser) return;

    renderNavbar('parrain_payout');
    renderFooter();

    const totalAvailableSpan = document.getElementById('totalAvailableForPayout');
    const commissionsListDiv = document.getElementById('commissionsToPayoutList');
    const selectAllCheckbox = document.getElementById('selectAllCommissions');
    const requestPayoutButton = document.getElementById('requestPayoutButton');
    const messageArea = 'messageAreaPayout';
    
    const payoutMethodTypeSpan = document.getElementById('payoutMethodType');
    const payoutMethodDetailsSpan = document.getElementById('payoutMethodDetails');

    let eligibleCommissions = []; // Pour stocker les commissions avec statut 'validee'

    async function loadEligibleCommissions() {
        commissionsListDiv.innerHTML = '<p class="text-gray-500 p-2">Chargement...</p>';
        requestPayoutButton.disabled = true;
        try {
            const token = localStorage.getItem('authToken');
            // Récupérer uniquement les commissions validées
            const response = await fetch(`${API_BASE_URL}/users/me/commissions?statut=validee&limit=500`, { // Limite haute pour tout récupérer
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) throw new Error('Erreur chargement des commissions éligibles.');
            
            const data = await response.json();

            if (data.success && data.commissions) {
                eligibleCommissions = data.commissions;
                displayEligibleCommissions();
                updateTotalAvailable();
            } else {
                commissionsListDiv.innerHTML = `<p class="text-gray-500 p-2">${data.message || 'Aucune commission validée disponible pour un paiement.'}</p>`;
                 if(totalAvailableSpan) totalAvailableSpan.textContent = '0.00 FCFA';
            }
        } catch (error) {
            console.error("Erreur loadEligibleCommissions:", error);
            showMessage(error.message, 'error', messageArea);
            commissionsListDiv.innerHTML = `<p class="text-red-500 p-2">Erreur de chargement.</p>`;
        }
    }

    function displayEligibleCommissions() {
        commissionsListDiv.innerHTML = '';
        if (eligibleCommissions.length === 0) {
            commissionsListDiv.innerHTML = '<p class="text-gray-500 p-2 text-center">Aucune commission validée à demander en paiement.</p>';
            requestPayoutButton.disabled = true;
            if(selectAllCheckbox) selectAllCheckbox.disabled = true;
            return;
        }
        
        if(selectAllCheckbox) selectAllCheckbox.disabled = false;
        requestPayoutButton.disabled = false; // Activer si des commissions existent

        const ul = document.createElement('ul');
        ul.className = 'space-y-2';
        eligibleCommissions.forEach(comm => {
            const li = document.createElement('li');
            li.className = 'flex items-center justify-between p-2 border-b border-gray-100 last:border-b-0';
            li.innerHTML = `
                <div class="flex items-center">
                    <input type="checkbox" id="comm-${comm._id}" name="commissionSelection" value="${comm._id}" class="h-4 w-4 text-emerald-600 border-gray-300 rounded focus:ring-emerald-500 mr-3 commission-checkbox">
                    <label for="comm-${comm._id}" class="text-sm text-gray-700">
                        ID: ...${comm._id.slice(-6)} - Montant: <strong class="text-emerald-600">${comm.montantCommission.toFixed(2)} FCFA</strong>
                        <span class="block text-xs text-gray-500">Date: ${new Date(comm.createdAt).toLocaleDateString()}</span>
                    </label>
                </div>
            `;
            ul.appendChild(li);
        });
        commissionsListDiv.appendChild(ul);
        addCheckboxListeners();
    }
    
    function addCheckboxListeners() {
        document.querySelectorAll('.commission-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', updateTotalAvailable);
        });
    }

    function updateTotalAvailable() {
        let selectedTotal = 0;
        const selectedCheckboxes = document.querySelectorAll('.commission-checkbox:checked');
        selectedCheckboxes.forEach(cb => {
            const commission = eligibleCommissions.find(c => c._id === cb.value);
            if (commission) selectedTotal += commission.montantCommission;
        });
        if(totalAvailableSpan) totalAvailableSpan.textContent = `${selectedTotal.toFixed(2)} FCFA`;
        requestPayoutButton.disabled = selectedTotal <= 0;
    }
    
    function displayPayoutMethod() {
        if (parrainUser && parrainUser.informationsPaiementSimulees) {
            const paiement = parrainUser.informationsPaiementSimulees;
            if (payoutMethodTypeSpan) payoutMethodTypeSpan.textContent = paiement.typePaiementPrincipal.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase()) || 'Non configuré';
            
            let detailsText = "Veuillez configurer dans votre profil.";
            if (paiement.typePaiementPrincipal === 'mobile_money' && paiement.detailsMobileMoney?.numero) {
                detailsText = `${paiement.detailsMobileMoney.operateur || ''} - ${paiement.detailsMobileMoney.numero}`;
            } else if (paiement.typePaiementPrincipal === 'carte_bancaire' && paiement.detailsCarteBancaire?.quatreDerniersChiffres) {
                detailsText = `${paiement.detailsCarteBancaire.typeCarte || ''} se terminant par ${paiement.detailsCarteBancaire.quatreDerniersChiffres}`;
            }
            if(payoutMethodDetailsSpan) payoutMethodDetailsSpan.textContent = detailsText;
        }
    }


    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', function() {
            document.querySelectorAll('.commission-checkbox').forEach(checkbox => {
                checkbox.checked = this.checked;
            });
            updateTotalAvailable();
        });
    }

    if (requestPayoutButton) {
        requestPayoutButton.addEventListener('click', async function() {
            const selectedCommissionIds = Array.from(document.querySelectorAll('.commission-checkbox:checked')).map(cb => cb.value);

            if (selectedCommissionIds.length === 0) {
                showMessage('Veuillez sélectionner au moins une commission pour demander un paiement.', 'error', messageArea);
                return;
            }
            if (!parrainUser.informationsPaiementSimulees || parrainUser.informationsPaiementSimulees.typePaiementPrincipal === 'non_configure') {
                showMessage('Veuillez configurer vos informations de paiement dans votre profil avant de demander un retrait.', 'error', messageArea);
                return;
            }

            showMessage('Soumission de votre demande de paiement...', 'info', messageArea);
            this.disabled = true;
            this.innerHTML = `<svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Envoi...`;


            try {
                const token = localStorage.getItem('authToken');
                const response = await fetch(`${API_BASE_URL}/users/me/commissions/request-payout`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify({ commissionIds: selectedCommissionIds })
                });
                const data = await response.json();

                if (response.ok && data.success) {
                    showMessage(data.message || 'Demande de paiement soumise avec succès !', 'success', messageArea);
                    eligibleCommissions = []; // Vider pour forcer rechargement
                    loadEligibleCommissions(); // Recharger la liste
                    if(selectAllCheckbox) selectAllCheckbox.checked = false;
                } else {
                    showMessage(data.message || 'Erreur lors de la soumission de la demande.', 'error', messageArea);
                }
            } catch (error) {
                console.error("Erreur requestPayout:", error);
                showMessage('Une erreur réseau est survenue.', 'error', messageArea);
            } finally {
                this.disabled = false;
                this.textContent = 'Soumettre la Demande de Paiement';
            }
        });
    }

    // Chargement initial
    loadEligibleCommissions();
    displayPayoutMethod();
});