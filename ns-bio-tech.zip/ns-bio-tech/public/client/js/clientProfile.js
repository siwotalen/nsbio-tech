// public/js/client/clientProfile.js

document.addEventListener('DOMContentLoaded', function() {
    // Protéger la page (s'assurer que l'utilisateur est connecté, peu importe son rôle pour l'instant)
    const user = protectPage(null, 'authToken', 'userData', '/connexion.html'); // null pour n'importe quel rôle connecté
    if (!user) return;

    // Appeler renderNavbar après avoir récupéré l'utilisateur pour que la navbar sache s'il est connecté
    renderNavbar('profil_client'); // Ou une clé plus générique si cette page est partagée
    renderFooter();

    const messageArea = 'messageAreaProfile';

    // Éléments du DOM pour le profil général
    const profileForm = document.getElementById('profileForm');
    const nomCompletInput = document.getElementById('nomComplet');
    const telephoneInput = document.getElementById('telephone');
    const emailInput = document.getElementById('email'); // Readonly
    const profileAvatarImg = document.getElementById('profileAvatarImg'); // Pour l'avatar
    const changePasswordLink = document.getElementById('changePasswordLink');
    const saveProfileButton = document.getElementById('saveProfileButton');

    // Éléments pour les champs conditionnels
    const clientFieldsDiv = document.getElementById('profileClientFields');
    const boutiqueFieldsDiv = document.getElementById('profileBoutiqueFields');
    const parrainFieldsDiv = document.getElementById('profileParrainFields');

    // Champs spécifiques client
    const codeParrainSaisiInput = document.getElementById('codeParrainSaisi');
    const adresseRueInput = document.getElementById('adresseRue');
    const adresseVilleInput = document.getElementById('adresseVille');
    const adresseCodePostalInput = document.getElementById('adresseCodePostal');

    // Champs spécifiques boutique
    const nomBoutiqueInput = document.getElementById('profileNomBoutique');
    const descriptionBoutiqueInput = document.getElementById('profileDescriptionBoutique');

    // Champs spécifiques parrain
    const codePromoPersonnelInput = document.getElementById('profileCodePromoPersonnel');

    // Champs pour paiement simulé
    const typePaiementSelect = document.getElementById('typePaiementPrincipal');
    const mobileMoneyFieldsDiv = document.getElementById('detailsMobileMoneyFields');
    const carteBancaireFieldsDiv = document.getElementById('detailsCarteBancaireFields');
    const mobileMoneyNumeroInput = document.getElementById('mobileMoneyNumero');
    const mobileMoneyOperateurInput = document.getElementById('mobileMoneyOperateur');
    const carteTypeInput = document.getElementById('carteType');
    const carteDerniersChiffresInput = document.getElementById('carteDerniersChiffres');
    const carteDateExpirationInput = document.getElementById('carteDateExpiration');
    const soldeSimuleSpan = document.getElementById('soldeSimule');


    /**
     * Charge et affiche les informations du profil utilisateur.
     */
    async function loadUserProfile() {
        // Les informations de base sont déjà dans 'user' grâce à protectPage/getAuthenticatedUser
        // Mais pour obtenir les dernières infos (surtout solde, etc.), on peut refaire un appel API.
        const token = localStorage.getItem('authToken'); // Ou la clé de token appropriée
        try {
            const response = await fetch(`${API_BASE_URL}/users/me`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) {
                const errData = await response.json().catch(() => ({}));
                throw new Error(errData.message || "Erreur chargement du profil");
            }
            const data = await response.json();

            if (data.success && data.user) {
                populateProfileForm(data.user);
                toggleRoleSpecificFields(data.user.role);
                updatePaymentFieldsVisibility(data.user.informationsPaiementSimulees?.typePaiementPrincipal);

            } else {
                showMessage(data.message || "Profil non trouvé.", 'error', messageArea);
            }
        } catch (error) {
            console.error("Erreur chargement profil:", error);
            showMessage(error.message, 'error', messageArea);
        }
    }

    /**
     * Remplit le formulaire avec les données de l'utilisateur.
     * @param {object} userData - Les données de l'utilisateur.
     */
    function populateProfileForm(userData) {
        if (nomCompletInput) nomCompletInput.value = userData.nomComplet || '';
        if (telephoneInput) telephoneInput.value = userData.telephone || '';
        if (emailInput) emailInput.value = userData.email || ''; // Readonly

        // Infos de paiement
        if (userData.informationsPaiementSimulees) {
            const paiementInfo = userData.informationsPaiementSimulees;
            if (typePaiementSelect) typePaiementSelect.value = paiementInfo.typePaiementPrincipal || 'non_configure';
            if (mobileMoneyNumeroInput) mobileMoneyNumeroInput.value = paiementInfo.detailsMobileMoney?.numero || '';
            if (mobileMoneyOperateurInput) mobileMoneyOperateurInput.value = paiementInfo.detailsMobileMoney?.operateur || '';
            if (carteTypeInput) carteTypeInput.value = paiementInfo.detailsCarteBancaire?.typeCarte || '';
            if (carteDerniersChiffresInput) carteDerniersChiffresInput.value = paiementInfo.detailsCarteBancaire?.quatreDerniersChiffres || '';
            if (carteDateExpirationInput) carteDateExpirationInput.value = paiementInfo.detailsCarteBancaire?.dateExpiration || '';
            if (soldeSimuleSpan) soldeSimuleSpan.textContent = `${(paiementInfo.soldeCompteSimule || 0).toFixed(2)} FCFA`;
        }


        // Champs spécifiques au rôle
        if (userData.role === 'client') {
            if (codeParrainSaisiInput) codeParrainSaisiInput.value = userData.codeParrainSaisi || 'Aucun';
            if (adresseRueInput) adresseRueInput.value = userData.adresseLivraison?.rue || '';
            if (adresseVilleInput) adresseVilleInput.value = userData.adresseLivraison?.ville || '';
            if (adresseCodePostalInput) adresseCodePostalInput.value = userData.adresseLivraison?.codePostal || '';
        } else if (userData.role === 'boutique') {
            if (nomBoutiqueInput) nomBoutiqueInput.value = userData.nomBoutique || '';
            if (descriptionBoutiqueInput) descriptionBoutiqueInput.value = userData.descriptionBoutique || '';
        } else if (userData.role === 'parrain') {
            if (codePromoPersonnelInput) codePromoPersonnelInput.value = userData.codePromoPersonnel || 'N/A';
        }
    }

    /**
     * Affiche/masque les champs spécifiques au rôle.
     */
    function toggleRoleSpecificFields(role) {
        if(clientFieldsDiv) clientFieldsDiv.classList.toggle('hidden', role !== 'client');
        if(boutiqueFieldsDiv) boutiqueFieldsDiv.classList.toggle('hidden', role !== 'boutique');
        if(parrainFieldsDiv) parrainFieldsDiv.classList.toggle('hidden', role !== 'parrain');
    }

    /**
     * Affiche/masque les champs de détails de paiement en fonction du type sélectionné.
     */
    function updatePaymentFieldsVisibility(selectedPaymentType) {
        if(mobileMoneyFieldsDiv) mobileMoneyFieldsDiv.classList.toggle('hidden', selectedPaymentType !== 'mobile_money');
        if(carteBancaireFieldsDiv) carteBancaireFieldsDiv.classList.toggle('hidden', selectedPaymentType !== 'carte_bancaire');
    }
    if(typePaiementSelect) {
        typePaiementSelect.addEventListener('change', function() {
            updatePaymentFieldsVisibility(this.value);
        });
    }


    /**
     * Gère la soumission du formulaire de mise à jour du profil.
     */
    async function handleProfileUpdate(event) {
        event.preventDefault();
        showMessage('Mise à jour du profil en cours...', 'info', messageArea);
        saveProfileButton.disabled = true;
        saveProfileButton.innerHTML = `<svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Enregistrement...`;


        const payload = {
            nomComplet: nomCompletInput.value,
            telephone: telephoneInput.value,
            informationsPaiementSimulees: {
                typePaiementPrincipal: typePaiementSelect.value,
                detailsMobileMoney: typePaiementSelect.value === 'mobile_money' ? {
                    numero: mobileMoneyNumeroInput.value,
                    operateur: mobileMoneyOperateurInput.value
                } : undefined,
                detailsCarteBancaire: typePaiementSelect.value === 'carte_bancaire' ? {
                    typeCarte: carteTypeInput.value,
                    quatreDerniersChiffres: carteDerniersChiffresInput.value,
                    dateExpiration: carteDateExpirationInput.value
                } : undefined,
            }
        };

        // Ajouter les champs spécifiques au rôle au payload
        if (user.role === 'client') {
            payload.adresseLivraison = {
                rue: adresseRueInput.value,
                ville: adresseVilleInput.value,
                codePostal: adresseCodePostalInput.value,
                // pays: // Ajoutez un champ pays si besoin
            };
        } else if (user.role === 'boutique') {
            payload.nomBoutique = nomBoutiqueInput.value;
            payload.descriptionBoutique = descriptionBoutiqueInput.value;
            // ... autres champs boutique (logoUrl, horaires...)
        }
        // Le parrain n'a généralement pas de champs spécifiques à mettre à jour ici (code généré)

        const token = localStorage.getItem('authToken');
        try {
            const response = await fetch(`${API_BASE_URL}/users/me`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(payload)
            });
            const data = await response.json();

            if (response.ok && data.success) {
                showMessage('Profil mis à jour avec succès !', 'success', messageArea);
                localStorage.setItem('userData', JSON.stringify(data.user)); // Mettre à jour les données locales
                populateProfileForm(data.user); // Re-remplir avec les nouvelles données (surtout pour le solde)
                renderNavbar('profil_client'); // Rafraîchir la navbar si le nom a changé
            } else {
                showMessage(data.message || 'Erreur lors de la mise à jour.', 'error', messageArea);
            }
        } catch (error) {
            console.error("Erreur MAJ profil:", error);
            showMessage('Une erreur réseau est survenue.', 'error', messageArea);
        } finally {
            saveProfileButton.disabled = false;
            saveProfileButton.innerHTML = `<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z" clip-rule="evenodd" /></svg> Enregistrer`;
        }
    }

    if (profileForm) {
        profileForm.addEventListener('submit', handleProfileUpdate);
    }

    if (changePasswordLink) {
        changePasswordLink.addEventListener('click', () => {
            // Rediriger vers une page de changement de mot de passe dédiée ou ouvrir un modal
            alert("La fonctionnalité de changement de mot de passe doit être implémentée sur une page dédiée ou un modal, utilisant l'API /api/auth/change-password.");
            // window.location.href = '/client/changer-mot-de-passe.html'; // Page à créer
        });
    }

    // Charger les données initiales du profil
    loadUserProfile();
});