// public/js/client/orderConfirmation.js

document.addEventListener('DOMContentLoaded', function() {
    renderNavbar('commande_confirmee'); // Clé pour la navbar
    renderFooter();

    const confirmationContentDiv = document.getElementById('confirmationContent');
    const messageArea = 'messageAreaGlobal'; // Utiliser une zone de message globale si besoin

    // Récupérer l'ID de la commande depuis les paramètres de l'URL
    const urlParams = new URLSearchParams(window.location.search);
    const orderId = urlParams.get('orderId');
    const totalPaye = urlParams.get('total'); // Optionnel, si passé depuis la page panier

    function displayConfirmation() {
        if (!confirmationContentDiv) return;

        let htmlContent = `
            <div class="confirmation-icon mx-auto mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-16 h-16 text-emerald-600">
                    <path fill-rule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm13.36-1.814a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z" clip-rule="evenodd" />
                </svg>
            </div>
            <h1 class="text-3xl font-bold text-gray-900 mb-4">Merci pour votre commande !</h1>
        `;

        if (orderId) {
            htmlContent += `<p class="text-gray-700 mb-2">Votre commande simulée <strong class="text-emerald-700">#${orderId}</strong> a été enregistrée avec succès.</p>`;
            if (totalPaye) {
                 htmlContent += `<p class="text-gray-700 mb-6">Un montant total de <strong class="text-emerald-700">${parseFloat(totalPaye).toFixed(2)} FCFA</strong> a été "payé" (simulation).</p>`;
            } else {
                htmlContent += `<p class="text-gray-600 mb-6">Nous avons bien reçu les détails de votre commande simulée.</p>`;
            }
            htmlContent += `<p class="text-gray-600 mb-6">Vous recevrez bientôt une notification par email avec les détails (simulation). Vous pouvez suivre son statut dans la section "Mes Commandes" de votre profil.</p>`;
        } else {
            htmlContent += `<p class="text-gray-600 mb-6">Votre commande simulée a été enregistrée avec succès. Vous pouvez consulter vos commandes dans votre espace client.</p>`;
        }

        htmlContent += `
            <div class="mt-8 space-y-3 sm:space-y-0 sm:flex sm:justify-center sm:space-x-3">
                <a href="/catalogue.html" class="w-full sm:w-auto flex items-center justify-center px-6 py-3 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-emerald-600 hover:bg-emerald-700">
                    Continuer mes achats
                </a>
                <a href="/client/orders.html" class="w-full sm:w-auto flex items-center justify-center px-6 py-3 border border-gray-300 rounded-md shadow-sm text-base font-medium text-gray-700 bg-white hover:bg-gray-50">
                    Voir mes commandes
                </a>
            </div>
        `;
        confirmationContentDiv.innerHTML = htmlContent;
    }

    // Pour l'instant, on affiche juste un message basé sur les params URL.
    // On pourrait faire un appel API pour récupérer les vrais détails de la commande si on voulait afficher plus d'infos.
    displayConfirmation();

    // Vider le panier après confirmation (si ce n'est pas déjà fait par la page panier)
    // C'est mieux de le faire sur la page panier après la soumission réussie.
    // localStorage.removeItem('cart');
    // updateCartCounterInNav();
});