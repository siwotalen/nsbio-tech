// public/js/client/clientLayout.js

const CLIENT_NAV_ITEMS = [
    { icon: 'LayoutDashboard', label: 'Tableau de bord', href: '/client/dashboard.html', key: 'client_dashboard' },
    { icon: 'User', label: 'Mon Profil', href: '/client/profile.html', key: 'client_profile' },
    { icon: 'ShoppingCart', label: 'Mes Commandes', href: '/client/orders.html', key: 'client_orders' },
    { icon: 'Bell', label: 'Mes Notifications', href: '/client/notifications.html', key: 'client_notifications' },
    // { icon: 'Gift', label: 'Mon Parrainage', href: '/parrainage.html', key: 'client_parrainage' }, // Si un client peut aussi être parrain
    // Ajoutez d'autres liens spécifiques au client
];

// Assurez-vous que ICONS_SVG est accessible (depuis data.js ou main.js)
// Ou redéfinissez les SVG nécessaires ici. Pour cet exemple, je suppose que ICONS_SVG est global.
// const ICONS_SVG = { ... };

function renderClientSidebar(currentPageKey) {
    const sidebarDiv = document.getElementById('clientSidebar');
    const mobileMenuDiv = document.getElementById('clientMobileMenu'); // Pour les liens du menu mobile
    const pageTitleH1 = document.getElementById('pageTitle'); // Pour mettre à jour le titre de la page

    if (!sidebarDiv) {
        console.error("Élément clientSidebar non trouvé. Assurez-vous qu'il est dans votre HTML de layout.");
        return;
    }

    let sidebarLinksHtml = '';
    let pageTitle = "Espace Client"; // Titre par défaut

    CLIENT_NAV_ITEMS.forEach(item => {
        const IconSVG = ICONS_SVG && ICONS_SVG[item.icon] ? ICONS_SVG[item.icon].replace('class="lucide', 'class="lucide h-5 w-5') : `<span class="w-5 h-5 inline-block mr-3">Icon</span>`;
        const isActive = currentPageKey === item.key;
        if (isActive && pageTitleH1) pageTitle = item.label; // Mettre à jour le titre de la page

        sidebarLinksHtml += `
            <li>
                <a href="${item.href}"
                   class="flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-colors text-sm font-medium
                          ${isActive ? 'bg-emerald-50 text-emerald-700' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}">
                    ${IconSVG}
                    <span>${item.label}</span>
                </a>
            </li>
        `;
    });

    sidebarDiv.innerHTML = `
        <div class="p-4 border-b border-gray-200">
             <a href="/index.html" class="text-2xl font-bold text-emerald-600">NSBIO-TECH</a>
        </div>
        <nav class="flex-1 p-3 space-y-1">
            <ul>${sidebarLinksHtml}</ul>
        </nav>
        <div class="p-4 border-t border-gray-200">
            <button onclick="handleLogout('authToken', 'userData', '/connexion.html')" 
                    class="w-full flex items-center space-x-2 text-gray-600 hover:bg-red-50 hover:text-red-600 p-2 rounded-md transition-colors text-sm font-medium">
                ${ICONS_SVG && ICONS_SVG.LogOut ? ICONS_SVG.LogOut.replace('class="lucide', 'class="lucide h-5 w-5') : '🚪'}
                <span>Déconnexion</span>
            </button>
        </div>
    `;
    
    if (pageTitleH1) pageTitleH1.textContent = pageTitle;


    // Configuration du menu burger pour le layout client
    const clientMobileBurger = document.getElementById('clientMobileBurger');
    if (clientMobileBurger && mobileMenuDiv) {
        // Cloner les liens pour le menu mobile
        mobileMenuDiv.innerHTML = `<ul class="flex flex-col p-2 space-y-1">${sidebarLinksHtml}</ul>`;
        mobileMenuDiv.querySelectorAll('a').forEach(link => {
            link.classList.add('w-full', 'text-left');
            link.addEventListener('click', () => mobileMenuDiv.classList.add('hidden'));
        });

        clientMobileBurger.addEventListener('click', () => {
            mobileMenuDiv.classList.toggle('hidden');
        });
    }
}

// Assurez-vous que ICONS_SVG est chargé (ex: depuis data.js ou main.js)
// S'il n'est pas global, vous devrez l'importer ou le définir ici.
// Exemple: si data.js est inclus avant ce script, ICONS_SVG sera disponible.