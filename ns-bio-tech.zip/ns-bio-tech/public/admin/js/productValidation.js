// public/js/admin/productValidation.js
document.addEventListener('DOMContentLoaded', function() {
    const adminUser = protectPage('admin', 'adminAuthToken', 'adminUserData', '/admin/login.html');
    if (!adminUser) return;

    renderAdminSidebar('admin_validation'); // Clé pour la sidebar admin
    // renderFooter(); // Généralement pas de footer public dans les pages admin

    const tableContainer = document.getElementById('pendingProductsTableContainer');
    const paginationDiv = document.getElementById('validationPagination');
    const searchInput = document.getElementById('productSearchInput');
    const messageArea = 'messageAreaProductValidation';

    // Modal de rejet
    const rejectModal = document.getElementById('rejectModal');
    const rejectForm = document.getElementById('rejectForm');
    const cancelRejectButton = document.getElementById('cancelRejectButton');
    const rejectProductIdInput = document.getElementById('rejectProductId');
    const motifRejetTextarea = document.getElementById('motifRejet');

    let currentPage = 1;
    const limit = 10; // Produits par page

    async function fetchPendingProducts(page = 1, searchTerm = '') {
        tableContainer.innerHTML = '<p class="text-gray-500 p-6 text-center">Chargement des produits...</p>';
        try {
            const token = localStorage.getItem('adminAuthToken');
            const params = new URLSearchParams({
                page: page.toString(),
                limit: limit.toString(),
            });
            if (searchTerm) {
                params.append('search', searchTerm); // L'API /admin/pending doit supporter la recherche
            }

            const response = await fetch(`${API_BASE_URL}/products/admin/pending?${params.toString()}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) {
                const errData = await response.json().catch(() => ({}));
                throw new Error(errData.message || "Erreur chargement des produits en attente.");
            }
            
            const data = await response.json();

            if (data.success && data.products) {
                displayPendingProducts(data.products);
                // Utiliser la fonction de pagination globale si elle existe, sinon copier/adapter
                displayValidationPagination(data.currentPage, data.totalPages);
            } else {
                tableContainer.innerHTML = `<p class="text-gray-500 p-6 text-center">${data.message || 'Aucun produit en attente de validation.'}</p>`;
                displayValidationPagination(1,1);
            }
        } catch (error) {
            console.error("Erreur fetchPendingProducts:", error);
            showMessage(error.message, 'error', messageArea);
            tableContainer.innerHTML = `<p class="text-red-500 p-6 text-center">Erreur de chargement.</p>`;
        }
    }

    function displayPendingProducts(products) {
        if (products.length === 0) {
            tableContainer.innerHTML = '<p class="text-gray-500 p-6 text-center">Aucun produit en attente de validation pour le moment.</p>';
            return;
        }
        let tableHTML = `
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Produit</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Boutique</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Prix</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Soumis le</th>
                        <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">`;
        
        products.forEach(product => {
            tableHTML += `
                <tr id="row-${product._id}">
                    <td class="px-4 py-3 whitespace-nowrap">
                        <div class="flex items-center">
                            <div class="flex-shrink-0 h-10 w-10">
                                <img class="h-10 w-10 rounded-md object-cover" src="${product.imageUrl || 'https://via.placeholder.com/40'}" alt="${product.nom}">
                            </div>
                            <div class="ml-4">
                                <div class="text-sm font-medium text-gray-900">${product.nom}</div>
                                <div class="text-xs text-gray-500">${product.categorie || 'N/A'}</div>
                            </div>
                        </div>
                    </td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-500">${product.idVendeur ? product.idVendeur.nomBoutique || product.idVendeur.email : 'N/A'}</td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-900 font-semibold">${product.prix.toFixed(2)} FCFA</td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-500 capitalize">${product.typeElement}</td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-500">${new Date(product.createdAt).toLocaleDateString()}</td>
                    <td class="px-4 py-3 whitespace-nowrap text-center text-sm font-medium space-x-2">
                        <button data-id="${product._id}" class="approve-btn text-emerald-600 hover:text-emerald-800 font-semibold py-1 px-3 rounded-md bg-emerald-50 hover:bg-emerald-100 transition-colors">Approuver</button>
                        <button data-id="${product._id}" data-name="${product.nom}" class="reject-btn text-red-600 hover:text-red-800 font-semibold py-1 px-3 rounded-md bg-red-50 hover:bg-red-100 transition-colors">Rejeter</button>
                        <a href="/produit-detail.html?id=${product._id}&admin_preview=true" target="_blank" class="text-blue-600 hover:text-blue-800 text-xs">Voir</a>
                    </td>
                </tr>
            `;
        });
        tableHTML += `</tbody></table>`;
        tableContainer.innerHTML = tableHTML;
        addTableActionListeners();
    }

    function addTableActionListeners() {
        document.querySelectorAll('.approve-btn').forEach(button => {
            button.addEventListener('click', function() { handleApprove(this.dataset.id); });
        });
        document.querySelectorAll('.reject-btn').forEach(button => {
            button.addEventListener('click', function() { openRejectModal(this.dataset.id, this.dataset.name); });
        });
    }

    async function handleApprove(productId) {
        if (!confirm("Êtes-vous sûr de vouloir approuver ce produit ?")) return;
        showMessage('Approbation en cours...', 'info', messageArea);
        try {
            const token = localStorage.getItem('adminAuthToken');
            const response = await fetch(`${API_BASE_URL}/products/admin/${productId}/approve`, {
                method: 'PATCH',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await response.json();
            if (response.ok && data.success) {
                showMessage(data.message || 'Produit approuvé avec succès!', 'success', messageArea);
                // Supprimer la ligne du tableau ou recharger
                const row = document.getElementById(`row-${productId}`);
                if(row) row.remove();
                // fetchPendingProducts(currentPage, searchInput.value); // Optionnel: recharger
            } else {
                showMessage(data.message || "Erreur lors de l'approbation.", 'error', messageArea);
            }
        } catch (error) {
            showMessage('Erreur réseau lors de l\'approbation.', 'error', messageArea);
        }
    }

    function openRejectModal(productId, productName) {
        if(rejectProductIdInput) rejectProductIdInput.value = productId;
        if(motifRejetTextarea) motifRejetTextarea.value = ''; // Vider le textarea
        // Optionnel: Mettre le nom du produit dans le titre du modal
        const modalTitle = rejectModal.querySelector('h3');
        if(modalTitle) modalTitle.textContent = `Motif du Rejet pour "${productName}"`;
        if(rejectModal) rejectModal.classList.remove('hidden');
    }

    if(cancelRejectButton) {
        cancelRejectButton.addEventListener('click', () => {
            if(rejectModal) rejectModal.classList.add('hidden');
        });
    }
    
    if(rejectModal) { // Fermer si on clique en dehors du contenu du modal
        rejectModal.addEventListener('click', function(event) {
            if (event.target === rejectModal) {
                rejectModal.classList.add('hidden');
            }
        });
    }


    if (rejectForm) {
        rejectForm.addEventListener('submit', async function(event) {
            event.preventDefault();
            const productId = rejectProductIdInput.value;
            const motifRejet = motifRejetTextarea.value;
            if (!motifRejet.trim()) {
                alert("Veuillez fournir un motif de rejet.");
                return;
            }
            showMessage('Rejet en cours...', 'info', messageArea);
            try {
                const token = localStorage.getItem('adminAuthToken');
                const response = await fetch(`${API_BASE_URL}/products/admin/${productId}/reject`, {
                    method: 'PATCH',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify({ motifRejet })
                });
                const data = await response.json();
                if (response.ok && data.success) {
                    showMessage(data.message || 'Produit rejeté avec succès!', 'success', messageArea);
                    if(rejectModal) rejectModal.classList.add('hidden');
                    const row = document.getElementById(`row-${productId}`);
                    if(row) row.remove();
                    // fetchPendingProducts(currentPage, searchInput.value); // Optionnel: recharger
                } else {
                    showMessage(data.message || "Erreur lors du rejet.", 'error', messageArea);
                }
            } catch (error) {
                showMessage('Erreur réseau lors du rejet.', 'error', messageArea);
            }
        });
    }
    
    // Pagination (similaire à celle des commissions, à adapter/copier)
    function displayValidationPagination(currentPageNum, totalPagesNum) {
        paginationDiv.innerHTML = ''; // Vider
        if (totalPagesNum <= 1) return;
        // ... (Copiez et adaptez la logique de displayPagination de parrainCommissionsDetail.js)
        // En remplaçant les appels à fetchParrainCommissions par fetchPendingProducts(page, searchInput.value)
        // Bouton Précédent
        const prevButton = document.createElement('button'); /* ... */
        prevButton.addEventListener('click', () => fetchPendingProducts(currentPageNum - 1, searchInput.value));
        // ... etc. pour les autres boutons de pagination
    }


    if (searchInput) {
        let debounceTimer;
        searchInput.addEventListener('input', function() {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                currentPage = 1; // Reset page on new search
                fetchPendingProducts(currentPage, this.value);
            }, 500); // Debounce de 500ms
        });
    }

    // Chargement initial
    fetchPendingProducts(currentPage);
});