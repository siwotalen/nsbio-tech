// public/js/admin/commissionPayouts.js
document.addEventListener('DOMContentLoaded', function() {
    const adminUser = protectPage('admin', 'adminAuthToken', 'adminUserData', '/admin/login.html');
    if (!adminUser) return;

    renderAdminSidebar('admin_commissions'); // Clé pour la sidebar admin

    const tableContainer = document.getElementById('payoutRequestsTableContainer');
    const paginationDiv = document.getElementById('payoutPagination');
    const messageArea = 'messageAreaCommissionPayouts';

    let currentPage = 1;
    const limit = 10; // Demandes par page

    async function fetchPendingPayouts(page = 1) {
        tableContainer.innerHTML = '<p class="text-gray-500 p-6 text-center">Chargement des demandes...</p>';
        try {
            const token = localStorage.getItem('adminAuthToken');
            const params = new URLSearchParams({
                page: page.toString(),
                limit: limit.toString(),
            });

            // Utiliser l'endpoint admin qui récupère les commissions avec statut 'demandee_en_paiement'
            const response = await fetch(`${API_BASE_URL}/admin/commissions/payout-requests?${params.toString()}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) {
                const errData = await response.json().catch(() => ({}));
                throw new Error(errData.message || "Erreur chargement des demandes de paiement.");
            }
            
            const data = await response.json();

            if (data.success && data.requests) { // 'requests' est le nom de la clé dans la réponse de l'API
                displayPayoutRequests(data.requests);
                displayPayoutPagination(data.currentPage, data.totalPages);
            } else {
                tableContainer.innerHTML = `<p class="text-gray-500 p-6 text-center">${data.message || 'Aucune demande de paiement en attente.'}</p>`;
                displayPayoutPagination(1,1);
            }
        } catch (error) {
            console.error("Erreur fetchPendingPayouts:", error);
            showMessage(error.message, 'error', messageArea);
            tableContainer.innerHTML = `<p class="text-red-500 p-6 text-center">Erreur de chargement.</p>`;
        }
    }

    function displayPayoutRequests(requests) {
        if (requests.length === 0) {
            tableContainer.innerHTML = '<p class="text-gray-500 p-6 text-center">Aucune demande de paiement de commission en attente.</p>';
            return;
        }
        let tableHTML = `
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID Commission</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Parrain</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Montant</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date Demande</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Méthode Paiement (Sim.)</th>
                        <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">`;
        
        requests.forEach(commission => {
            const parrainInfo = commission.idParrain ? (commission.idParrain.nomComplet || commission.idParrain.email) : 'N/A';
            let paiementSimuleInfo = 'Non configuré';
            if (commission.idParrain && commission.idParrain.informationsPaiementSimulees) {
                const paiement = commission.idParrain.informationsPaiementSimulees;
                if (paiement.typePaiementPrincipal === 'mobile_money' && paiement.detailsMobileMoney?.numero) {
                    paiementSimuleInfo = `${paiement.detailsMobileMoney.operateur || 'Mobile Money'}: ...${paiement.detailsMobileMoney.numero.slice(-4)}`;
                } else if (paiement.typePaiementPrincipal === 'carte_bancaire' && paiement.detailsCarteBancaire?.quatreDerniersChiffres) {
                    paiementSimuleInfo = `${paiement.detailsCarteBancaire.typeCarte || 'Carte'}: ...${paiement.detailsCarteBancaire.quatreDerniersChiffres}`;
                }
            }

            tableHTML += `
                <tr id="payout-row-${commission._id}">
                    <td class="px-4 py-3 whitespace-nowrap text-xs text-gray-500">...${commission._id.slice(-8)}</td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-900">${parrainInfo}</td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm text-emerald-600 font-semibold">${commission.montantCommission.toFixed(2)} FCFA</td>
                    <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-500">${new Date(commission.dateDemandePaiement || commission.updatedAt).toLocaleDateString()}</td>
                    <td class="px-4 py-3 whitespace-nowrap text-xs text-gray-500">${paiementSimuleInfo}</td>
                    <td class="px-4 py-3 whitespace-nowrap text-center text-sm font-medium">
                        <button data-id="${commission._id}" class="approve-payout-btn text-white bg-emerald-600 hover:bg-emerald-700 font-semibold py-1.5 px-3 rounded-md text-xs transition-colors">
                            Approuver & Payer (Sim.)
                        </button>
                    </td>
                </tr>
            `;
        });
        tableHTML += `</tbody></table>`;
        tableContainer.innerHTML = tableHTML;
        addTableActionListeners();
    }

    function addTableActionListeners() {
        document.querySelectorAll('.approve-payout-btn').forEach(button => {
            button.addEventListener('click', function() { handleApprovePayout(this.dataset.id); });
        });
    }

    async function handleApprovePayout(commissionId) {
        if (!confirm("Êtes-vous sûr de vouloir approuver ce paiement de commission (simulation) ?")) return;
        
        const button = document.querySelector(`.approve-payout-btn[data-id="${commissionId}"]`);
        if(button) {
            button.disabled = true;
            button.textContent = 'Traitement...';
        }
        showMessage('Approbation du paiement en cours...', 'info', messageArea);

        try {
            const token = localStorage.getItem('adminAuthToken');
            const response = await fetch(`${API_BASE_URL}/admin/commissions/payout-requests/${commissionId}/approve`, {
                method: 'PATCH', // ou POST selon votre API
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await response.json();

            if (response.ok && data.success) {
                showMessage(data.message || 'Paiement de commission approuvé avec succès!', 'success', messageArea);
                // Mettre à jour la ligne dans le tableau ou recharger la liste
                const row = document.getElementById(`payout-row-${commissionId}`);
                if (row) {
                    // Option 1: Supprimer la ligne si elle ne doit plus apparaître
                    // row.remove();
                    // Option 2: Mettre à jour son style/contenu pour indiquer "Payée"
                    row.classList.add('opacity-50', 'bg-green-50');
                    const actionCell = row.querySelector('td:last-child');
                    if(actionCell) actionCell.innerHTML = '<span class="text-xs text-emerald-700 font-semibold">Payée</span>';
                }
                 // fetchPendingPayouts(currentPage); // Recharger la liste pour être sûr
            } else {
                showMessage(data.message || "Erreur lors de l'approbation du paiement.", 'error', messageArea);
                if(button) button.disabled = false; button.textContent = 'Approuver & Payer (Sim.)';
            }
        } catch (error) {
            showMessage('Erreur réseau lors de l\'approbation du paiement.', 'error', messageArea);
            if(button) button.disabled = false; button.textContent = 'Approuver & Payer (Sim.)';
        }
    }
    
    // Pagination (similaire à celle des commissions, à adapter/copier)
    function displayPayoutPagination(currentPageNum, totalPagesNum) {
        paginationDiv.innerHTML = '';
        if (totalPagesNum <= 1) return;
        // ... (Copiez et adaptez la logique de displayPagination de parrainCommissionsDetail.js)
        // En remplaçant les appels à fetchParrainCommissions par fetchPendingPayouts(page)
        const prevButton = document.createElement('button'); /* ... */
        prevButton.addEventListener('click', () => fetchPendingPayouts(currentPageNum - 1));
        // ... etc.
    }

    // Chargement initial
    fetchPendingPayouts(currentPage);
});