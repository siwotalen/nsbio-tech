 document.addEventListener('DOMContentLoaded', function() {
            // Pas besoin de renderNavbar() ici, ou une version admin spécifique si vous en créez une.

            const loginForm = document.getElementById('adminLoginForm');
            if (loginForm) {
                loginForm.addEventListener('submit', handleAdminLogin); // Utilise la fonction dédiée
            }

            // Si l'admin est déjà connecté, le rediriger
            const adminUser = getAuthenticatedUser('adminAuthToken', 'adminUserData');
            if(adminUser && adminUser.role === 'admin') {
                showMessage('Vous êtes déjà connecté en tant qu\'administrateur. Redirection...', 'info', 'adminLoginMessageArea');
                setTimeout(() => {
                    window.location.href = '/admin/dashboard.html';
                }, 1500);
            }
        });