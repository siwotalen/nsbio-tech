// public/js/admin/ledgerViewer.js
document.addEventListener('DOMContentLoaded', function() {
    const adminUser = protectPage('admin', 'adminAuthToken', 'adminUserData', '/admin/login.html');
    if (!adminUser) return;

    renderAdminSidebar('admin_ledger'); // Clé pour la sidebar admin

    const tableContainer = document.getElementById('ledgerTableContainer');
    const paginationDiv = document.getElementById('ledgerPagination');
    const filterForm = document.getElementById('ledgerFilterForm');
    const eventTypeFilterInput = document.getElementById('eventTypeFilter');
    const userIdFilterInput = document.getElementById('userIdFilter');
    const messageArea = 'messageAreaLedger';

    let currentPage = 1;
    const limit = 15; // Entrées par page

    async function fetchLedgerEntries(page = 1) {
        tableContainer.innerHTML = '<p class="text-gray-500 p-6 text-center">Chargement des entrées...</p>';
        try {
            const token = localStorage.getItem('adminAuthToken');
            const params = new URLSearchParams({
                page: page.toString(),
                limit: limit.toString(),
            });
            const eventType = eventTypeFilterInput.value;
            const userId = userIdFilterInput.value.trim();

            if (eventType) params.append('eventType', eventType);
            if (userId) params.append('userId', userId);


            const response = await fetch(`${API_BASE_URL}/ledger?${params.toString()}`, { // API /api/ledger
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) {
                const errData = await response.json().catch(() => ({}));
                throw new Error(errData.message || "Erreur chargement du registre.");
            }
            
            const data = await response.json();

            if (data.success && data.entries) {
                displayLedgerEntries(data.entries);
                displayLedgerPagination(data.currentPage, data.totalPages); // Utiliser displayLedgerPagination
            } else {
                tableContainer.innerHTML = `<p class="text-gray-500 p-6 text-center">${data.message || 'Aucune entrée trouvée dans le registre.'}</p>`;
                displayLedgerPagination(1,1);
            }
        } catch (error) {
            console.error("Erreur fetchLedgerEntries:", error);
            showMessage(error.message, 'error', messageArea);
            tableContainer.innerHTML = `<p class="text-red-500 p-6 text-center">Erreur de chargement.</p>`;
        }
    }

    function displayLedgerEntries(entries) {
        if (entries.length === 0) {
            tableContainer.innerHTML = '<p class="text-gray-500 p-6 text-center">Aucune entrée ne correspond à vos filtres.</p>';
            return;
        }
        let tableHTML = `
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date/Heure Évén.</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type Événement</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Données Événement</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Utilisateurs Liés</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Hash Entrée</th>
                        <th class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Hash Précédent</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">`;
        
        entries.forEach(entry => {
            const relatedUsersText = entry.relatedUserIds && entry.relatedUserIds.length > 0 ?
                entry.relatedUserIds.map(user => user ? (user.nomComplet || user.email || user._id) : 'N/A').join(', ') :
                'Aucun';

            tableHTML += `
                <tr>
                    <td class="px-3 py-3 whitespace-nowrap text-xs text-gray-500">${new Date(entry.eventTimestamp).toLocaleString()}</td>
                    <td class="px-3 py-3 whitespace-nowrap text-xs font-medium text-gray-900">${entry.eventType}</td>
                    <td class="px-3 py-3 text-xs text-gray-700"><pre class="event-data-pre">${JSON.stringify(entry.eventData, null, 2)}</pre></td>
                    <td class="px-3 py-3 whitespace-nowrap text-xs text-gray-500">${relatedUsersText}</td>
                    <td class="px-3 py-3 text-xs hash-text" title="${entry.entryHash}">${entry.entryHash.substring(0,10)}...${entry.entryHash.substring(entry.entryHash.length - 10)}</td>
                    <td class="px-3 py-3 text-xs hash-text" title="${entry.previousEntryHash}">${entry.previousEntryHash === '0' ? 'Genesis' : entry.previousEntryHash.substring(0,10)+'...'}</td>
                </tr>
            `;
        });
        tableHTML += `</tbody></table>`;
        tableContainer.innerHTML = tableHTML;
    }
    
    function displayLedgerPagination(currentPageNum, totalPagesNum) {
        paginationDiv.innerHTML = '';
        if (totalPagesNum <= 1) return;
        // ... (Copiez et adaptez la logique de displayPagination de parrainCommissionsDetail.js)
        // En remplaçant les appels à fetchParrainCommissions par fetchLedgerEntries(page)
        const prevButton = document.createElement('button'); /* ... */
        prevButton.className = 'px-3 py-1.5 mx-0.5 text-xs font-medium text-gray-600 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50';
        prevButton.disabled = currentPageNum === 1;
        prevButton.addEventListener('click', () => { currentPage = currentPageNum - 1; fetchLedgerEntries(currentPage); });
        prevButton.innerHTML = '«';
        paginationDiv.appendChild(prevButton);
        
        // Logique pour afficher les numéros de page (simplifiée)
        let startPage = Math.max(1, currentPageNum - 2);
        let endPage = Math.min(totalPagesNum, currentPageNum + 2);
        if (currentPageNum <=3) endPage = Math.min(totalPagesNum, 5);
        if (currentPageNum >= totalPagesNum - 2) startPage = Math.max(1, totalPagesNum - 4);

        if (startPage > 1) { /* ... bouton 1 et ellipsis ... */ }
        for (let i = startPage; i <= endPage; i++) {
            const pageButton = document.createElement('button'); pageButton.textContent = i;
            pageButton.className = `px-3 py-1.5 mx-0.5 text-xs font-medium border border-gray-300 rounded-md hover:bg-gray-50 ${i === currentPageNum ? 'bg-emerald-600 text-white border-emerald-600' : 'text-gray-600 bg-white'}`;
            if (i === currentPageNum) pageButton.disabled = true;
            pageButton.addEventListener('click', () => { currentPage = i; fetchLedgerEntries(currentPage); });
            paginationDiv.appendChild(pageButton);
        }
        if (endPage < totalPagesNum) { /* ... ellipsis et dernier bouton ... */ }

        const nextButton = document.createElement('button'); /* ... */
        nextButton.className = 'px-3 py-1.5 mx-0.5 text-xs font-medium text-gray-600 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50';
        nextButton.disabled = currentPageNum === totalPagesNum;
        nextButton.addEventListener('click', () => { currentPage = currentPageNum + 1; fetchLedgerEntries(currentPage); });
        nextButton.innerHTML = '»';
        paginationDiv.appendChild(nextButton);
    }

    if (filterForm) {
        filterForm.addEventListener('submit', function(event) {
            event.preventDefault();
            currentPage = 1; // Reset page on new filter
            fetchLedgerEntries(currentPage);
        });
    }

    // Chargement initial
    fetchLedgerEntries(currentPage);
});