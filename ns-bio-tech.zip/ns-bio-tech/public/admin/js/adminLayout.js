// public/js/admin/adminLayout.js

const ADMIN_NAV_ITEMS = [
    { icon: 'BarChart2', label: 'Tableau de bord', href: '/admin/dashboard.html', key: 'admin_dashboard' },
    { icon: 'Users', label: 'Utilisateurs', href: '/admin/user-management.html', key: 'admin_users' },
    { icon: 'ShoppingBag', label: 'Produits (Validation)', href: '/admin/product-validation.html', key: 'admin_validation' },
    { icon: 'Package', label: 'Commandes (Suivi)', href: '/admin/orders-overview.html', key: 'admin_orders' }, // Page à créer
    { icon: 'Gift', label: 'Paiements Commissions', href: '/admin/commission-payouts.html', key: 'admin_commissions' },
    { icon: 'MessageSquare', label: 'Messages', href: '/admin/messages.html', key: 'admin_messages' }, // Page à créer
    { icon: 'FileText', label: 'Registre (Ledger)', href: '/admin/ledger-viewer.html', key: 'admin_ledger'},
    { icon: 'Settings', label: 'Paramètres', href: '/admin/settings.html', key: 'admin_settings' } // Page à créer
];

// SVG des icônes (vous pouvez les stocker dans data.js ou ici)
const ADMIN_ICONS_SVG = {
    BarChart2: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" x2="12" y1="20" y2="10"></line><line x1="18" x2="18" y1="20" y2="4"></line><line x1="6" x2="6" y1="20" y2="16"></line></svg>',
    Users: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M22 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>',
    ShoppingBag: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"></path><path d="M3 6h18"></path><path d="M16 10a4 4 0 0 1-8 0"></path></svg>',
    Package: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="16.5" x2="7.5" y1="9.5" y2="9.5"></line><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" x2="12" y1="22.08" y2="12"></line></svg>',
    MessageSquare: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>',
    Settings: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.38a2 2 0 0 0-.73-2.73l-.15-.09a2 2 0 0 1-1-1.74v-.51a2 2 0 0 1 1-1.72l.15-.1a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path><circle cx="12" cy="12" r="3"></circle></svg>',
    FileText: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path><path d="M14 2v4a2 2 0 0 0 2 2h4"></path><path d="M10 9H8"></path><path d="M16 13H8"></path><path d="M16 17H8"></path></svg>',
    Gift: '<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 12 20 22 4 22 4 12"></polyline><rect width="20" height="5" x="2" y="7"></rect><line x1="12" x2="12" y1="22" y2="7"></line><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"></path><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"></path></svg>'
};


function renderAdminSidebar(currentPageKey) {
    const adminNavLinksDiv = document.getElementById('adminNavLinks');
    if (!adminNavLinksDiv) return;

    let navLinksHtml = '';
    ADMIN_NAV_ITEMS.forEach(item => {
        const IconSVG = ADMIN_ICONS_SVG[item.icon] || ADMIN_ICONS_SVG.BarChart2; // Fallback icon
        const isActive = currentPageKey === item.key;
        navLinksHtml += `
            <li>
                <a href="${item.href}"
                   class="flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-colors text-sm font-medium
                          ${isActive ? 'bg-emerald-50 text-emerald-700' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}">
                    ${IconSVG}
                    <span>${item.label}</span>
                </a>
            </li>
        `;
    });
    adminNavLinksDiv.innerHTML = navLinksHtml;

    // Mobile menu burger
    const adminMobileBurger = document.getElementById('adminMobileBurger');
    const adminMobileMenu = document.getElementById('adminMobileMenu');

    if (adminMobileBurger && adminMobileMenu) {
        // Cloner les liens du desktop pour le mobile menu
        const mobileNavLinksContent = adminNavLinksDiv.innerHTML;
        adminMobileMenu.innerHTML = `<ul class="flex flex-col p-2 space-y-1">${mobileNavLinksContent}</ul>`;

        adminMobileMenu.querySelectorAll('a').forEach(link => {
            link.classList.add('w-full', 'text-left'); // Assurer que les classes de base sont là
            link.addEventListener('click', () => {
                adminMobileMenu.classList.add('hidden'); // Fermer au clic
            });
        });

        adminMobileBurger.addEventListener('click', () => {
            adminMobileMenu.classList.toggle('hidden');
        });
    }
}

// Initialisation au chargement de la page si une clé est passée globalement
// (sinon, chaque page admin appellera renderAdminSidebar avec sa clé)
// document.addEventListener('DOMContentLoaded', () => {
//    if (typeof adminPageKey !== 'undefined') { // si adminPageKey est défini globalement
//        renderAdminSidebar(adminPageKey);
//    }
// });