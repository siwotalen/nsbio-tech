// public/js/admin/adminDashboard.js
document.addEventListener('DOMContentLoaded', async function() {
    const adminUser = protectPage('admin', 'adminAuthToken', 'adminUserData', '/admin/login.html');
    if (!adminUser) return;

    renderAdminSidebar('admin_dashboard'); // Appel de la fonction de layout
    // renderFooter(); // Le layout admin n'a généralement pas le même footer public

    const adminWelcomeMessage = document.getElementById('adminWelcomeMessage');
    const adminStatsGrid = document.getElementById('adminStatsGrid');
    const pendingProductsListDiv = document.getElementById('pendingProductsList');
    const pendingPayoutsListDiv = document.getElementById('pendingPayoutsList');
    const messageArea = 'messageAreaAdminDashboard';

    if (adminWelcomeMessage && adminUser.nomComplet) {
        adminWelcomeMessage.textContent = `Bienvenue, ${adminUser.nomComplet} !`;
    } else if (adminWelcomeMessage && adminUser.email) {
         adminWelcomeMessage.textContent = `Bienvenue, Admin (${adminUser.email}) !`;
    }

    // Fonction pour créer une carte de stat (inspirée de votre Admin/Dashboard.tsx)
    function createStatCard(title, value,変化, iconSvgName, colorTheme = 'emerald') {
        const IconSVG = ADMIN_ICONS_SVG[iconSvgName] || ADMIN_ICONS_SVG.BarChart2;
        let changeIndicator = '';
        if (typeof 변화 === 'number' && 변화 !== 0) {
            const arrow = 변화 > 0 ? 
                '<svg class="h-4 w-4 mr-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M4.5 10.5L12 3m0 0l7.5 7.5M12 3v18" /></svg>' : // ArrowUpRight (adapté)
                '<svg class="h-4 w-4 mr-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 13.5L12 21m0 0l-7.5-7.5M12 21V3" /></svg>'; // ArrowDownRight (adapté)
            changeIndicator = `<div class="flex items-center text-xs font-medium ${変化 > 0 ? `text-${colorTheme}-600` : 'text-red-600'}">${arrow}<span>${Math.abs(変化)}%</span></div>`;
        } else if (typeof 변화 === 'string'){
             changeIndicator = `<div class="flex items-center text-xs font-medium text-gray-500"><span>${変化}</span></div>`;
        }


        return `
            <div class="bg-white p-5 rounded-xl shadow-sm border border-gray-100">
                <div class="flex justify-between items-start">
                    <div>
                        <p class="text-sm text-gray-500">${title}</p>
                        <h3 class="text-2xl font-bold text-gray-900 mb-1">${value}</h3>
                        ${changeIndicator}
                    </div>
                    <div class="bg-${colorTheme}-100 p-3 rounded-lg">
                        ${IconSVG.replace('class="h-5 w-5"', `class="h-6 w-6 text-${colorTheme}-600"`)}
                    </div>
                </div>
            </div>
        `;
    }
    
    async function loadDashboardStats() {
        // Vider les placeholders
        if(adminStatsGrid) adminStatsGrid.innerHTML = '';

        // Ces appels API sont des exemples, vous devrez créer ces endpoints agrégés côté backend
        // Ou faire plusieurs appels et combiner les données.
        // Pour le proto, on peut mettre des données factices.
        
        // Exemple de données factices
        const stats = [
            { title: "Utilisateurs Total", value: "125", change: "+5 nouveaux", icon: "Users", theme: "purple" },
            { title: "Produits Actifs", value: "78", change: "+2 en validation", icon: "ShoppingBag", theme: "blue" },
            { title: "Commandes (30j)", value: "210", change: "5.2%", icon: "Package", theme: "amber" },
            { title: "Revenu (30j)", value: "12,345 FCFA", change: "8.1%", icon: "BarChart2", theme: "emerald" }
        ];

        stats.forEach(stat => {
            if(adminStatsGrid) adminStatsGrid.insertAdjacentHTML('beforeend', createStatCard(stat.title, stat.value, stat.change, stat.icon, stat.theme));
        });

        // Charger un aperçu des produits en attente
        if (pendingProductsListDiv) {
            pendingProductsListDiv.innerHTML = '<p class="text-xs text-gray-500">Chargement...</p>';
            try {
                const token = localStorage.getItem('adminAuthToken');
                const response = await fetch(`${API_BASE_URL}/admin/products/pending?limit=3`, {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                const data = await response.json();
                if (data.success && data.products) {
                    if (data.products.length > 0) {
                        let listHtml = '<ul class="space-y-3">';
                        data.products.forEach(p => {
                            listHtml += `<li class="text-sm text-gray-700 p-2 bg-gray-50 rounded-md"><strong>${p.nom}</strong> par ${p.idVendeur.nomBoutique || 'N/A'}</li>`;
                        });
                        listHtml += '</ul>';
                        pendingProductsListDiv.innerHTML = listHtml;
                    } else {
                        pendingProductsListDiv.innerHTML = '<p class="text-sm text-gray-500">Aucun produit en attente.</p>';
                    }
                } else {
                     pendingProductsListDiv.innerHTML = '<p class="text-sm text-red-500">Erreur chargement.</p>';
                }
            } catch (e) { pendingProductsListDiv.innerHTML = '<p class="text-sm text-red-500">Erreur réseau.</p>'; }
        }
        // Charger un aperçu des demandes de paiement
        if (pendingPayoutsListDiv) {

        
            // pendingPayoutsListDiv.innerHTML = '<p class="text-xs text-gray-500">Chargement...</p>';
            // try {
            //     const token = localStorage.getItem('adminAuthToken');
            //     console.log("ADMIN DASHBOARD: Token utilisé pour API:", token); // <<--- AJOUTER CE LOG
            //     const response = await fetch(`${API_BASE_URL}/products/admin/pending?limit=3`, {
            //         headers: { 'Authorization': `Bearer ${token}` }
            //     });
            //     const data = await response.json();
            //     if (data.success && data.products) {
            //         if (data.products.length > 0) {
            //             let listHtml = '<ul class="space-y-3">';
            //             data.products.forEach(p => {
            //                 listHtml += `<li class="text-sm text-gray-700 p-2 bg-gray-50 rounded-md"><strong>${p.nom}</strong> par ${p.idVendeur.nomBoutique || 'N/A'}</li>`;
            //             });
            //             listHtml += '</ul>';
            //             pendingPayoutsListDiv.innerHTML = listHtml;
            //         } else {
            //             pendingPayoutsListDiv.innerHTML = '<p class="text-sm text-gray-500">Aucun produit en attente.</p>';
            //         }
            //     } else {
            //          pendingPayoutsListDiv.innerHTML = '<p class="text-sm text-red-500">Erreur chargement.</p>';
            //     }
            // } catch (e) { pendingPayoutsListDiv.innerHTML = '<p class="text-sm text-red-500">Erreur réseau.</p>'; }
        }
         }

    loadDashboardStats();
});