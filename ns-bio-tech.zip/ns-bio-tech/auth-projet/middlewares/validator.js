// middlewares/validator.js
const Joi = require('joi');

// Schéma de base pour email et mot de passe
const baseAuthSchema = {
    email: Joi.string()
        .email({ tlds: { allow: ['com', 'net'] } }) // Adaptez les TLDs si besoin
        .min(6)
        .max(60)
        .required()
        .messages({
            'string.empty': 'L\'email est requis',
            'string.email': 'Email invalide',
            'string.min': 'L\'email doit contenir au moins 6 caractères',
            'string.max': 'L\'email ne peut pas dépasser 60 caractères',
        }),
    password: Joi.string()
        .min(6) // Simplifié pour le proto, vous aviez un pattern plus strict que vous pouvez remettre
        .max(30)
        .required()
        .messages({
            'string.empty': 'Le mot de passe est requis',
            'string.min': 'Le mot de passe doit contenir au moins 6 caractères',
            'string.max': 'Le mot de passe ne peut pas dépasser 30 caractères',
        }),
};

// Schéma pour l'inscription
exports.signupSchema = Joi.object({
    ...baseAuthSchema,
    role: Joi.string().valid('client', 'parrain', 'boutique', 'admin').required().messages({
        'any.required': 'Le rôle est requis',
        'any.only': 'Le rôle doit être client, parrain, ou boutique',
    }),
    // Champs Client
    nomComplet: Joi.when('role', {
        is: Joi.string().valid('client', 'parrain', 'admin'),
        then: Joi.string().min(2).max(100).required().messages({
            'string.empty': 'Le nom complet est requis pour ce rôle.',
            'string.min': 'Le nom complet doit avoir au moins 2 caractères.',
            'any.only': 'Le rôle doit être client, parrain, boutique, ou admin',
        }),
        otherwise: Joi.optional(),
    }),
    telephone: Joi.when('role', { // Optionnel pour client et parrain
        is: Joi.string().valid('client', 'parrain', 'admin'),
        then: Joi.string().pattern(/^[0-9+\-\s()]*$/).min(8).max(20).optional().messages({ // Adaptez le pattern
            'string.pattern.base': 'Numéro de téléphone invalide.',
            'any.only': 'Le rôle doit être client, parrain, boutique, ou admin',
        }),
        otherwise: Joi.optional(),
    }),
    
    // --- Champs spécifiques au Client ---
    codeParrainSaisi: Joi.when('role', { // <<--- VALIDATION IMPORTANTE
        is: 'client', // S'applique uniquement si le rôle est 'client'
        then: Joi.string().trim().min(3).max(20).optional().messages({ // Optionnel et peut être vide
             'string.min': 'Le code parrain doit avoir au moins 3 caractères.',
             'string.max': 'Le code parrain ne peut pas dépasser 20 caractères.',
             'string.empty': 'Le code parrain est requis pour continuer.',
        }),
        otherwise: Joi.optional(), // Non applicable pour les autres rôles
    }),
    // adresseLivraison: Joi.when('role', { is: 'client', then: Joi.object(...), otherwise: Joi.optional()}), // À détailler si besoin

    // Champs Boutique
    nomBoutique: Joi.when('role', {
        is: 'boutique',
        then: Joi.string().min(2).max(100).required().messages({
            'string.empty': 'Le nom de la boutique est requis.',
             'string.min': 'Le nom de la boutique doit avoir au moins 2 caractères.',
        }),
        otherwise: Joi.optional(),
    }),
    descriptionBoutique: Joi.when('role', {
        is: 'boutique',
        then: Joi.string().min(10).max(500).optional().messages({
            'string.min': 'La description doit avoir au moins 10 caractères.',
        }),
        otherwise: Joi.optional(),
    }),
    // coordonneesBoutique: Joi.when('role', {is: 'boutique', then: Joi.object(...).required(), otherwise: Joi.optional()}), // À détailler

    // Champs Parrain
    codePromoPersonnel: Joi.when('role', { // Permettre au parrain de proposer un code, sinon il sera généré
        is: 'parrain',
        then: Joi.string().trim().alphanum().min(5).max(15).optional().messages({
            'string.min': 'Le code promo personnel doit avoir au moins 5 caractères alphanumériques.',
            'string.alphanum': 'Le code promo personnel ne doit contenir que des lettres et des chiffres.',
        }),
        otherwise: Joi.optional(),
    }),
    // ... autres champs optionnels ou requis selon le rôle
});


exports.signinSchema = Joi.object({
    email: baseAuthSchema.email,
    password: baseAuthSchema.password,
});

// ... vos autres schémas (accepCodeSchema, changePasswordSchema, etc.) restent valables
// Assurez-vous que les messages d'erreur sont pertinents
exports.accepCodeSchema = Joi.object({
    email: baseAuthSchema.email,
    providedCode: Joi.string() // Le code est souvent une chaîne de chiffres
        .length(6) // Si vos codes ont toujours 6 chiffres
        .pattern(/^[0-9]+$/)
        .required()
        .messages({
            'string.base': 'Le code de vérification doit être une chaîne de chiffres.',
            'string.length': 'Le code de vérification doit comporter 6 chiffres.',
            'string.pattern.base': 'Le code de vérification doit être numérique.',
            'any.required': 'Le code de vérification est requis',
        }),
});

exports.changePasswordSchema = Joi.object({
    oldpassword: baseAuthSchema.password.label("Ancien mot de passe"), // Ajouter .label() pour de meilleurs messages
    newpassword: baseAuthSchema.password.label("Nouveau mot de passe")
        .invalid(Joi.ref('oldpassword')) // S'assurer que le nouveau est différent de l'ancien
        .messages({
            'any.invalid': 'Le nouveau mot de passe doit être différent de l\'ancien.',
            // ... autres messages spécifiques pour newpassword si besoin
        }),
});

exports.acceptFPSchema = Joi.object({
    email: baseAuthSchema.email,
    providedCode: exports.accepCodeSchema.extract('providedCode'), // Réutiliser la validation du code
    newpassword: baseAuthSchema.password.label("Nouveau mot de passe"),
});

