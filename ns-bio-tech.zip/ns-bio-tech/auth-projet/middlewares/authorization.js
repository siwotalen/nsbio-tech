// middlewares/authorization.js
exports.checkRole = (roles) => {
    return (req, res, next) => {
        // Le middleware 'identifier' doit avoir été exécuté avant pour avoir req.user
        if (!req.user || !req.user.role) {
            return res.status(401).json({ success: false, message: 'Accès non autorisé. Token manquant ou information de rôle invalide.' });
        }

        // Vérifie si le rôle de l'utilisateur est dans la liste des rôles autorisés
        if (!Array.isArray(roles)) { // Au cas où on passe une chaîne au lieu d'un tableau
            roles = [roles];
        }

        if (!roles.includes(req.user.role)) {
            return res.status(403).json({ success: false, message: 'Accès refusé. Vous n\'avez pas les permissions nécessaires pour cette action.' });
        }
        next(); // L'utilisateur a le bon rôle, continuer
    };
};