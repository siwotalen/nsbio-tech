// utils/notificationManager.js
const Notification = require('../models/notificationModel');
const User = require('../models/usersModel'); // Pour trouver les admins
const transport = require('../middlewares/sendMail');
const mongoose = require('mongoose'); 

/**
 * Crée et sauvegarde une notification en base de données.
 * Simule également l'envoi (pour l'instant via console.log).
 *
 * @param {mongoose.Types.ObjectId} idUtilisateurDestinataire L'ID de l'utilisateur.
 * @param {String} typeNotification Le type de notification (cf. enum du modèle).
 * @param {String} message Le message principal.
 * @param {String} [titre] Le titre optionnel.
 * @param {String} [lienInterne] Un lien interne dans l'application.
 * @param {Object} [metadata] Des données supplémentaires.
 */
async function createNotification(idUtilisateurDestinataire, typeNotification, message, titre = '', lienInterne = '', metadata = {}) {
    try {
        if (!idUtilisateurDestinataire) {
            console.warn("NOTIFICATION_MANAGER: Tentative de création de notification sans idUtilisateurDestinataire.", { typeNotification, message });
            return null;
        }

        const notification = new Notification({
            idUtilisateurDestinataire,
            typeNotification,
            titre: titre || generateDefaultTitle(typeNotification), // Générer un titre par défaut si non fourni
            message,
            lienInterne,
            metadata
        });
        await notification.save();

        // Simulation de l'envoi (email, push, etc.)
        console.log(`---- NOUVELLE NOTIFICATION ----`);
        console.log(`Pour: User ID ${idUtilisateurDestinataire}`);
        console.log(`Type: ${typeNotification}`);
        if (titre) console.log(`Titre: ${titre}`);
        console.log(`Message: ${message}`);
        if (lienInterne) console.log(`Lien: ${lienInterne}`);
        if (Object.keys(metadata).length > 0) console.log(`Metadata: ${JSON.stringify(metadata)}`);
        console.log(`-----------------------------`);
        

         // --- ENVOI D'EMAIL ---
         const titreNotif = titre || generateDefaultTitle(typeNotification);
         const destinataire = await User.findById(idUtilisateurDestinataire).select('email nomComplet');
         if (destinataire && destinataire.email) {
             // Construire le contenu de l'email
             // Vous pouvez créer des templates HTML plus sophistiqués pour différents types de notifications
             const emailHtml = `
                 <h1>${titreNotif}</h1>
                 <p>Bonjour ${destinataire.nomComplet || 'Utilisateur'},</p>
                 <p>${message}</p>
                 ${lienInterne ? `<p><a href="${process.env.FRONTEND_URL || 'http://localhost:8000'}${lienInterne}">Voir les détails</a></p>` : ''}
                 <p>Cordialement,<br>L'équipe NSBIO-TECH</p>
             `;
 
             const mailOptions = {
                 from: `"NSBIO-TECH" <${process.env.NODE_CODE_SENDING_EMAIL_ADDRESS}>`,
                 to: destinataire.email,
                 subject: `NSBIO-TECH: ${titreNotif}`,
                 html: emailHtml
             };
 
             try {
                 let info = await transport.sendMail(mailOptions);
                 console.log(`NOTIFICATION_MANAGER: Email de notification envoyé à ${destinataire.email}. Message ID: ${info.messageId}`);
             } catch (emailError) {
                 console.error(`NOTIFICATION_MANAGER ERREUR: Impossible d'envoyer l'email de notification à ${destinataire.email}`, emailError);
             }
         } else {
             console.warn(`NOTIFICATION_MANAGER: Email non envoyé pour la notification ID ${notification._id}, utilisateur ou email non trouvé.`);
         }
         // --- FIN ENVOI D'EMAIL ---
        // Ici, vous ajouteriez la logique pour l'envoi réel via email, push, etc.
        // Ex: await sendEmailNotification(idUtilisateurDestinataire, titre, message, lienInterne);
        // Ex: await sendPushNotification(idUtilisateurDestinataire, titre, message, lienInterne);

        return notification;
    } catch (error) {
        console.error("NOTIFICATION_MANAGER ERREUR: Impossible de créer la notification.", error, { idUtilisateurDestinataire, typeNotification, message });
        return null; // Ou rejeter l'erreur si critique
    }
}

/**
 * Crée et sauvegarde des notifications pour tous les administrateurs.
 */
async function createAdminNotification(typeNotification, message, titre = '', lienInterne = '', metadata = {}) {
    try {
        const admins = await User.find({ role: 'admin' }).select('_id');
        if (admins.length === 0) {
            console.warn("NOTIFICATION_MANAGER: Aucun admin trouvé pour envoyer la notification de type", typeNotification);
            return;
        }
      

        const notificationsPromises = admins.map(admin => {
            return createNotification(admin._id, typeNotification, message, titreNotif, lienInterne, metadata);
        });


        await Promise.all(notificationsPromises);
        console.log(`NOTIFICATION_MANAGER: Notifications de type '${typeNotification}' envoyées à ${admins.length} admin(s).`);

    } catch (error) {
        console.error("NOTIFICATION_MANAGER ERREUR: Impossible d'envoyer la notification aux admins.", error);
    }
}
function generateDefaultTitle(typeNotification) {
    switch (typeNotification) {
        case 'BIENVENUE': return 'Bienvenue chez NSBIO-TECH !';
        case 'COMMANDE_RECUE_CLIENT': return 'Votre Commande NSBIO-TECH a été Reçue';
        case 'COMMANDE_RECUE_BOUTIQUE': return 'Nouvelle Commande sur Votre Boutique';
        case 'COMMISSION_GENEREE_PARRAIN': return 'Nouvelle Commission Gagnée !';
        case 'PRODUIT_SOUMIS_BOUTIQUE': return 'Votre Produit est en cours de Validation';
        case 'PRODUIT_VALIDATION_ADMIN': return 'Nouveau Produit à Valider';
        case 'PRODUIT_APPROUVE_BOUTIQUE': return 'Bonne Nouvelle ! Votre Produit a été Approuvé';
        case 'PRODUIT_REJETE_BOUTIQUE': return 'Information Concernant Votre Produit';
        case 'COMMANDE_STATUT_MAJ_CLIENT': return 'Mise à Jour du Statut de Votre Commande';
        case 'ABONNEMENT_MAJ_BOUTIQUE': return 'Mise à Jour de Votre Abonnement';
        case 'DEMANDE_PAIEMENT_COMMISSION_PARRAIN': return 'Demande de Paiement de Commissions Soumise';
        case 'DEMANDE_PAIEMENT_COMMISSION_ADMIN': return 'Nouvelle Demande de Paiement de Commission';
        case 'PAIEMENT_COMMISSION_EFFECTUE_PARRAIN': return 'Vos Commissions Ont Été Payées !';
        default: return 'Notification Importante de NSBIO-TECH';
    }
}

module.exports = { createNotification, createAdminNotification };