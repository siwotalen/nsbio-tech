// utils/ledgerLogger.js
const LedgerEntry = require('../models/ledgerEntryModel');

/**
 * Enregistre un événement dans le registre simulé.
 * @param {string} eventType - Le type d'événement (ex: 'COMMANDE_SIMULEE').
 * @param {object} eventData - Les données spécifiques à l'événement.
 * @param {Array<mongoose.Types.ObjectId>} [relatedUserIds=[]] - Tableau des IDs des utilisateurs liés.
 */
async function logLedgerEvent(eventType, eventData, relatedUserIds = []) {
    try {
        const newEntry = new LedgerEntry({
            eventType,
            eventData,
            relatedUserIds: relatedUserIds.filter(id => id) // Filtrer les IDs nuls/undefined
        });
        // Le hook pre-validate s'occupera de previousEntryHash et entryHash
        await newEntry.save();
        console.log(`REGISTRE: Événement '${eventType}' enregistré avec hash ${newEntry.entryHash}`);
        return newEntry;
    } catch (error) {
        console.error(`REGISTRE ERREUR: Impossible d'enregistrer l'événement '${eventType}'.`, error);
        // Gérer l'erreur (ex: la logguer, mais ne pas bloquer le flux principal si ce n'est pas critique pour le proto)
        // throw error; // Ou rejeter l'erreur si l'enregistrement au registre est critique
    }
}

module.exports = { logLedgerEvent };