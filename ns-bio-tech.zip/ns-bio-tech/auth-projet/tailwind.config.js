/** @type {import('tailwindcss').Config} */
module.exports = { // Ou `export default {` si votre projet est configuré pour les modules ES
  content: [
    "../public/**/*.html",   // Scanne TOUS les fichiers HTML dans public et ses sous-dossiers
    "../public/**/*.js",
     "../public/admin/**/*.html",
    "../public/admin/js/**/*.js", 
         // Scanne aussi les fichiers JS au cas où vous ajouteriez des classes dynamiquement
  ],
  theme: {
    extend: {
      // REPRENEZ VOTRE PALETTE DE COULEURS ET VOS POLICES ICI
      // C'est ici que vous vous assurez que les couleurs comme 'emerald-600' etc.
      // correspondent à ce que vous aviez dans votre projet React.
      // Si vous utilisiez les couleurs par défaut de Tailwind dans React,
      // elles seront disponibles ici aussi par défaut.
      // Si vous aviez des couleurs personnalisées dans le theme.extend de votre config React/Tailwind,
      // reproduisez-les ici.
      colors: {
        // Exemple pour matcher votre Connexion.tsx:
        emerald: { // Si vous voulez utiliser directement 'bg-emerald-600', etc.
          50: '#ecfdf5',
          100: '#d1fae5',
          200: '#a7f3d0',
          300: '#6ee7b7',
          400: '#34d399',
          500: '#10b981',
          600: '#059669',
          700: '#047857',
          800: '#065f46',
          900: '#064e3b',
        },
        gray: {
          50: '#f9fafb',
          100: '#f3f4f6',
          200: '#e5e7eb', // Bordure des inputs
          400: '#9ca3af', // Couleur des icônes placeholder
          600: '#4b5563', // Texte secondaire
          700: '#374151', // Texte des labels
          900: '#111827', // Titre principal
        }
        // Vous pouvez aussi définir des alias :
        // 'nsbio-primary': '#059669', // => utilisable avec bg-nsbio-primary
      },
      fontFamily: {
        // Si vous utilisiez une police spécifique (ex: Roboto)
        // sans: ['Roboto', 'ui-sans-serif', 'system-ui', /* ...autres fallbacks */],
      },
    },
  },
  plugins: [
    // Si vos maquettes React utilisaient des plugins Tailwind (ex: @tailwindcss/forms pour styler les formulaires plus facilement)
    // vous devriez les installer (npm install -D @tailwindcss/forms) et les ajouter ici:
    // require('@tailwindcss/forms'),
  ],
}