// controllers/boutiqueController.js
const User = require('../models/usersModel'); // Le modèle User contient les infos de la boutique
const Joi = require('joi');
const mongoose = require('mongoose');

// Schéma Joi pour la validation d'un point de retrait
const pointRetraitValidationSchema = Joi.object({
    nom: Joi.string().min(3).max(100).required().messages({
        'string.empty': 'Le nom du point de retrait est requis.',
        'string.min': 'Le nom doit avoir au moins 3 caractères.'
    }),
    adresse: Joi.string().min(5).max(200).required().messages({
        'string.empty': 'L\'adresse est requise.',
        'string.min': 'L\'adresse doit avoir au moins 5 caractères.'
    }),
    ville: Joi.string().min(2).max(100).optional().allow(''),
    instructionsSupplementaires: Joi.string().max(500).optional().allow(''),
    horairesOuverture: Joi.string().max(200).optional().allow('')
});

// --- Fonctions pour gérer les points de retrait de la boutique connectée ---

// Récupérer tous les points de retrait de la boutique connectée
exports.getMesPointsDeRetrait = async (req, res) => {
    try {
        const boutiqueId = req.user.userId; // Vient du token
        const boutique = await User.findById(boutiqueId).select('pointsDeRetrait nomBoutique');

        if (!boutique || boutique.role !== 'boutique') {
            return res.status(404).json({ success: false, message: 'Compte boutique non trouvé.' });
        }

        res.status(200).json({
            success: true,
            nomBoutique: boutique.nomBoutique,
            pointsDeRetrait: boutique.pointsDeRetrait || []
        });
    } catch (error) {
        console.error("Erreur getMesPointsDeRetrait:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};

// Ajouter un nouveau point de retrait
exports.addPointDeRetrait = async (req, res) => {
    try {
        const boutiqueId = req.user.userId;
        const { error, value: pointData } = pointRetraitValidationSchema.validate(req.body);

        if (error) {
            return res.status(400).json({ success: false, message: error.details[0].message });
        }

        const boutique = await User.findById(boutiqueId);
        if (!boutique || boutique.role !== 'boutique') {
            return res.status(404).json({ success: false, message: 'Compte boutique non trouvé.' });
        }

        // Limite de points de retrait (optionnel, peut dépendre de l'abonnement)
        // const MAX_POINTS_RETRAIT = 5; // Exemple
        // if (boutique.pointsDeRetrait.length >= MAX_POINTS_RETRAIT) {
        //     return res.status(403).json({ success: false, message: `Limite de ${MAX_POINTS_RETRAIT} points de retrait atteinte.` });
        // }

        boutique.pointsDeRetrait.push(pointData); // Ajoute le nouveau point au tableau
        await boutique.save();

        // Renvoyer le dernier point ajouté (celui avec le _id généré)
        const nouveauPoint = boutique.pointsDeRetrait[boutique.pointsDeRetrait.length - 1];

        res.status(201).json({
            success: true,
            message: 'Point de retrait ajouté avec succès.',
            pointDeRetrait: nouveauPoint
        });
    } catch (error) {
        console.error("Erreur addPointDeRetrait:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};

// Mettre à jour un point de retrait existant
exports.updatePointDeRetrait = async (req, res) => {
    try {
        const boutiqueId = req.user.userId;
        const { pointId } = req.params; // ID du sous-document point de retrait
        const { error, value: pointData } = pointRetraitValidationSchema.validate(req.body);

        if (error) {
            return res.status(400).json({ success: false, message: error.details[0].message });
        }
        if (!mongoose.Types.ObjectId.isValid(pointId)) {
            return res.status(400).json({ success: false, message: 'ID de point de retrait invalide.' });
        }

        const boutique = await User.findById(boutiqueId);
        if (!boutique || boutique.role !== 'boutique') {
            return res.status(404).json({ success: false, message: 'Compte boutique non trouvé.' });
        }

        const point = boutique.pointsDeRetrait.id(pointId); // Trouve le sous-document par son _id
        if (!point) {
            return res.status(404).json({ success: false, message: 'Point de retrait non trouvé.' });
        }

        // Mettre à jour les champs du point de retrait
        point.set(pointData); // .set() est une méthode Mongoose pour mettre à jour les champs d'un sous-document
        await boutique.save();

        res.status(200).json({
            success: true,
            message: 'Point de retrait mis à jour avec succès.',
            pointDeRetrait: point // Renvoyer le point mis à jour
        });
    } catch (error) {
        console.error("Erreur updatePointDeRetrait:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};

// Supprimer un point de retrait
exports.deletePointDeRetrait = async (req, res) => {
    try {
        const boutiqueId = req.user.userId;
        const { pointId } = req.params;

        if (!mongoose.Types.ObjectId.isValid(pointId)) {
            return res.status(400).json({ success: false, message: 'ID de point de retrait invalide.' });
        }

        const boutique = await User.findById(boutiqueId);
        if (!boutique || boutique.role !== 'boutique') {
            return res.status(404).json({ success: false, message: 'Compte boutique non trouvé.' });
        }

        const point = boutique.pointsDeRetrait.id(pointId);
        if (!point) {
            return res.status(404).json({ success: false, message: 'Point de retrait non trouvé.' });
        }
        
        // Supprimer le sous-document en utilisant la méthode pull de Mongoose sur le tableau
        boutique.pointsDeRetrait.pull({ _id: pointId });
        // Alternativement, si vous avez l'objet 'point' : point.remove(); mais pull est souvent utilisé pour les tableaux.
        // En fait, point.deleteOne() est la méthode moderne si `point` est une instance de sous-document Mongoose.
        // `boutique.pointsDeRetrait.id(pointId).deleteOne();` pourrait aussi fonctionner.
        // Le plus sûr est d'utiliser pull pour enlever l'élément du tableau.

        await boutique.save();

        res.status(200).json({
            success: true,
            message: 'Point de retrait supprimé avec succès.'
        });
    } catch (error) {
        console.error("Erreur deletePointDeRetrait:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};