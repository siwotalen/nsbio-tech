// controllers/userController.js
const User = require('../models/usersModel');
const Joi = require('joi');
const mongoose = require('mongoose'); // Utile pour la validation d'ObjectId
const Commission = require('../models/commissionModel'); 
const { logLedgerEvent } = require('../utils/ledgerLogger');
const Notification = require('../models/notificationModel');


// Schéma Joi pour la mise à jour du profil (sera utilisé plus tard)
// On ne permet pas de changer l'email, le rôle ou le mot de passe via cette route.
// Pour le mot de passe, on utilisera la route dédiée dans authController.
const updateUserProfileSchema = Joi.object({
    nomComplet: Joi.string().min(2).max(100).optional().allow(''),
    telephone: Joi.string().pattern(/^[0-9+\-\s()]*$/).min(8).max(20).optional().allow(''), // Adaptez pattern
     // --- AJOUT POUR INFORMATIONS DE PAIEMENT SIMULÉES ---
     informationsPaiementSimulees: Joi.object({
        typePaiementPrincipal: Joi.string().valid('non_configure', 'mobile_money', 'carte_bancaire', 'paypal_simule').optional(),
        detailsMobileMoney: Joi.object({
            numero: Joi.string().pattern(/^[+0-9\s()-]*$/).optional().allow(''), // Pattern large pour numéros
            operateur: Joi.string().optional().allow('')
        }).optional(),
        detailsCarteBancaire: Joi.object({
            typeCarte: Joi.string().optional().allow(''),
            quatreDerniersChiffres: Joi.string().length(4).pattern(/^[0-9]+$/).optional().allow(''),
            dateExpiration: Joi.string().pattern(/^(0[1-9]|1[0-2])\/?([0-9]{2})$/).optional().allow('') // MM/YY
        }).optional(),
        // soldeCompteSimule n'est généralement pas modifiable par l'utilisateur via son profil
    }).optional(),
    // --- FIN AJOUT PAIEMENT ---
    // Champs spécifiques Client (adresse par exemple)
    adresseLivraison: Joi.object({
        rue: Joi.string().optional().allow(''),
        ville: Joi.string().optional().allow(''),
        codePostal: Joi.string().optional().allow(''),
        pays: Joi.string().optional().allow(''),
    }).optional(),

    // Champs spécifiques Boutique
    nomBoutique: Joi.string().min(2).max(100).optional().allow(''),
    descriptionBoutique: Joi.string().min(10).max(500).optional().allow(''),
    logoUrlBoutique: Joi.string().uri().optional().allow(''),
    coordonneesBoutique: Joi.object({
        adressePrincipale: Joi.string().optional().allow(''),
        ville: Joi.string().optional().allow(''),
        pays: Joi.string().optional().allow(''),
        telephoneBoutique: Joi.string().pattern(/^[0-9+\-\s()]*$/).min(8).max(20).optional().allow(''),
    }).optional(),
    horairesOuvertureBoutique: Joi.string().optional().allow(''),

    // Un parrain ne met généralement pas à jour son code promo personnel via son profil
    // Il est généré ou défini à la création.
});

// Schéma Joi pour la demande de paiement de commissions
const requestCommissionPayoutSchema = Joi.object({
    // Pour le prototype, on peut demander le paiement de TOUTES les commissions validées
    // Ou permettre de spécifier des IDs de commissions
    commissionIds: Joi.array().items(Joi.string().hex().length(24)).min(1).optional().messages({
        'array.min': 'Vous devez sélectionner au moins une commission.',
        'string.hex': 'L\'ID de commission doit être une chaîne hexadécimale valide.',
        'string.length': 'L\'ID de commission doit comporter 24 caractères.'
    }),
    // On pourrait aussi demander le moyen de paiement souhaité par le parrain ici,
    // mais pour le proto, on suppose que c'est géré hors bande ou via son profil.
});

exports.getMyProfile = async (req, res) => {
    try {
        const userId = req.user.userId; // Vient du token via le middleware 'identifier'

        // Sélectionner les champs à retourner, exclure les sensibles
        // Le modèle User a déjà 'select: false' pour password, verificationCode etc.
        // Donc un findById simple devrait suffire, mais on peut être explicite.
        const user = await User.findById(userId)
            .select('-password -verificationCode -verificationCodeValidation -forgotPasswordCode -forgotPasswordCodeValidation');

        if (!user) {
            return res.status(404).json({ success: false, message: 'Utilisateur non trouvé.' });
        }

        res.status(200).json({ success: true, user });
    } catch (error) {
        console.error("Erreur getMyProfile:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur lors de la récupération du profil.', error: error.message });
    }
};

exports.updateMyProfile = async (req, res) => {
    try {
        const userId = req.user.userId;
        const userRole = req.user.role; // Utile pour valider quels champs peuvent être mis à jour

        const { error, value } = updateUserProfileSchema.validate(req.body);
        if (error) {
            return res.status(400).json({ success: false, message: error.details[0].message });
        }

        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ success: false, message: 'Utilisateur non trouvé.' });
        }

        // Appliquer les mises à jour en fonction du rôle
        // On ne met à jour que les champs pertinents pour le rôle de l'utilisateur
        // et ceux présents dans 'value' (données validées)

        if (value.nomComplet !== undefined) user.nomComplet = value.nomComplet;
        if (value.telephone !== undefined) user.telephone = value.telephone;

         // Mise à jour des informations de paiement simulées
         if (value.informationsPaiementSimulees) {
            if (!user.informationsPaiementSimulees) { // Initialiser si n'existe pas
                user.informationsPaiementSimulees = {};
            }
            const paiementInput = value.informationsPaiementSimulees;
            if (paiementInput.typePaiementPrincipal !== undefined) {
                user.informationsPaiementSimulees.typePaiementPrincipal = paiementInput.typePaiementPrincipal;
            }
            if (paiementInput.detailsMobileMoney) {
                 user.informationsPaiementSimulees.detailsMobileMoney = {
                    numero: paiementInput.detailsMobileMoney.numero || user.informationsPaiementSimulees.detailsMobileMoney?.numero,
                    operateur: paiementInput.detailsMobileMoney.operateur || user.informationsPaiementSimulees.detailsMobileMoney?.operateur
                 };
            }
            if (paiementInput.detailsCarteBancaire) {
                 user.informationsPaiementSimulees.detailsCarteBancaire = {
                    typeCarte: paiementInput.detailsCarteBancaire.typeCarte || user.informationsPaiementSimulees.detailsCarteBancaire?.typeCarte,
                    quatreDerniersChiffres: paiementInput.detailsCarteBancaire.quatreDerniersChiffres || user.informationsPaiementSimulees.detailsCarteBancaire?.quatreDerniersChiffres,
                    dateExpiration: paiementInput.detailsCarteBancaire.dateExpiration || user.informationsPaiementSimulees.detailsCarteBancaire?.dateExpiration,
                 };
            }
            // On ne modifie pas le solde ici via le profil
        }

        if (userRole === 'client') {
            if (value.adresseLivraison) {
                // Si adresseLivraison est null dans la requête, on peut vouloir la supprimer
                // ou la mettre à jour champ par champ. Pour la simplicité, on remplace l'objet.
                user.adresseLivraison = value.adresseLivraison;
            }
        } else if (userRole === 'boutique') {
            if (value.nomBoutique !== undefined) user.nomBoutique = value.nomBoutique;
            if (value.descriptionBoutique !== undefined) user.descriptionBoutique = value.descriptionBoutique;
            if (value.logoUrlBoutique !== undefined) user.logoUrlBoutique = value.logoUrlBoutique;
            if (value.coordonneesBoutique) user.coordonneesBoutique = value.coordonneesBoutique;
            if (value.horairesOuvertureBoutique !== undefined) user.horairesOuvertureBoutique = value.horairesOuvertureBoutique;
        }
        // Les parrains ont généralement moins de champs de profil modifiables à part nomComplet/telephone.

        const updatedUser = await user.save();

        // Renvoyer l'utilisateur mis à jour (sans les champs sensibles)
        const userToReturn = { ...updatedUser.toObject() };
        delete userToReturn.password;
        delete userToReturn.verificationCode;
        delete userToReturn.verificationCodeValidation;
        delete userToReturn.forgotPasswordCode;
        delete userToReturn.forgotPasswordCodeValidation;


        res.status(200).json({
            success: true,
            message: 'Profil mis à jour avec succès!',
            user: userToReturn
        });

    } catch (error) {
        console.error("Erreur updateMyProfile:", error);
         if (error.code === 11000) { // Erreur de clé dupliquée (si un champ unique est mal géré)
             return res.status(409).json({
                 success: false,
                 message: `Une valeur fournie est déjà utilisée (ex: email si vous permettiez sa modification).`,
             });
        }
        res.status(500).json({ success: false, message: 'Erreur serveur lors de la mise à jour du profil.', error: error.message });
    }
};

// Schéma Joi pour la mise à jour de l'abonnement
const updateSubscriptionSchema = Joi.object({
    newSubscriptionType: Joi.string().valid('classic', 'gold', 'platinum').required().messages({
        'any.required': 'Le nouveau type d\'abonnement est requis.',
        'any.only': 'Type d\'abonnement invalide.'
    })
});


// Map des coûts d'abonnement (simulation)
const COUTS_ABONNEMENT_SIMULES = {
    classic: 0, // Supposons que classic soit gratuit ou a un coût initial
    gold: 10000, // Coût fictif en FCFA
    platinum: 25000 // Coût fictif en FCFA
};

exports.updateMySubscription = async (req, res) => {
    try {
        const userId = req.user.userId; // ID de la boutique

        const { error, value } = updateSubscriptionSchema.validate(req.body);
        if (error) {
            return res.status(400).json({ success: false, message: error.details[0].message });
        }

        const boutique = await User.findById(userId);
        if (!boutique || boutique.role !== 'boutique') {
            return res.status(404).json({ success: false, message: 'Compte boutique non trouvé.' });
        }

        const nouveauTypeAbo = value.newSubscriptionType;
        const coutNouvelAbo = COUTS_ABONNEMENT_SIMULES[nouveauTypeAbo]

        // --- SIMULATION DE PAIEMENT ---
        let paiementEffectue = false;
        if (nouveauTypeAbo !== boutique.typeAbonnement) { // Si l'abonnement change réellement
            if (!boutique.informationsPaiementSimulees || boutique.informationsPaiementSimulees.typePaiementPrincipal === 'non_configure') {
                return res.status(402).json({ // 402 Payment Required
                    success: false,
                    message: "Veuillez configurer une méthode de paiement avant de changer d'abonnement."
                });
            }
            if (coutNouvelAbo > 0) { // Si le nouvel abonnement a un coût
                if (boutique.informationsPaiementSimulees.soldeCompteSimule < coutNouvelAbo) {
                    return res.status(402).json({
                        success: false,
                        message: `Solde insuffisant (${boutique.informationsPaiementSimulees.soldeCompteSimule} FCFA) pour payer l'abonnement ${nouveauTypeAbo} (${coutNouvelAbo} FCFA).`
                    });
                }
                // Déduire le coût du solde simulé
                boutique.informationsPaiementSimulees.soldeCompteSimule -= coutNouvelAbo;
                paiementEffectue = true;
                console.log(`Paiement simulé de ${coutNouvelAbo} FCFA pour l'abonnement ${nouveauTypeAbo} par la boutique ${boutique.email}. Nouveau solde: ${boutique.informationsPaiementSimulees.soldeCompteSimule}`);
            }
        }
        // --- FIN SIMULATION PAIEMENT ---


        boutique.typeAbonnement = value.nouveauTypeAbo;
        // La limiteProduits sera mise à jour automatiquement par le hook pre-save
        await boutique.save();
        
          // --- ENREGISTREMENT DANS LE REGISTRE (ABONNEMENT) ---
          if (paiementEffectue) {
            await logLedgerEvent(
                'ABONNEMENT_PAYE_SIMULE',
                {
                    boutiqueId: userId,
                    ancienAbonnement: /* stocker l'ancien type si besoin */ boutique.typeAbonnement, // Ceci est le nouveau, il faudrait stocker l'ancien avant de le changer
                    nouvelAbonnement: nouveauTypeAbo,
                    montantPaye: coutNouvelAbo
                },
                [userId]
            );
        }
        // --- FIN ENREGISTREMENT REGISTRE (ABONNEMENT) ---


        // Renvoyer l'utilisateur mis à jour
        const userToReturn = { ...boutique.toObject() };
        delete userToReturn.password; // etc.

        // Ne pas renvoyer le solde après chaque update
        if (userToReturn.informationsPaiementSimulees) delete userToReturn.informationsPaiementSimulees.soldeCompteSimule; 
        res.status(200).json({
            success: true,
            message: `Votre abonnement a été mis à jour vers "${boutique.typeAbonnement}". Votre nouvelle limite de produits est de ${boutique.limiteProduits}.`,
            user: userToReturn
        });

    } catch (error) {
        console.error("Erreur updateMySubscription:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur lors de la mise à jour de l\'abonnement.', error: error.message });
    }
};

// Récupérer les commissions du parrain connecté
exports.getMyCommissions = async (req, res) => {
    try {
        const parrainId = req.user.userId; // Vient du token
        const userRole = req.user.role;

        if (userRole !== 'parrain') {
            return res.status(403).json({ success: false, message: 'Accès non autorisé. Réservé aux parrains.' });
        }

        // Pagination simple (optionnelle)
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        const commissions = await Commission.find({ idParrain: parrainId })
            .sort({ createdAt: -1 }) // Les plus récentes en premier
            .skip(skip)
            .limit(limit)
            .populate('idClientReffere', 'nomComplet email') // Afficher des infos sur le client parrainé
            .populate('idOrderAssocie', 'totalCommande createdAt') //  liez à un Order

        const totalCommissions = await Commission.countDocuments({ idParrain: parrainId });
        
        // Calculer le total des commissions validées (exemple)
        const commissionsValidees = await Commission.aggregate([
            { $match: { idParrain: new mongoose.Types.ObjectId(parrainId), statut: 'validee' } }, // ou 'payee' si il y'a ce statut
            { $group: { _id: null, totalGains: { $sum: '$montantCommission' } } }
        ]);
        const totalGainsValides = commissionsValidees.length > 0 ? commissionsValidees[0].totalGains : 0;


        res.status(200).json({
            success: true,
            currentPage: page,
            totalPages: Math.ceil(totalCommissions / limit),
            totalCommissionsCount: totalCommissions,
            totalGainsValidesSimules: totalGainsValides.toFixed(2), // Solde des commissions "retirables"
            commissions: commissions
        });

    } catch (error) {
        console.error("Erreur getMyCommissions:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};

// Récupérer les filleuls du parrain connecté
exports.getMyReferredUsers = async (req, res) => {
    try {
        const parrainId = req.user.userId;
        const userRole = req.user.role;

        if (userRole !== 'parrain') {
            return res.status(403).json({ success: false, message: 'Accès non autorisé. Réservé aux parrains.' });
        }

        const parrain = await User.findById(parrainId).select('codePromoPersonnel');
        if (!parrain || !parrain.codePromoPersonnel) {
            return res.status(404).json({ success: false, message: 'Informations du parrain non trouvées ou code promo manquant.' });
        }

        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        // Trouver les clients qui ont utilisé le code du parrain
        const filleuls = await User.find({
            role: 'client',
            codeParrainSaisi: parrain.codePromoPersonnel // Recherche sur le code stocké chez le client
        })
        .select('nomComplet email createdAt informationsPaiementSimulees.typePaiementPrincipal') // Renvoyer des infos utiles mais pas trop sensibles
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit);

        const totalFilleuls = await User.countDocuments({
            role: 'client',
            codeParrainSaisi: parrain.codePromoPersonnel
        });

        res.status(200).json({
            success: true,
            codeParrainUtilise: parrain.codePromoPersonnel,
            currentPage: page,
            totalPages: Math.ceil(totalFilleuls / limit),
            totalFilleuls,
            filleuls
        });

    } catch (error) {
        console.error("Erreur getMyReferredUsers:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};


// Demander le paiement des commissions validées
exports.requestCommissionPayout = async (req, res) => {
    try {
        const parrainId = req.user.userId;

        const { error, value } = requestCommissionPayoutSchema.validate(req.body);
        if (error) {
            return res.status(400).json({ success: false, message: error.details[0].message });
        }

        let query = {
            idParrain: parrainId,
            statut: 'validee' // On ne peut demander que le paiement des commissions validées
        };

        if (value.commissionIds && value.commissionIds.length > 0) {
            query._id = { $in: value.commissionIds.map(id => new mongoose.Types.ObjectId(id)) };
        }

        const commissionsADemander = await Commission.find(query);

        if (commissionsADemander.length === 0) {
            return res.status(404).json({ success: false, message: 'Aucune commission validée trouvée pour cette demande.' });
        }

        const montantTotalDemande = commissionsADemander.reduce((sum, comm) => sum + comm.montantCommission, 0);

        if (montantTotalDemande <= 0) {
             return res.status(400).json({ success: false, message: 'Le montant total des commissions sélectionnées est nul ou négatif.' });
        }

        // Mettre à jour le statut des commissions et la date de demande
        const idsToUpdate = commissionsADemander.map(c => c._id);
        await Commission.updateMany(
            { _id: { $in: idsToUpdate } },
            { $set: { statut: 'demandee_en_paiement', dateDemandePaiement: new Date() } }
        );
        
        // Logguer l'événement
        await logLedgerEvent('COMMISSION_PAIEMENT_DEMANDE', {
            parrainId: parrainId,
            commissionIds: idsToUpdate,
            montantTotalDemande: montantTotalDemande
        }, [parrainId]);


        // Dans une vraie app, on créerait un enregistrement PayoutRequest ici.
        // Pour le proto, on informe juste que la demande est prise en compte.
        res.status(200).json({
            success: true,
            message: `Demande de paiement pour ${commissionsADemander.length} commission(s) (totalisant ${montantTotalDemande.toFixed(2)} FCFA) a été soumise. Elle sera traitée par un administrateur.`,
            demande: {
                commissionIds: idsToUpdate,
                montantTotal: montantTotalDemande.toFixed(2),
                dateDemande: new Date()
            }
        });

    } catch (error) {
        console.error("Erreur requestCommissionPayout:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur lors de la demande de paiement.', error: error.message });
    }
};

// Récupérer les notifications de l'utilisateur connecté
exports.getMyNotifications = async (req, res) => {
    try {
        const userId = req.user.userId;
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10; // Nombre de notifs par page
        const skip = (page - 1) * limit;
        const filter = req.query.filter; // 'lues', 'non_lues'

        let query = { idUtilisateurDestinataire: userId };
        if (filter === 'lues') query.estLue = true;
        if (filter === 'non_lues') query.estLue = false;

        const notifications = await Notification.find(query)
            .sort({ createdAt: -1 }) // Les plus récentes en premier
            .skip(skip)
            .limit(limit);

        const totalNotifications = await Notification.countDocuments(query);
        const unreadCount = await Notification.countDocuments({ idUtilisateurDestinataire: userId, estLue: false });

        res.status(200).json({
            success: true,
            currentPage: page,
            totalPages: Math.ceil(totalNotifications / limit),
            totalNotifications,
            unreadCount,
            notifications
        });
    } catch (error) {
        console.error("Erreur getMyNotifications:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};

// Marquer une notification comme lue
exports.markNotificationAsRead = async (req, res) => {
    try {
        const userId = req.user.userId;
        const { notificationId } = req.params;

        if (!mongoose.Types.ObjectId.isValid(notificationId)) {
            return res.status(400).json({ success: false, message: 'ID de notification invalide.' });
        }

        const notification = await Notification.findOne({
            _id: notificationId,
            idUtilisateurDestinataire: userId // S'assurer que la notif appartient à l'utilisateur
        });

        if (!notification) {
            return res.status(404).json({ success: false, message: 'Notification non trouvée ou accès non autorisé.' });
        }

        if (!notification.estLue) {
            notification.estLue = true;
            notification.dateLecture = new Date();
            await notification.save();
        }

        res.status(200).json({ success: true, message: 'Notification marquée comme lue.', notification });
    } catch (error) {
        console.error("Erreur markNotificationAsRead:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};

// Marquer toutes les notifications comme lues
exports.markAllMyNotificationsAsRead = async (req, res) => {
    try {
        const userId = req.user.userId;

        const result = await Notification.updateMany(
            { idUtilisateurDestinataire: userId, estLue: false },
            { $set: { estLue: true, dateLecture: new Date() } }
        );

        res.status(200).json({
            success: true,
            message: `${result.modifiedCount} notification(s) marquée(s) comme lue(s).`
        });
    } catch (error) {
        console.error("Erreur markAllMyNotificationsAsRead:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};
// ... (imports Notification, mongoose)

// ... (getMyNotifications, markNotificationAsRead, markAllMyNotificationsAsRead)

exports.getSingleNotification = async (req, res) => {
    try {
        const userId = req.user.userId;
        const { notificationId } = req.params;

        if (!mongoose.Types.ObjectId.isValid(notificationId)) {
            return res.status(400).json({ success: false, message: 'ID de notification invalide.' });
        }

        const notification = await Notification.findOne({
            _id: notificationId,
            idUtilisateurDestinataire: userId // S'assurer que la notification appartient à l'utilisateur connecté
        });

        if (!notification) {
            return res.status(404).json({ success: false, message: 'Notification non trouvée ou accès non autorisé.' });
        }

        // Optionnel: Si elle n'est pas lue, on pourrait la marquer comme lue ici aussi,
        // mais le frontend le fait déjà avant d'appeler cet endpoint.
        // if (!notification.estLue) {
        //     notification.estLue = true;
        //     notification.dateLecture = new Date();
        //     await notification.save();
        //     // On ne renvoie pas la notification mise à jour ici, le frontend gère l'UI
        // }

        res.status(200).json({ success: true, notification });

    } catch (error) {
        console.error("Erreur getSingleNotification:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};
// --- Potentiellement d'autres fonctions pour les administrateurs plus tard ---
// exports.getAllUsers (pour admin)
// exports.getUserById (pour admin)
// exports.updateUserById (pour admin)
// exports.deleteUserById (pour admin)
