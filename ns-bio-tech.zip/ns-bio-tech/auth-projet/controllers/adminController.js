// auth-projet/controllers/adminController.js
const Order = require('../models/orderModel');         // <<--- ASSUREZ-VOUS QUE CETTE LIGNE EST PRÉSENTE ET CORRECTE
const User = require('../models/usersModel');
const Product = require('../models/productModel');     // Si vous en avez besoin ici pour d'autres fonctions admin
const Commission = require('../models/commissionModel'); // Pour getPendingPayoutRequests etc.
const mongoose = require('mongoose');
const { logLedgerEvent } = require('../utils/ledgerLogger'); // Si utilisé dans d'autres fonctions admin

// Lister les demandes de paiement de commissions (statut 'demandee_en_paiement')
exports.getPendingPayoutRequests = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        // On liste les commissions individuellement, même si plusieurs ont été demandées en même temps
        // Une approche plus avancée créerait un modèle PayoutRequest regroupant des commissions.
        const pendingCommissions = await Commission.find({ statut: 'demandee_en_paiement' })
            .populate('idParrain', 'email nomComplet informationsPaiementSimulees') // Pour voir à qui payer et comment (simulé)
            .sort({ dateDemandePaiement: 1 }) // Les plus anciennes demandes en premier
            .skip(skip)
            .limit(limit);

        const totalPending = await Commission.countDocuments({ statut: 'demandee_en_paiement' });

        res.status(200).json({
            success: true,
            currentPage: page,
            totalPages: Math.ceil(totalPending / limit),
            totalPending,
            requests: pendingCommissions // Chaque commission est une "demande" individuelle ici
        });
    } catch (error) {
        console.error("Erreur getPendingPayoutRequests:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};

// Approuver et "payer" une commission (simulation)
exports.approveCommissionPayout = async (req, res) => {
    try {
        const adminId = req.user.userId; // ID de l'admin qui approuve
        const { commissionId } = req.params;

        if (!mongoose.Types.ObjectId.isValid(commissionId)) {
            return res.status(400).json({ success: false, message: 'ID de commission invalide.' });
        }

        const commission = await Commission.findById(commissionId).populate('idParrain', 'email');
        if (!commission) {
            return res.status(404).json({ success: false, message: 'Commission non trouvée.' });
        }

        if (commission.statut !== 'demandee_en_paiement') {
            return res.status(400).json({ success: false, message: `Cette commission n'est pas en attente de paiement (statut actuel: ${commission.statut}).` });
        }

        // --- SIMULATION DU PAIEMENT RÉEL ---
        // Dans une vraie application, ici vous déclencheriez un paiement via une API (PayPal, Stripe, virement bancaire...).
        // Pour le prototype, nous allons simplement mettre à jour le statut.
        // On pourrait aussi (optionnellement) déduire du "solde de la plateforme" et créditer le "solde retirable" du parrain.
        // Pour l'instant, on marque juste comme payé.

        commission.statut = 'payee';
        commission.datePaiement = new Date();
        // commission.processedByAdminId = adminId; // Optionnel: tracer quel admin a traité
        await commission.save();

        // Logguer l'événement
        await logLedgerEvent('COMMISSION_PAYEE_SIMULEE', {
            commissionId: commission._id,
            parrainId: commission.idParrain._id,
            montantPaye: commission.montantCommission,
            adminIdApprobateur: adminId
        }, [commission.idParrain, adminId].filter(id => id));

        // Optionnel: Envoyer une notification au parrain
        // ...

        res.status(200).json({
            success: true,
            message: `Le paiement de la commission de ${commission.montantCommission.toFixed(2)} FCFA pour ${commission.idParrain.email} a été approuvé et marqué comme payé (simulation).`,
            commission
        });

    } catch (error) {
        console.error("Erreur approveCommissionPayout:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};

exports.getAllPlatformOrders = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 15;
        const skip = (page - 1) * limit;
        const sortParam = req.query.sort || 'createdAt_desc'; // Ex: 'createdAt_asc', 'totalCommande_desc'

        let sortOption = {};
        if (sortParam === 'createdAt_desc') sortOption.createdAt = -1;
        else if (sortParam === 'createdAt_asc') sortOption.createdAt = 1;
        else if (sortParam === 'totalCommande_desc') sortOption.totalCommande = -1;
        else if (sortParam === 'totalCommande_asc') sortOption.totalCommande = 1;
        else sortOption.createdAt = -1; // Défaut

        let query = {};

        // Filtre par statut de commande
        if (req.query.statutCommande) {
            query.statutCommande = req.query.statutCommande;
        }

        // Filtre par date (createdAt de la commande)
        if (req.query.dateFrom) {
            query.createdAt = { ...query.createdAt, $gte: new Date(req.query.dateFrom) };
        }
        if (req.query.dateTo) { // Si vous ajoutez un filtre dateTo
            query.createdAt = { ...query.createdAt, $lte: new Date(new Date(req.query.dateTo).setHours(23, 59, 59, 999)) };
        }
        
        // Filtre de recherche (plus complexe car sur des champs populés ou ID)
        // Pour une recherche efficace, il faudrait dénormaliser certains champs sur le modèle Order
        // ou faire des requêtes d'agrégation plus complexes.
        // Simplification pour le prototype : recherche sur l'ID de commande si c'est un ObjectId valide.
        // Une recherche textuelle sur les noms nécessiterait des étapes supplémentaires.
        if (req.query.search && req.query.search.trim() !== '') {
            const searchTerm = req.query.search.trim();
            if (mongoose.Types.ObjectId.isValid(searchTerm)) {
                query._id = new mongoose.Types.ObjectId(searchTerm);
            } else {
                // Pour rechercher sur nom client/boutique, il faudrait une logique d'agrégation
                // pour filtrer après population, ou un index texte sur des champs dénormalisés.
                // Pour l'instant, on ne fait pas cette recherche complexe pour le prototype si ce n'est pas un ID.
                // Ou, on pourrait ajouter une recherche regex sur un champ dénormalisé `clientEmail` ou `boutiqueName` sur Order.
                console.log("Recherche admin sur des champs non-ID non implémentée pour ce prototype simple sur /admin/orders.");
            }
        }


        const orders = await Order.find(query)
            .populate({
                path: 'idClient',
                select: 'nomComplet email' // Champs à populer pour le client
            })
            .populate({
                path: 'idBoutiqueAssociee',
                select: 'nomBoutique email' // Champs à populer pour la boutique
            })
            .populate({ // Optionnel : populer les noms des produits dans la commande
                path: 'produits.idProduit',
                select: 'nom'
            })
            .sort(sortOption)
            .skip(skip)
            .limit(limit);

        const totalOrders = await Order.countDocuments(query);

        res.status(200).json({
            success: true,
            orders,
            currentPage: page,
            totalPages: Math.ceil(totalOrders / limit),
            totalOrders,
        });

    } catch (error) {
        console.error("Erreur getAllPlatformOrders (admin):", error);
        res.status(500).json({ success: false, message: "Erreur serveur lors de la récupération des commandes.", error: error.message });
    }
};

exports.getSinglePlatformOrder = async (req, res) => {
    try {
        const { orderId } = req.params;
        if (!mongoose.Types.ObjectId.isValid(orderId)) {
            return res.status(400).json({ success: false, message: 'ID de commande invalide.' });
        }

        const order = await Order.findById(orderId)
            .populate('idClient', 'nomComplet email telephone informationsPaiementSimulees.typePaiementPrincipal')
            .populate('idBoutiqueAssociee', 'nomBoutique email telephone')
            .populate('produits.idProduit', 'nom imageUrl categorie'); // Populer les produits de la commande

        if (!order) {
            return res.status(404).json({ success: false, message: 'Commande non trouvée.' });
        }

        res.status(200).json({ success: true, order });

    } catch (error) {
        console.error("Erreur getSinglePlatformOrder (admin):", error);
        res.status(500).json({ success: false, message: "Erreur serveur lors de la récupération de la commande.", error: error.message });
    }
};

