// controllers/chatbotController.js
const Joi = require('joi');
const User = require('../models/usersModel');
const Product = require('../models/productModel');
const Order = require('../models/orderModel'); // Assurez-vous que ce modèle existe si vous l'utilisez


const chatQuerySchema = Joi.object({
    message: Joi.string().min(1).max(500).required(),
    // Optionnel: L'ID de session du chat pour maintenir le contexte entre les appels
    // Si non fourni, le contexte sera lié à l'utilisateur s'il est connecté, sinon il sera limité.
    chatSessionId: Joi.string().optional().allow('')
});

// --- Gestion de Contexte (Simulation en Mémoire) ---
// ATTENTION: En production, ce contexte devrait être stocké en base de données (ex: Redis, ou une collection MongoDB)
// et lié à un chatSessionId ou userId pour persistance et scalabilité.
// Pour le prototype, une simple map en mémoire fera l'affaire (se réinitialise au redémarrage du serveur).
const chatContexts = new Map(); // Clé: userId ou chatSessionId, Valeur: { lastIntent: '...', data: {} }

// --- Base de Connaissances Améliorée avec Fonctions et Détection d'Intentions ---
const INTENTS = {
    GREETING: 'greeting',
    PRODUCT_SEARCH_INIT: 'product_search_init', // "Je cherche un produit"
    PRODUCT_SEARCH_DETAIL: 'product_search_detail', // "pour la peau sèche" (suit un INIT)
    PRODUCT_AVAILABILITY: 'product_availability', // "Avez-vous du thé vert bio ?"
    ORDER_STATUS: 'order_status',
    DELIVERY_INFO: 'delivery_info',
    REFERRAL_INFO: 'referral_info',
    HELP: 'help',
    PROBLEM_REPORT: 'problem_report',
    THANK_YOU: 'thank_you',
    GOODBYE: 'goodbye',
    UNKNOWN: 'unknown',

};
INTENTS.BOUTIQUE_INFO_REQUEST = 'boutique_info_request'; // "Infos sur la boutique X"
INTENTS.BOUTIQUE_PICKUP_POINTS_REQUEST = 'boutique_pickup_points_request'; // "Points de retrait de la boutique X"
INTENTS.BOUTIQUE_OPENING_HOURS_REQUEST = 'boutique_opening_hours_request'; // "Horaires d'ouverture de la boutique X"
INTENTS.BOUTIQUE_CONTACT_REQUEST = 'boutique_contact_request'; // "Contact de la boutique X"
// Chaque clé est un regex, la valeur est une fonction qui retourne une promesse avec la réponse
// La fonction reçoit (userMessage, userId, currentContext)
const KNOWLEDGE_HANDLERS = [
    {
        intent: INTENTS.GREETING,
        regex: /\b(bonjour|salut|hello|yo|coucou)\b/i,
        handler: async (msg, userId, ctx) => {
            let greeting = "Bonjour !";
            if (userId) {
                const user = await User.findById(userId).select('nomComplet');
                if (user && user.nomComplet) greeting = `Bonjour ${user.nomComplet.split(' ')[0]} !`;
            }
            ctx.lastIntent = INTENTS.GREETING;
            return `${greeting} Comment puis-je vous aider aujourd'hui ?`;
        }
    },
    {
        intent: INTENTS.PRODUCT_SEARCH_INIT,
        regex: /cherche\s+(un\s+)?produit|recherche\s+produit|besoin\s+d'un\s+produit/i,
        handler: async (msg, userId, ctx) => {
            ctx.lastIntent = INTENTS.PRODUCT_SEARCH_INIT;
            return "Bien sûr, quel type de produit cherchez-vous ou pour quel usage ?";
        }
    },
    {
        intent: INTENTS.BOUTIQUE_OPENING_HOURS_REQUEST,
        // Regex pour "horaires d'ouverture de (la boutique)? XYZ" ou "quand est ouverte XYZ"
        regex: /(?:horaires d'ouverture|quand est ouverte|quelles sont les heures d'ouverture)\s+(?:de|pour|chez)\s+(?:la\s+boutique\s+)?([\w\sÀ-ÿ'-]+)/i,
        handler: async (msg, userId, ctx, match) => {
            const nomBoutiqueQuery = match[1]?.trim();
            if (!nomBoutiqueQuery) {
                return "Pour quelle boutique souhaitez-vous connaître les horaires d'ouverture ?";
            }
            ctx.lastIntent = INTENTS.BOUTIQUE_OPENING_HOURS_REQUEST;
            ctx.data.lastQueriedBoutiqueNameForHours = nomBoutiqueQuery; // Stocker pour un éventuel suivi

            const boutique = await User.findOne({
                nomBoutique: { $regex: `^${nomBoutiqueQuery}$`, $options: 'i' }, // Correspondance exacte (insensible à la casse)
                role: 'boutique'
            }).select('nomBoutique horairesOuverture');

            if (boutique) {
                if (boutique.horairesOuverture) {
                    return `Les horaires d'ouverture de "${boutique.nomBoutique}" sont : ${boutique.horairesOuverture}.`;
                } else {
                    return `Désolé, je n'ai pas trouvé d'informations sur les horaires d'ouverture de "${boutique.nomBoutique}".`;
                }
            } else {
                return `Désolé, je n'ai pas trouvé de boutique nommée "${nomBoutiqueQuery}". Veuillez vérifier l'orthographe.`;
            }
        }
    },
    
    {
    intent: INTENTS.BOUTIQUE_INFO_REQUEST,
        // Regex pour capturer le nom de la boutique. Ex: "infos sur (la boutique)? XYZ" ou "parle moi de XYZ"
        regex: /(?:infos sur|parle moi de|qui est|détails sur)\s+(?:la\s+boutique\s+)?([\w\sÀ-ÿ'-]+)/i,
        handler: async (msg, userId, ctx, match) => {
            const nomBoutiqueQuery = match[1]?.trim();
            if (!nomBoutiqueQuery) {
                return "De quelle boutique souhaitez-vous des informations ?";
            }
            ctx.lastIntent = INTENTS.BOUTIQUE_INFO_REQUEST;
            ctx.data.lastQueriedBoutiqueName = nomBoutiqueQuery; // Stocker pour un éventuel suivi

            const boutique = await User.findOne({
                nomBoutique: { $regex: `^${nomBoutiqueQuery}$`, $options: 'i' }, // Correspondance exacte (insensible à la casse)
                role: 'boutique'
            }).select('nomBoutique descriptionBoutique telephone coordonneesBoutique.ville createdAt');

            if (boutique) {
                let response = `Voici quelques informations sur la boutique "${boutique.nomBoutique}": `;
                if (boutique.descriptionBoutique) response += `${boutique.descriptionBoutique}. `;
                if (boutique.coordonneesBoutique?.ville) response += `Elle est située aux alentours de ${boutique.coordonneesBoutique.ville}. `;
                if (boutique.telephone) response += `Vous pouvez les contacter au ${boutique.telephone}. `;
                response += `Elle est inscrite sur notre plateforme depuis ${new Date(boutique.createdAt).toLocaleDateString()}.`;
                return response;
            } else {
                return `Désolé, je n'ai pas trouvé d'informations pour une boutique nommée "${nomBoutiqueQuery}". Veuillez vérifier l'orthographe.`;
            }
        }
    },
    {
        intent: INTENTS.BOUTIQUE_PICKUP_POINTS_REQUEST,
        // Regex pour "points de retrait de (la boutique)? XYZ" ou "où récupérer chez XYZ"
        regex: /(?:points? de retrait|o[uù] r[eé]cup[eé]rer|adresses? de collecte)\s+(?:de|pour|chez)\s+(?:la\s+boutique\s+)?([\w\sÀ-ÿ'-]+)/i,
        handler: async (msg, userId, ctx, match) => {
            const nomBoutiqueQuery = match[1]?.trim();
            if (!nomBoutiqueQuery) {
                return "Pour quelle boutique souhaitez-vous connaître les points de retrait ?";
            }
            ctx.lastIntent = INTENTS.BOUTIQUE_PICKUP_POINTS_REQUEST;
            ctx.data.lastQueriedBoutiqueNameForPickup = nomBoutiqueQuery;

            const boutique = await User.findOne({
                nomBoutique: { $regex: `^${nomBoutiqueQuery}$`, $options: 'i' },
                role: 'boutique'
            }).select('nomBoutique pointsDeRetrait');

            if (boutique) {
                if (boutique.pointsDeRetrait && boutique.pointsDeRetrait.length > 0) {
                    let response = `Voici les points de retrait pour la boutique "${boutique.nomBoutique}":\n`;
                    boutique.pointsDeRetrait.forEach(point => {
                        response += `- ${point.nom}: ${point.adresse}${point.ville ? ', ' + point.ville : ''}.\n`;
                        if(point.horairesOuverture) response += `  Horaires: ${point.horairesOuverture}\n`;
                    });
                    return response;
                } else {
                    return `La boutique "${boutique.nomBoutique}" n'a pas encore configuré de points de retrait sur notre plateforme. Vous pouvez opter pour la livraison si disponible.`;
                }
            } else {
                return `Désolé, je n'ai pas trouvé de boutique nommée "${nomBoutiqueQuery}" pour vérifier les points de retrait.`;
            }
        }
    },
    
    {
        intent: INTENTS.PRODUCT_SEARCH_DETAIL, // S'active si le contexte précédent était PRODUCT_SEARCH_INIT
        // Pas de regex spécifique ici, on se base sur le contexte
        handler: async (msg, userId, ctx) => {
            if (ctx.lastIntent === INTENTS.PRODUCT_SEARCH_INIT) {
                ctx.lastIntent = INTENTS.PRODUCT_SEARCH_DETAIL;
                // Recherche simple basée sur les mots du message
                const searchTerms = msg.split(' ').filter(term => term.length > 2).join(' '); // Enlever les petits mots
                const products = await Product.find({
                    $text: { $search: searchTerms }, // Nécessite un index texte sur nom, description, categorie
                    statutValidation: 'approuve',
                    disponible: true
                }).limit(3).select('nom prix');

                if (products.length > 0) {
                    const productNames = products.map(p => `${p.nom} (${p.prix}€)`).join(', ');
                    return `Pour "${msg}", j'ai trouvé : ${productNames}. Un de ceux-là vous intéresse ou souhaitez-vous affiner ?`;
                } else {
                    return `Je n'ai pas trouvé de produit spécifique pour "${msg}". Pouvez-vous reformuler ou essayer d'autres termes ?`;
                }
            }
            return null; // Ne pas gérer si le contexte n'est pas bon
        }
    },
    {
        intent: INTENTS.PRODUCT_AVAILABILITY,
        regex: /(avez-vous|as-tu|existe|disponible).*(produit|article|thé|crème|huile)\s+([\w\s]+)/i,
        handler: async (msg, userId, ctx, match) => { // match contient les groupes capturés par la regex
            const productNameQuery = match[3]?.trim();
            if (!productNameQuery) return "Quel produit recherchez-vous exactement ?";

            ctx.lastIntent = INTENTS.PRODUCT_AVAILABILITY;
            const products = await Product.find({
                nom: { $regex: productNameQuery, $options: 'i' },
                statutValidation: 'approuve',
                disponible: true
            }).limit(1).select('nom prix');

            if (products.length > 0) {
                return `Oui, nous avons "${products[0].nom}" disponible à ${products[0].prix}€. Souhaitez-vous l'ajouter au panier ?`;
            } else {
                return `Désolé, je ne trouve pas de "${productNameQuery}" disponible pour le moment. Voulez-vous que je cherche autre chose ?`;
            }
        }
    },
    {
        intent: INTENTS.ORDER_STATUS,
        regex: /o[uù]\s+est\s+ma\s+commande|statut\s+(de\s+ma\s+)?commande|suivi\s+commande/i,
        handler: async (msg, userId, ctx) => {
            ctx.lastIntent = INTENTS.ORDER_STATUS;
            if (!userId) return "Veuillez vous connecter pour que je puisse vérifier le statut de votre commande.";

            // Simulation: récupérer la dernière commande "en cours" de l'utilisateur
            // Pour une vraie app, OrderModel aurait des statuts plus précis (en_preparation, expediee, livree)
            const lastOrder = await Order.findOne({ idClient: userId, statut: { $ne: 'simulation_reussie' } }) // Exclure les simulations pures si Order les stocke
                                         .sort({ createdAt: -1 })
                                         .select('statut createdAt produits'); // Adaptez les statuts

            if (lastOrder) {
                // Pour le proto, on donne un statut générique.
                // Dans une vraie app, vous auriez des statuts comme 'en préparation', 'expédiée', 'livrée'.
                const productName = lastOrder.produits.length > 0 ? lastOrder.produits[0].nomProduit : 'votre commande';
                return `Votre dernière commande (${productName}...) passée le ${new Date(lastOrder.createdAt).toLocaleDateString()} est actuellement "en cours de traitement".`;
            } else {
                return "Je ne trouve pas de commande récente en cours pour votre compte.";
            }
        }
    },
    {
        intent: INTENTS.DELIVERY_INFO,
        regex: /livraison|point de retrait|retrait/i,
        handler: async (msg, userId, ctx) => {
            ctx.lastIntent = INTENTS.DELIVERY_INFO;
            return "Nous proposons la livraison à domicile et le retrait en point relais. Les options et coûts spécifiques sont affichés lors de la validation de votre commande, en fonction des produits et de votre adresse.";
        }
    },
    {
        intent: INTENTS.REFERRAL_INFO,
        regex: /parrainage|code\s+parrain|commission/i,
        handler: async (msg, userId, ctx) => {
            ctx.lastIntent = INTENTS.REFERRAL_INFO;
            if(userId){
                const user = await User.findById(userId).select('role codePromoPersonnel');
                if(user && user.role === 'parrain' && user.codePromoPersonnel){
                    return `Votre code de parrainage est ${user.codePromoPersonnel}. Partagez-le pour gagner des commissions !`;
                }
            }
            return "Notre système de parrainage vous permet de gagner des commissions. Si vous êtes parrain, votre code est dans votre profil. Les clients peuvent utiliser un code lors de la commande.";
        }
    },
    {
        intent: INTENTS.HELP,
        regex: /aide|besoin d'aide|support/i,
        handler: async (msg, userId, ctx) => {
            ctx.lastIntent = INTENTS.HELP;
            ctx.helpAttempts = (ctx.helpAttempts || 0) + 1;
            if(ctx.helpAttempts > 2){
                 ctx.helpAttempts = 0; // Reset
                 return "Je vois que vous avez toujours besoin d'aide. Vous pouvez contacter notre support client à support@nsbio.tech ou au +XX XXX XX XX XX.";
            }
            return "Je suis là pour vous aider. Posez-moi votre question sur nos produits, votre commande, la livraison ou le parrainage.";
        }
    },
    // ... (THANK_YOU, GOODBYE comme avant)
];

const DEFAULT_RESPONSE = "Je ne suis pas sûr de comprendre. Pouvez-vous reformuler ? Vous pouvez demander de l' 'aide'.";
const ESCALATION_MESSAGE = "Je rencontre des difficultés à comprendre. Souhaitez-vous être mis en contact avec un conseiller humain ? (Répondez 'oui' ou 'non')";


exports.handleChatMessage = async (req, res) => {
    try {
        const { error, value } = chatQuerySchema.validate(req.body);
        if (error) {
            return res.status(400).json({ success: false, message: error.details[0].message });
        }

        const userMessage = value.message.toLowerCase().trim();
        const userId = req.user ? req.user.userId : null; // Si 'identifier' est utilisé
        const sessionId = userId || value.chatSessionId || 'default_session'; // Utiliser userId si connecté

        // Récupérer ou initialiser le contexte
        let currentContext = chatContexts.get(sessionId) || { lastIntent: null, data: {}, unknownAttempts: 0, helpAttempts:0 };

        let botResponse = null;
        let matchedIntent = INTENTS.UNKNOWN;

        // Logique de correspondance d'intention
        // D'abord, vérifier si la réponse actuelle dépend fortement du contexte précédent
        // Ex: PRODUCT_SEARCH_DETAIL après PRODUCT_SEARCH_INIT
        const detailSearchHandler = KNOWLEDGE_HANDLERS.find(h => h.intent === INTENTS.PRODUCT_SEARCH_DETAIL);
        if (detailSearchHandler && currentContext.lastIntent === INTENTS.PRODUCT_SEARCH_INIT) {
            const detailResponse = await detailSearchHandler.handler(userMessage, userId, currentContext);
            if (detailResponse) { // Si le handler de détail a pu traiter
                botResponse = detailResponse;
                matchedIntent = INTENTS.PRODUCT_SEARCH_DETAIL;
            }
        }

        // Si pas géré par un intent contextuel, essayer les regex
        if (!botResponse) {
            for (const handlerObj of KNOWLEDGE_HANDLERS) {
                if (handlerObj.regex) { // S'assurer que la regex existe
                    const match = userMessage.match(handlerObj.regex);
                    if (match) {
                        botResponse = await handlerObj.handler(userMessage, userId, currentContext, match);
                        matchedIntent = handlerObj.intent;
                        break;
                    }
                }
            }
        }
        
        if (!botResponse) { // Si aucune regex n'a matché ou aucun intent contextuel
            currentContext.unknownAttempts = (currentContext.unknownAttempts || 0) + 1;
            if (currentContext.unknownAttempts >= 3) {
                botResponse = ESCALATION_MESSAGE;
                currentContext.lastIntent = 'escalation_pending'; // Attendre une réponse oui/non
            } else {
                botResponse = DEFAULT_RESPONSE;
            }
        } else {
            currentContext.unknownAttempts = 0; // Réinitialiser si on a compris
        }
        
        // Gérer la réponse à une demande d'escalade
        if (currentContext.lastIntent === 'escalation_pending') {
            if (userMessage.includes('oui')) {
                botResponse = "D'accord. Veuillez contacter notre support à support@nsbio.tech ou au +XX XXX XX XX XX pour une assistance personnalisée.";
                currentContext.unknownAttempts = 0; // Reset
                currentContext.lastIntent = null; // Fin de l'escalade
            } else if (userMessage.includes('non')) {
                botResponse = "D'accord. Comment puis-je vous aider autrement ?";
                currentContext.unknownAttempts = 0; // Reset
                currentContext.lastIntent = null;
            }
            // Si ni oui ni non, la réponse d'escalade est maintenue par la logique précédente
        }


        // Mettre à jour le contexte
        if (matchedIntent !== INTENTS.UNKNOWN && botResponse !== ESCALATION_MESSAGE && currentContext.lastIntent !== 'escalation_pending') {
            currentContext.lastIntent = matchedIntent; // Mettre à jour le lastIntent si ce n'est pas une escalade ou un unknown
        }
        chatContexts.set(sessionId, currentContext);

        await new Promise(resolve => setTimeout(resolve, Math.random() * 300 + 100));

        res.status(200).json({
            success: true,
            userMessage: value.message,
            botResponse: botResponse
        });

    } catch (error) {
        console.error("Erreur handleChatMessage:", error);
        // Nettoyer le contexte en cas d'erreur pour éviter des états incohérents
        // const sessionId = req.user ? req.user.userId : req.body.chatSessionId || 'default_session';
        // chatContexts.delete(sessionId);
        res.status(500).json({ success: false, message: 'Erreur serveur du chatbot.', error: error.message });
    }
};