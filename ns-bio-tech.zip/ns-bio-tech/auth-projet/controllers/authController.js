// controllers/authController.js
const jwt = require('jsonwebtoken');
const { signupSchema, signinSchema, accepCodeSchema, changePasswordSchema, acceptFPSchema } = require("../middlewares/validator");
const transport = require("../middlewares/sendMail");
const { doHash, doHashValidation, hmacProcess } = require("../utils/hashing");
const User = require("../models/usersModel");
const { createNotification } = require('../utils/notificationManager'); // <<--- IMPORT


exports.signup = async (req, res) => {
    try {
        const { error, value } = signupSchema.validate(req.body); // Valider tout le req.body
        if (error) {
            return res.status(400).json({ // 400 pour Bad Request due à la validation
                success: false,
                message: error.details[0].message,
            });
        }

        const { email, password, role, ...otherData } = value; // Destructurer après validation

        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(409).json({ // 409 pour Conflit
                success: false,
                message: 'Un utilisateur avec cet email existe déjà.',
            });
        }

        // Si c'est un parrain et qu'il a fourni un codePromoPersonnel, vérifier son unicité
        if (role === 'parrain' && otherData.codePromoPersonnel) {
            const existingPromoCode = await User.findOne({ codePromoPersonnel: otherData.codePromoPersonnel });
            if (existingPromoCode) {
                return res.status(409).json({
                    success: false,
                    message: 'Ce code promo personnel est déjà utilisé. Veuillez en choisir un autre.',
                });
            }
        }
            

        let parrainReferantTrouve = null; // Pour garder une trace si on trouve le parrain
        // Si c'est un client et qu'il a fourni un codeParrainSaisi, vérifier s'il existe 
        if (role === 'client' && otherData.codeParrainSaisi && otherData.codeParrainSaisi.trim() !== '') {
            const codeSaisi = otherData.codeParrainSaisi.toUpperCase(); // Normaliser le code
            parrainReferantTrouve = await User.findOne({ codePromoPersonnel: codeSaisi, role: 'parrain' });
            if (!parrainReferantTrouve) {
                // Pour le prototype, on peut juste ignorer le code ou le stocker quand même
                // Dans une vraie app, on pourrait retourner une erreur ou un avertissement
                delete otherData.codeParrainSaisi; // Option: ne pas le stocker s'il est invalide
                // Ou retourner une erreur:
                return res.status(400).json({
                    success: false,
                    message: `Le code de parrainage "${otherData.codeParrainSaisi}" est invalide ou n'existe pas.`
                });
            }else {
                console.log(`Client ${email} parrainé par ${parrainReferantTrouve.email} (ID: ${parrainReferantTrouve._id}) via le code ${codeSaisi}`);
                // À ce stade, parrainReferantTrouve contient les informations du parrain.
                // Le simple fait de stocker `otherData.codeParrainSaisi` sur le document du client
                // crée le lien via le code.
                // Si on voulait un lien direct par ID, on pourrait ajouter un champ `parrainId` au client.
            }
        }        // --- FIN LOGIQUE LIEN CLIENT-PARRAIN ---
           


        const hashedPassword = await doHash(password, 12);
        
        const newUserObject = {
            email,
            password: hashedPassword,
            role,
            nomComplet: otherData.nomComplet, // Sera undefined si non fourni et non requis par Joi pour ce rôle
            telephone: otherData.telephone,
        };

        if (role === 'client') {
            // Stocker le code saisi par le client (selon Option B ci-dessus)
            // Si Option A (erreur bloquante) est choisie, cette partie n'est atteinte que si le code est valide.
            if (otherData.codeParrainSaisi && otherData.codeParrainSaisi.trim() !== '') {
                newUserObject.codeParrainSaisi = otherData.codeParrainSaisi.toUpperCase(); // Stocker en majuscules pour cohérence
            }
             // Ajoutez ici d'autres champs spécifiques au client si nécessaire (ex: adresseLivraison)

            // stockage de  l'ID du parrain directement sur le client :
            if (parrainReferantTrouve) {
                newUserObject.idDuParrain = parrainReferantTrouve._id; 
            }
        } else if (role === 'boutique') {
            newUserObject.nomBoutique = otherData.nomBoutique;
            newUserObject.descriptionBoutique = otherData.descriptionBoutique;
            // Ajoutez ici d'autres champs spécifiques à la boutique
        } else if (role === 'parrain') {
            if (otherData.codePromoPersonnel) { // Si le parrain a fourni un code
                newUserObject.codePromoPersonnel = otherData.codePromoPersonnel.toUpperCase();
                 // ... autres champs boutique
                 // typeAbonnement aura sa valeur par défaut 'classic' du modèle
                 // limiteProduits sera définie par le hook pre-save basé sur typeAbonnement
                 // Si vous permettez de choisir l'abonnement à l'inscription :
                 // if (otherData.typeAbonnementSouhaite) {
                 //    newUserObject.typeAbonnement = otherData.typeAbonnementSouhaite;
                 // }
            }
            // Le codePromoPersonnel sera généré par le pre-save hook si non fourni
        }

        const newUser = new User(newUserObject);
        const result = await newUser.save();// Le hook pre-save s'exécute ici

        // Important: Ne pas renvoyer le mot de passe ou d'autres infos sensibles
        const userToReturn = { ...result.toObject() };
        delete userToReturn.password;
        delete userToReturn.verificationCode;
        delete userToReturn.verificationCodeValidation;
        delete userToReturn.forgotPasswordCode;
        delete userToReturn.forgotPasswordCodeValidation;
        // Si codePromoPersonnel a été généré, il sera dans 'result'
        
        // Vous pourriez vouloir envoyer un email de bienvenue ou de vérification ici

        await createNotification(
            result._id,
            'BIENVENUE',
            `Bienvenue sur NSBIO-TECH, ${result.nomComplet || result.email} ! Veuillez vérifier votre email pour activer votre compte.`,
            'Bienvenue !',
            '/profil/verification' // Exemple de lien interne
        )
        res.status(201).json({
            success: true,
            message: 'Votre compte a été créé avec succès.',
            user: userToReturn, // Renvoyer l'utilisateur créé (sans les infos sensibles)
        });

    } catch (error) {
        console.error("Erreur lors de l'inscription:", error);
        // Gérer les erreurs de duplication Mongoose (ex: email ou codePromoPersonnel)
        if (error.code === 11000) { // Erreur de clé dupliquée
             let field = Object.keys(error.keyValue)[0];
             field = field === 'email' ? 'L\'email' : `Le champ ${field}`;
             return res.status(409).json({
                 success: false,
                 message: `${field} est déjà utilisé.`,
             });
        }
        res.status(500).json({
            success: false,
            message: 'Une erreur est survenue lors de la création du compte.',
            error: error.message // Pour le débogage, à ne pas faire en prod
        });
    }
};

exports.signin = async (req, res) => {
    const { email, password } = req.body;
    try {
        const { error, value } = signinSchema.validate({ email, password });
        if (error) {
            return res.status(400).json({
                success: false,
                message: error.details[0].message,
            });
        }

        const existingUser = await User.findOne({ email }).select('+password'); // On a besoin du password ici
        if (!existingUser) {
            return res.status(404).json({ // 404 pour Not Found
                success: false,
                message: 'Utilisateur non trouvé.',
            });
        }

        const isPasswordValid = await doHashValidation(password, existingUser.password);

        if (!isPasswordValid) {
            return res.status(401).json({ // 401 pour Unauthorized
                success: false,
                message: 'Email ou mot de passe incorrect.',
            });
        }
        
        // Optionnel: Vérifier si l'utilisateur est 'verified' avant de permettre la connexion
        // if (!existingUser.verified) {
        //     return res.status(403).json({ // 403 Forbidden
        //         success: false,
        //         message: 'Veuillez vérifier votre compte avant de vous connecter. Un email de vérification vous a été envoyé.',
        //         // On pourrait ajouter une option pour renvoyer le code de vérification
        //     });
        // }


        const token = jwt.sign(
            {
                userId: existingUser._id,
                email: existingUser.email,
                role: existingUser.role, // Ajouter le rôle au token !
                verified: existingUser.verified,
            },
            process.env.TOKEN_SECRET,
            {
                expiresIn: '8h', // Ou '1d', etc.
            }
        );
        
        // Renvoyer les informations utilisateur de base (sans mot de passe, etc.)
        const userToReturn = {
            _id: existingUser._id,
            email: existingUser.email,
            role: existingUser.role,
            verified: existingUser.verified,
            nomComplet: existingUser.nomComplet, // Inclure les champs pertinents
            // ...autres champs à retourner si besoin (nomBoutique, etc.)
        };
        if (existingUser.role === 'parrain') {
            userToReturn.codePromoPersonnel = existingUser.codePromoPersonnel;
        }


        res.cookie('Authorization', `Bearer ${token}`, {
            expires: new Date(Date.now() + 8 * 3600000), // 8 heures
            httpOnly: process.env.NODE_ENV === 'production', // true en prod
            secure: process.env.NODE_ENV === 'production', // true en prod (nécessite HTTPS)
            sameSite: process.env.NODE_ENV === 'production' ? 'None' : 'Lax', // Important pour les cookies cross-site en prod
        })
        .json({
            success: true,
            token, // Renvoyer le token dans le corps est courant pour les applis mobiles
            message: 'Connexion réussie.',
            user: userToReturn,
        });
    } catch (error) {
        console.error("Erreur lors de la connexion:", error);
        res.status(500).json({
            success: false,
            message: 'Une erreur est survenue lors de la connexion.',
            error: error.message
        });
    }
};


exports.adminSignin = async (req, res) => {
    const { email, password } = req.body;
    try {
        // Vous pouvez utiliser un schéma Joi spécifique pour la connexion admin si besoin
        const { error, value } = signinSchema.validate({ email, password });
        if (error) {
            return res.status(400).json({
                success: false,
                message: error.details[0].message,
            });
        }

        const existingUser = await User.findOne({ email }).select('+password');
        if (!existingUser) {
            return res.status(401).json({ success: false, message: 'Identifiants invalides.' }); // Message générique
        }

        // --- VÉRIFICATION CRUCIALE DU RÔLE ---
        if (existingUser.role !== 'admin') {
            return res.status(403).json({ success: false, message: 'Accès non autorisé.' });
        }

        const isPasswordValid = await doHashValidation(password, existingUser.password);
        if (!isPasswordValid) {
            return res.status(401).json({ success: false, message: 'Identifiants invalides.' });
        }

        // Optionnel: Vérifier si le compte admin est 'verified' (peut-être pas nécessaire si créé par script)
        // if (!existingUser.verified) { /* ... */ }

        const token = jwt.sign(
            { userId: existingUser._id, email: existingUser.email, role: existingUser.role },
            process.env.TOKEN_SECRET,
            { expiresIn: process.env.ADMIN_TOKEN_EXPIRES_IN || '2h' } // Durée de session plus courte pour admin ?
        );

        const userToReturn = {  _id: existingUser._id,
            email: existingUser.email,
            role: existingUser.role,
            verified: existingUser.verified,
            nomComplet: existingUser.nomComplet,  };

        // Pas de cookie ici si le panel admin est une SPA qui gère le token elle-même
        // Ou si vous voulez un cookie, configurez-le avec Path=/admin pour le limiter
        res.json({
            success: true,
            token,
            message: 'Connexion admin réussie.',
            user: userToReturn,
        });

    } catch (error) {
        console.error("Erreur adminSignin:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.' });
    }
};
// Les autres fonctions (signout, SendVerificationCode, etc.) devraient fonctionner
// Tel quel, mais vérifiez que les messages d'erreur sont clairs.
// Pensez à ce que vous voulez retourner dans `req.user` après `identifier` (le rôle est important)

exports.signout = async (req, res) => {
    res
    .clearCookie('Authorization', {
        httpOnly: process.env.NODE_ENV === 'production',
        secure: process.env.NODE_ENV === 'production',
        sameSite: process.env.NODE_ENV === 'production' ? 'None' : 'Lax',
    })
    .status(200)
    .json({ success: true, message: 'Déconnexion réussie.' });
};


exports.SendVerificationCode = async (req, res) => {
    // Note: Le middleware 'identifier' est utilisé ici, donc req.user.email devrait être disponible
    // Si vous voulez permettre l'envoi de code sans être connecté, retirez 'identifier' et prenez email du body.
    // Pour cet exemple, on suppose que l'utilisateur est connecté mais non vérifié.
    const email = req.user.email; // Ou req.body.email si l'utilisateur n'est pas forcément connecté

    if (!email) {
         return res.status(400).json({ success: false, message: 'Email manquant.' });
    }

    try {
        const existingUser = await User.findOne({ email });
        if (!existingUser) {
            return res
            .status(404)
            .json({ success: false, message: 'Utilisateur non trouvé.' });
        }
        if (existingUser.verified) {
            return res
            .status(400)
            .json({ success: false, message: 'Votre compte est déjà vérifié !' });
        }
        const codeValue = Math.floor(100000 + Math.random() * 900000).toString(); // Code à 6 chiffres

        // Configuration de l'email (assurez-vous que le HTML est correct)
        const mailOptions = {
            from: `"NSBIO-TECH" <${process.env.NODE_CODE_SENDING_EMAIL_ADDRESS}>`, // Mettez un nom d'expéditeur
            to: existingUser.email,
            subject: "Code de vérification de compte NSBIO-TECH",
            html: `
                <div style="font-family: Arial, sans-serif; color: #333;">
                    <h2>Vérification de votre compte NSBIO-TECH</h2>
                    <p>Bonjour ${existingUser.nomComplet || existingUser.email},</p>
                    <p>Merci de vous être inscrit sur NSBIO-TECH. Veuillez utiliser le code suivant pour vérifier votre compte :</p>
                    <p style="font-size: 24px; font-weight: bold; color: #007bff;">${codeValue}</p>
                    <p>Ce code est valide pour 5 minutes.</p>
                    <p>Si vous n'avez pas demandé ce code, veuillez ignorer cet email.</p>
                    <p>L'équipe NSBIO-TECH</p>
                </div>
            `
        };
        
        let info = await transport.sendMail(mailOptions);

        if (info.accepted && info.accepted.includes(existingUser.email)) {
           const hashedCodeValue = hmacProcess(
                codeValue,
                process.env.HMAC_VERIFICATION_CODE_SECRET
            );
           existingUser.verificationCode = hashedCodeValue;
           existingUser.verificationCodeValidation = new Date(Date.now() + 5 * 60 * 1000); // Valide pour 5 minutes
           await existingUser.save();
           return res.status(200).json({ success:true, message: 'Un code de vérification a été envoyé à votre adresse email.' });
        }
        // Si l'email n'est pas dans info.accepted, il y a eu un problème
        console.error("Échec de l'envoi de l'email de vérification:", info);
        res.status(500).json({ success: false, message: "Échec de l'envoi du code de vérification." });
    }
    catch(error){
        console.error("Erreur lors de l'envoi du code de vérification:", error);
        res.status(500).json({ success: false, message: "Une erreur est survenue." });
    }
};

exports.verifyVerificationCode = async (req, res) => {
    // De même, req.user.email est disponible grâce à 'identifier'
    // Si on veut permettre la vérification sans être connecté (ex: lien direct d'email),
    // il faudra passer l'email dans le body et ajuster.
    const email = req.user.email; // Ou req.body.email
    const { providedCode } = req.body;

    if (!email || !providedCode) {
        return res.status(400).json({ success: false, message: 'Email ou code manquant.'});
    }
    
    try {
        // Valider le format du code si pas déjà fait par Joi au niveau de la route
        const { error: joiError } = accepCodeSchema.validate({ email, providedCode }); // Adaptez accepCodeSchema si besoin
        if (joiError) {
            return res.status(400).json({
                success: false,
                message: joiError.details[0].message,
            });
        }
        
        const existingUser = await User.findOne({email}).select("+verificationCode +verificationCodeValidation");
        if(!existingUser){
            return res
            .status(404)
            .json({ success: false, message: 'Utilisateur non trouvé.' });
        }
        if(existingUser.verified){
            return res
            .status(400)
            .json({ success: false, message: 'Votre compte est déjà vérifié !'});
        }
        if(!existingUser.verificationCode || !existingUser.verificationCodeValidation){
            return res
            .status(400)
            .json({ success: false, message: 'Aucun code de vérification en attente ou une erreur est survenue.' });
        }
        if(Date.now() > new Date(existingUser.verificationCodeValidation).getTime()){
            existingUser.verificationCode = undefined; // Invalider le code
            existingUser.verificationCodeValidation = undefined;
            await existingUser.save();
            return res
            .status(400)
            .json({ success: false, message: 'Le code de vérification a expiré. Veuillez en demander un nouveau.' });
        }
        
        const hashedCodeValue = hmacProcess(providedCode.toString(), process.env.HMAC_VERIFICATION_CODE_SECRET);

        if(hashedCodeValue === existingUser.verificationCode){
            existingUser.verified = true;
            existingUser.verificationCode = undefined;
            existingUser.verificationCodeValidation = undefined;
            await existingUser.save();
            return res
            .status(200)
            .json({ success: true, message: 'Votre compte a été vérifié avec succès !' });
        }
        // Si le code est incorrect
        return res
        .status(400)
        .json({ success: false, message: 'Code de vérification incorrect.' });
    }
    catch(error){
        console.error("Erreur lors de la vérification du code:", error);
        res.status(500).json({ success: false, message: 'Une erreur est survenue.' });
    }
};


// ... Assurez-vous que changePassword et les fonctions forgotPassword
// gèrent bien les messages d'erreur et la logique.
// Par exemple, pour forgotPassword, le `html` de l'email devrait être personnalisé.

exports.SendForgotPasswordCode = async (req, res) => {
    const { email } = req.body; // Ici, l'email vient du body car l'utilisateur n'est pas connecté
     if (!email) {
         return res.status(400).json({ success: false, message: 'Email manquant.' });
    }
    try {
        const existingUser = await User.findOne({ email });
        if (!existingUser) {
            // Ne pas révéler si l'email existe ou non pour des raisons de sécurité,
            // mais pour le développement, un message clair est utile.
            // En production, renvoyez toujours un message générique.
            return res
            .status(404)
            .json({ success: false, message: 'Utilisateur non trouvé.' });
        }
        const codeValue = Math.floor(100000 + Math.random() * 900000).toString();
        
        const mailOptions = {
            from: `"NSBIO-TECH" <${process.env.NODE_CODE_SENDING_EMAIL_ADDRESS}>`,
            to: existingUser.email,
            subject: "Réinitialisation de votre mot de passe NSBIO-TECH",
            html: `
                <div style="font-family: Arial, sans-serif; color: #333;">
                    <h2>Réinitialisation de mot de passe</h2>
                    <p>Bonjour ${existingUser.nomComplet || existingUser.email},</p>
                    <p>Nous avons reçu une demande de réinitialisation de mot de passe pour votre compte NSBIO-TECH. Utilisez le code suivant :</p>
                    <p style="font-size: 24px; font-weight: bold; color: #007bff;">${codeValue}</p>
                    <p>Ce code est valide pour 5 minutes.</p>
                    <p>Si vous n'avez pas demandé cette réinitialisation, veuillez ignorer cet email.</p>
                    <p>L'équipe NSBIO-TECH</p>
                </div>
            `
        };

        let info = await transport.sendMail(mailOptions);

        if(info.accepted && info.accepted.includes(existingUser.email)){
           const hashedCodeValue = hmacProcess(
                codeValue,
                process.env.HMAC_VERIFICATION_CODE_SECRET // Utilisez une clé différente si vous voulez plus de sécurité
            );
           existingUser.forgotPasswordCode = hashedCodeValue;
           existingUser.forgotPasswordCodeValidation = new Date(Date.now() + 5 * 60 * 1000); // Valide 5 minutes
           await existingUser.save();
           return res.status(200).json({ success:true, message: 'Un code de réinitialisation de mot de passe a été envoyé.' });
        }
        console.error("Échec de l'envoi de l'email de mot de passe oublié:", info);
        res.status(500).json({ success: false, message: "Échec de l'envoi du code." });
    }
    catch(error){
        console.error("Erreur SendForgotPasswordCode:", error);
        res.status(500).json({ success: false, message: 'Une erreur est survenue.' });
    }
};

exports.verifyForgotPasswordCode = async (req, res) => {
    const { email, providedCode, newpassword } = req.body;
     if (!email || !providedCode || !newpassword) {
        return res.status(400).json({ success: false, message: 'Données manquantes.'});
    }
    try {
        const { error: joiError } = acceptFPSchema.validate({ email, newpassword, providedCode });
        if (joiError) {
            return res.status(400).json({
                success: false,
                message: joiError.details[0].message,
            });
        }
        
        const existingUser = await User.findOne({email}).select("+forgotPasswordCode +forgotPasswordCodeValidation +password");
        if(!existingUser){
            return res
            .status(404)
            .json({ success: false, message: 'Utilisateur non trouvé.' });
        }
      
        if(!existingUser.forgotPasswordCode || !existingUser.forgotPasswordCodeValidation){
            return res
            .status(400)
            .json({ success: false, message: 'Aucun code de réinitialisation en attente ou une erreur est survenue.' });
        }
        if(Date.now() > new Date(existingUser.forgotPasswordCodeValidation).getTime()){
            existingUser.forgotPasswordCode = undefined;
            existingUser.forgotPasswordCodeValidation = undefined;
            await existingUser.save();
            return res
            .status(400)
            .json({ success: false, message: 'Le code de réinitialisation a expiré.' });
        }
        
        const hashedCodeValue = hmacProcess(providedCode.toString(), process.env.HMAC_VERIFICATION_CODE_SECRET);

        if(hashedCodeValue === existingUser.forgotPasswordCode){
            const hashedPassword = await doHash(newpassword, 12);
            existingUser.password = hashedPassword;
            existingUser.forgotPasswordCode = undefined;
            existingUser.forgotPasswordCodeValidation = undefined;
            existingUser.verified = true; // On peut considérer que l'utilisateur est vérifié s'il réinitialise son mdp
            await existingUser.save();
            return res
            .status(200)
            .json({ success: true, message: 'Votre mot de passe a été mis à jour avec succès !' });
        }
        return res
        .status(400)
        .json({ success: false, message: 'Code de réinitialisation incorrect.' });
    }
    catch(error){
        console.error("Erreur verifyForgotPasswordCode:", error);
        res.status(500).json({ success: false, message: 'Une erreur est survenue.' });
    }
};

exports.changePassword = async (req, res) => {
    const userId = req.user.userId;  // récupère via JWT
    const { oldpassword, newpassword } = req.body;
    try {
        const { error: joiError } = changePasswordSchema.validate({ oldpassword, newpassword });
        if (joiError) {
            return res.status(400).json({
                success: false,
                message: joiError.details[0].message,
            });
        }

        const existingUser = await User.findOne({ _id: userId }).select("+password +verified");

        if (!existingUser) {
            return res.status(404).json({
                success: false,
                message: 'Utilisateur non trouvé.',
            });
        }

        // Optionnel: exiger la vérification pour changer le mot de passe si souhaité
        // if (!existingUser.verified) {
        //     return res.status(403).json({
        //         success: false,
        //         message: 'Veuillez vérifier votre compte avant de changer le mot de passe.'
        //     });
        // }

        const isOldPasswordValid = await doHashValidation(oldpassword, existingUser.password);
        if (!isOldPasswordValid) {
            return res.status(401).json({
                success: false,
                message: 'Ancien mot de passe incorrect.',
            });
        }

        const hashedPassword = await doHash(newpassword, 12);
        existingUser.password = hashedPassword;
        await existingUser.save();

        return res.status(200).json({
            success: true,
            message: 'Votre mot de passe a été mis à jour avec succès !',
        });
    } catch (error) {
        console.error("Erreur changePassword:", error);
        res.status(500).json({
            success: false,
            message: 'Une erreur est survenue lors de la mise à jour du mot de passe.',
             error: error.message
        });
    }
};