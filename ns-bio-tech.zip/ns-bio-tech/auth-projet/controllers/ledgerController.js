// controllers/ledgerController.js
const LedgerEntry = require('../models/ledgerEntryModel');

exports.getLedgerEntries = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 20; // Plus d'entrées par page
        const skip = (page - 1) * limit;

        const { eventType, userId } = req.query;
        let query = {};
        if (eventType) query.eventType = eventType;
        if (userId) query.relatedUserIds = new mongoose.Types.ObjectId(userId);


        const entries = await LedgerEntry.find(query)
            .sort({ eventTimestamp: -1, createdAt: -1 }) // Trier par timestamp de l'événement puis par date de création
            .skip(skip)
            .limit(limit)
            .populate('relatedUserIds', 'email role nomComplet');

        const totalEntries = await LedgerEntry.countDocuments(query);

        res.status(200).json({
            success: true,
            currentPage: page,
            totalPages: Math.ceil(totalEntries / limit),
            totalEntriesCount: totalEntries,
            entries: entries
        });
    } catch (error) {
        console.error("Erreur getLedgerEntries:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};

exports.getLedgerEntryByHash = async (req, res) => {
    try {   
        const { hash } = req.params;
        const entry = await LedgerEntry.findOne({ entryHash: hash })
                                   .populate('relatedUserIds', 'email role nomComplet');
        if(!entry){
            return res.status(404).json({ success: false, message: 'Entrée de registre non trouvée pour ce hash.'});
        }
        res.status(200).json({ success: true, entry });
    } catch (error) {
        console.error("Erreur getLedgerEntryByHash:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
}