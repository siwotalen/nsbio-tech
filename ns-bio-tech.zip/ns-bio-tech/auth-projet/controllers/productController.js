// controllers/productController.js
const Product = require('../models/productModel');
const User = require('../models/usersModel'); // Au cas où on en aurait besoin
const Joi = require('joi'); // Pour la validation
const mongoose = require('mongoose'); // Pour la validation de l'ID de produit
const { ObjectId } = mongoose.Types; // Pour la validation de l'ID de produit
const { createNotification, createAdminNotification } = require('../utils/notificationManager'); // <<--- IMPORT



// Schéma de validation Joi pour la création/mise à jour de produit
const productSchemaValidation = Joi.object({
    nom: Joi.string().min(3).max(100).required().messages({
        'string.empty': 'Le nom du produit est requis.',
        'string.min': 'Le nom du produit doit avoir au moins 3 caractères.',
    }),
    description: Joi.string().max(1000).allow('').optional(),
    prix: Joi.number().positive().required().messages({
        'number.base': 'Le prix doit être un nombre.',
        'number.positive': 'Le prix doit être un nombre positif.',
        'any.required': 'Le prix est requis.',
    }),
    imageUrl: Joi.string().uri().allow('').optional().messages({
        'string.uri': 'L\'URL de l\'image doit être une URL valide.'
    }),
    categorie: Joi.string().max(50).allow('').optional(),
    disponible: Joi.boolean().optional(),
    typeElement: Joi.string().valid('produit', 'service').required().messages({
        'any.required': 'Le type (produit ou service) est requis.',
        'any.only': 'Le type doit être "produit" ou "service".'
    }),
    quantiteEnStock: Joi.when('typeElement', {
        is: 'produit',
        then: Joi.number().integer().min(0).required().messages({ // Requis si c'est un produit
            'number.base': 'La quantité en stock doit être un nombre.',
            'number.min': 'La quantité en stock ne peut pas être négative.',
            'any.required': 'La quantité en stock est requise pour un produit.'
        }),
        otherwise: Joi.number().integer().min(0).optional().allow(null) // Optionnel et peut être null si service
    }),
    dureeServiceMinutes: Joi.when('typeElement', {
        is: 'service',
        then: Joi.number().integer().min(0).optional().required().messages({ // Requis si c'est un produit
            'number.base': 'La durée de service doit être un nombre.',
            'number.min': 'La durée de service ne peut pas être négative.',
            'any.required': 'La durée de service est requise pour un service.'
        }),
        otherwise: Joi.forbidden() // Interdit si ce n'est pas un service
        
    }),
    lieuService: Joi.when('typeElement', {
        is: 'service',
        then: Joi.string().trim().max(100).optional().required().messages({ // Requis si c'est un produit
            'string.empty': 'Le lieu de service est requis.',
        }),
        otherwise: Joi.forbidden() // Interdit si ce n'est pas un service
    })
});

const rejectProductSchema = Joi.object({
    motifRejet: Joi.string().min(5).max(500).required().messages({
        'string.empty': 'Le motif de rejet est requis.',
        'string.min': 'Le motif de rejet doit contenir au moins 5 caractères.'
    })
});

exports.createProduct = async (req, res) => {
    try {
     
        // 1. Valider les données entrantes
        const { error, value: productData } = productSchemaValidation.validate(req.body);
        if (error) {
            return res.status(400).json({ success: false, message: error.details[0].message });
        }

        // 2. Récupérer l'ID du vendeur (boutique) depuis le token (req.user est défini par le middleware 'identifier')
        const idVendeur = req.user.userId;

       // --- VÉRIFICATION DE LA LIMITE D'ABONNEMENT ---
       const boutique = await User.findById(idVendeur);
       if (!boutique || boutique.role !== 'boutique') {
           // Ce cas ne devrait pas arriver si checkRole(['boutique']) est utilisé dans la route
           return res.status(403).json({ success: false, message: "Action non autorisée. Compte vendeur non valide." });
       }

       // Compter les produits existants de cette boutique.
       // Décidez si vous comptez TOUS les produits (y compris 'en_attente', 'rejete')
       // ou seulement les produits 'approuves' ou 'disponibles'.
       // Pour une limite stricte, on compte généralement tous les produits créés par la boutique.
       const nombreProduitsActuels = await Product.countDocuments({ idVendeur: idVendeur });

       if (nombreProduitsActuels >= boutique.limiteProduits) {
           return res.status(403).json({
               success: false,
               message: `Vous avez atteint la limite de ${boutique.limiteProduits} produits pour votre abonnement "${boutique.typeAbonnement}". Veuillez mettre à niveau votre abonnement pour ajouter plus de produits.`
           });
       }
       // --- FIN VÉRIFICATION LIMITE ---
         if (productData.typeElement === 'service') {
            // productData.quantiteEnStock = undefined; // Ou null, Joi.optional().allow(null) le gère
        } else if (productData.typeElement === 'produit') {
            // productData.dureeServiceMinutes = undefined;
            // productData.lieuService = undefined;
        }

        // 3. Créer le produit
        const newProduct = new Product({
            ...productData, // nom, description, prix, imageUrl, categorie, disponible
            idVendeur: idVendeur,  // statutValidation sera 'en_attente' par défaut grâce au modèle
        });


        const savedProduct = await newProduct.save();
        // Notif pour la boutique
        await createNotification(
            req.user.userId, // idVendeur
            'PRODUIT_SOUMIS_BOUTIQUE',
            `Votre produit "${savedProduct.nom}" a été soumis et est en attente de validation par nos équipes.`,
            'Produit Soumis',
            `/boutique/produits/${savedProduct._id}` // Lien vers le produit dans le dashboard boutique
        );

        // Notif pour les admins
        const boutique1 = await User.findById(req.user.userId).select('nomBoutique');
        await createAdminNotification(
            'PRODUIT_VALIDATION_ADMIN',
            `Nouveau produit "${savedProduct.nom}" soumis par la boutique "${boutique1 ? boutique1.nomBoutique : req.user.userId}" et nécessite une validation.`,
            'Nouveau Produit en Attente',
            `/admin/produits/validation/${savedProduct._id}` // Lien vers la page de modération admin
        );

        res.status(201).json({
            success: true,
            message: 'Produit ajouté avec succès et en attente de validation.',
            product: savedProduct,
        });

    } catch (err) {
        console.error("Erreur createProduct:", err);
        res.status(500).json({ success: false, message: 'Erreur serveur lors de l\'ajout du produit.', error: err.message });
    }
};

// Seuls les produits 'approuves' et 'disponibles' sont visibles par les clients
exports.getAllProducts = async (req, res) => {
    try {
        const { search, category } = req.query; // Récupérer les paramètres de requête
        let query = { disponible: true, statutValidation: 'approuve' }; // Modification

        if (search) {
            query.$or = [ // Recherche sur le nom OU la description
                { nom: { $regex: search, $options: 'i' } }, // 'i' pour insensible à la casse
                { description: { $regex: search, $options: 'i' } }
            ];
        }
        if (category) {
            query.categorie = { $regex: category, $options: 'i' };
        }

        const products = await Product.find(query)
            .populate('idVendeur', 'nomBoutique email')// Pour afficher nom de la boutique et email du vendeur
            .sort({ createdAt: -1 });

        res.status(200).json({
            success: true,
            count: products.length, // Utile pour le frontend
            products: products,
        });
    } catch (err) {
        console.error("Erreur getAllProducts:", err);
        res.status(500).json({ success: false, message: 'Erreur serveur lors de la récupération de tous les produits.', error: err.message });
    }
};

// --- getProductsByVendor (La boutique voit tous ses produits, quel que soit leur statut de validation) ---
exports.getProductsByVendor = async (req, res) => {
    try {
        const idVendeur = req.user.userId;
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10; // Ou une limite par défaut
        const skip = (page - 1) * limit;

        let query = { idVendeur: idVendeur };
        if (req.query.statutValidation) {
            query.statutValidation = req.query.statutValidation;
        }
        if (req.query.typeElement) {
            query.typeElement = req.query.typeElement;
        }

        const products = await Product.find(query)
            .sort({ createdAt: req.query.sort === 'createdAt_desc' ? -1 : 1 }) // Exemple de tri
            .skip(skip)
            .limit(limit);
        
        const totalProducts = await Product.countDocuments(query);

        res.status(200).json({
            success: true,
            products: products,
            currentPage: page,
            totalPages: Math.ceil(totalProducts / limit),
            totalProducts: totalProducts
        });
    } catch (err) {
        console.error("Erreur getProductsByVendor:", err);
        res.status(500).json({ success: false, message: 'Erreur serveur lors de la récupération des produits.', error: err.message });
    }

};

// --- getSingleProduct (Le client ne voit que si 'approuve' et 'disponible') ---
exports.getSingleProduct = async (req, res) => {
    try {
        const { productId } = req.params;
        if (!mongoose.Types.ObjectId.isValid(productId)) { // Vérifier la validité de l'ID
            return res.status(400).json({ success: false, message: 'ID de produit invalide.' });
        }

        const product = await Product.findById(productId)
                                 .populate('idVendeur', 'nomBoutique email'); // Pour afficher des infos du vendeur et l'email

        
        // Vérifier si le produit existe et s'il est disponible
        if (!product) {
            return res.status(404).json({ success: false, message: 'Produit non trouvé.' });
        }

        
        // Logique pour déterminer si l'utilisateur actuel est le vendeur de ce produit
        let isOwner = false;
        if (req.user && req.user.userId && product.idVendeur._id.toString() === req.user.userId) {
            isOwner = true;
        }
        // Logique pour déterminer si l'utilisateur actuel est un admin
        let isAdmin = false;
        if (req.user && req.user.role === 'admin') { // Supposant que vous ayez un rôle admin
            isAdmin = true;
        }
       
        // Le produit n'est visible publiquement que s'il est disponible ET approuvé
        // Le propriétaire ou un admin peuvent le voir quel que soit son statut de validation (mais pas s'il n'est pas disponible et qu'ils ne sont pas proprio)
        if (!product.disponible && !isOwner) {
             return res.status(404).json({ success: false, message: 'Produit non disponible actuellement.' });
        }

        if (product.statutValidation !== 'approuve' && !isOwner && !isAdmin) {
            return res.status(404).json({ success: false, message: 'Produit en attente de validation ou non approuvé.' });
        }
        res.status(200).json({ success: true, product });
    } catch (err) {
        console.error("Erreur getSingleProduct:", err);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: err.message });
    }
};

// Récupérer les produits en attente de validation (pour admin/modérateur)
exports.getPendingProducts = async (req, res) => {
    try {
        const pendingProducts = await Product.find({ statutValidation: 'en_attente' })
            .populate('idVendeur', 'nomBoutique email')
            .sort({ createdAt: 1 }); // Les plus anciens en premier

        res.status(200).json({
            success: true,
            count: pendingProducts.length,
            products: pendingProducts
        });
    } catch (error) {
        console.error("Erreur getPendingProducts:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};

// Approuver un produit (pour admin/modérateur)
exports.approveProduct = async (req, res) => {
    try {
        const { productId } = req.params;
        if (!mongoose.Types.ObjectId.isValid(productId)) {
            return res.status(400).json({ success: false, message: 'ID de produit invalide.' });
        }

        const product = await Product.findById(productId);
        if (!product) {
            return res.status(404).json({ success: false, message: 'Produit non trouvé.' });
        }

        if (product.statutValidation === 'approuve') {
            return res.status(400).json({ success: false, message: 'Ce produit est déjà approuvé.' });
        }

        product.statutValidation = 'approuve';
        product.motifRejet = ''; // Effacer un éventuel motif de rejet précédent
        await product.save();

        // Optionnel: Envoyer une notification au vendeur
        // ...

        res.status(200).json({ success: true, message: `Produit "${product.nom}" approuvé avec succès.`, product });
    } catch (error) {
        console.error("Erreur approveProduct:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};

// Rejeter un produit (pour admin/modérateur)
exports.rejectProduct = async (req, res) => {
    try {
        const { productId } = req.params;
        const { error: joiError, value: joiValue } = rejectProductSchema.validate(req.body); // Valider le motif de rejet

        if (joiError) {
            return res.status(400).json({ success: false, message: joiError.details[0].message });
        }
        
        if (!mongoose.Types.ObjectId.isValid(productId)) {
            return res.status(400).json({ success: false, message: 'ID de produit invalide.' });
        }

        const product = await Product.findById(productId);
        if (!product) {
            return res.status(404).json({ success: false, message: 'Produit non trouvé.' });
        }

        if (product.statutValidation === 'rejete') {
             return res.status(400).json({ success: false, message: 'Ce produit est déjà rejeté.' });
        }


        product.statutValidation = 'rejete';
        product.motifRejet = joiValue.motifRejet; // Utiliser le motif validé
        await product.save();

        // Optionnel: Envoyer une notification au vendeur avec le motif
        // ...

        res.status(200).json({ success: true, message: `Produit "${product.nom}" rejeté avec succès.`, product });
    } catch (error) {
        console.error("Erreur rejectProduct:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};

// Optionnel pour le proto : updateProduct
exports.updateProduct = async (req, res) => {
    try {
        const { productId } = req.params;
        const idVendeur = req.user.userId;

        const { error, value: productDataToUpdate  } = productSchemaValidation.validate(req.body);
        if (error) {
            return res.status(400).json({ success: false, message: error.details[0].message });
        }

        const product = await Product.findById(productId);

        if (!product) {
            return res.status(404).json({ success: false, message: 'Produit non trouvé.' });
        }

        // Vérifier si l'utilisateur connecté est le propriétaire du produit
        if (product.idVendeur.toString() !== idVendeur) {
            return res.status(403).json({ success: false, message: 'Action non autorisée. Vous n\'êtes pas le propriétaire de ce produit.' });
        }

        // Si typeElement est modifié, il faut potentiellement nettoyer les anciens champs
        if (productDataToUpdate.typeElement && productDataToUpdate.typeElement !== product.typeElement) {
            if (productDataToUpdate.typeElement === 'service') {
                product.quantiteEnStock = 0; // Ou undefined/null selon votre modèle
            } else if (productDataToUpdate.typeElement === 'produit') {
                product.dureeServiceMinutes = undefined;
                product.lieuService = undefined;
            }
        }


      // Appliquer les mises à jour
      Object.assign(product, productDataToUpdate);
      // Si un produit devient service, quantiteEnStock doit être mis à jour via Joi ou manuellement ici
      // Si un service devient produit, duree/lieu doivent être mis à jour
      // Joi.forbidden() dans le schéma de validation devrait empêcher d'envoyer des champs inappropriés
      // pour le typeElement actuel lors de la mise à jour.
      // Si typeElement lui-même est mis à jour, la logique ci-dessus aide à nettoyer.pdatedProduct = await product.save();

        res.status(200).json({ success: true, message: 'Produit mis à jour avec succès!', product: productDataToUpdate });

    } catch (err) {
        console.error("Erreur updateProduct:", err);
        if (err.kind === 'ObjectId') { // Si productId n'est pas un ObjectId valide
             return res.status(400).json({ success: false, message: 'ID de produit invalide.' });
        }
        res.status(500).json({ success: false, message: 'Erreur serveur lors de la mise à jour du produit.', error: err.message });
    }
};

// Optionnel pour le proto : deleteProduct
exports.deleteProduct = async (req, res) => {
    try {
        const { productId } = req.params;
        const idVendeur = req.user.userId;

        const product = await Product.findById(productId);

        if (!product) {
            return res.status(404).json({ success: false, message: 'Produit non trouvé.' });
        }

        if (product.idVendeur.toString() !== idVendeur) {
            return res.status(403).json({ success: false, message: 'Action non autorisée. Vous n\'êtes pas le propriétaire de ce produit.' });
        }

        await product.deleteOne(); // Utilisez deleteOne() sur l'instance du document

        res.status(200).json({ success: true, message: 'Produit supprimé avec succès!' });

    } catch (err) {
        console.error("Erreur deleteProduct:", err);
         if (err.kind === 'ObjectId') {
             return res.status(400).json({ success: false, message: 'ID de produit invalide.' });
        }
        res.status(500).json({ success: false, message: 'Erreur serveur lors de la suppression du produit.', error: err.message });
    }
};

