// controllers/orderController.js
const Order = require('../models/orderModel'); // Si vous créez le modèle
const User = require('../models/usersModel');
const Product = require('../models/productModel');
const Joi = require('joi');
const mongoose = require('mongoose');
const Commission = require('../models/commissionModel');
const { logLedgerEvent } = require('../utils/ledgerLogger');
const { createNotification, createAdminNotification } = require('../utils/notificationManager');




const simulateOrderSchema = Joi.object({
    // idClient sera pris du token, pas besoin de le valider ici
    produits: Joi.array().items(Joi.object({
        idProduit: Joi.string().required(), // Valider que c'est un ObjectId valide plus tard
        quantite: Joi.number().integer().min(1).required(),
        prixUnitaire: Joi.number().positive().allow('') // Le prix sera récupéré du backend pour sécurité
    })).min(1).required(),
    codePromo: Joi.string().trim().allow('').optional(),
});

exports.simulateOrder = async (req, res) => {
    try {
        const { error, value } = simulateOrderSchema.validate(req.body);
        if (error) {
            return res.status(400).json({ success: false, message: error.details[0].message });
        }

        const idClient = req.user.userId;
        const { produits: produitsInput, codePromo } = value;

        
        // 1. Récupérer le client avec ses informations de paiement
        const client = await User.findById(idClient).select('+informationsPaiementSimulees.soldeCompteSimule');
        if (!client) {
            return res.status(404).json({ success: false, message: "Client non trouvé." });
        }

        let sousTotal = 0;
        let produitsPourCommande = [];
        let operationsStock = []; // Pour gérer les mises à jour de stock de manière atomique (plus tard)
        let produitsPourCommandeDetails = [];
        // 2. Valider les produits et calculer le sous-total
        for (const item of produitsInput) {
            if (!mongoose.Types.ObjectId.isValid(item.idProduit)) {
                return res.status(400).json({ success: false, message: `ID de produit invalide: ${item.idProduit}` });
            }
            const productDoc = await Product.findById(item.idProduit);

            if (!productDoc || !productDoc.disponible || productDoc.statutValidation !== 'approuve') {
                return res.status(404).json({ success: false, message: `Produit "${productDoc ? productDoc.nom : item.idProduit}" non trouvé, indisponible ou non approuvé.` });
            }

             // --- VÉRIFICATION ET GESTION DES STOCKS ---
             if (productDoc.typeElement === 'produit') {
                if (productDoc.quantiteEnStock < item.quantite) {
                    return res.status(400).json({
                        success: false,
                        message: `Stock insuffisant pour le produit "${productDoc.nom}". Disponible : ${productDoc.quantiteEnStock}, demandé : ${item.quantite}.`
                    });
                }
                // Préparer l'opération de décrémentation du stock (sera appliquée si tout est OK)


                operationsStock.push({
                    updateOne: {
                        filter: { _id: productDoc._id, quantiteEnStock: { $gte: item.quantite } }, // Condition pour éviter race condition
                        update: { $inc: { quantiteEnStock: -item.quantite } }
                    }
                });
            }
            // --- FIN VÉRIFICATION STOCKS ---

            sousTotal += productDoc.prix * item.quantite;
            produitsPourCommandeDetails.push({
                idProduit: productDoc._id,
                nomProduit: productDoc.nom,
                quantite: item.quantite,
                prixUnitaire: productDoc.prix,
                typeElement: productDoc.typeElement, // Stocker le type
                // Dénormaliser les infos spécifiques si c'est un service
                ...(productDoc.typeElement === 'service' && {
                    dureeServiceMinutes: productDoc.dureeServiceMinutes,
                    lieuService: productDoc.lieuService
                })
            });
        }

        let reductionAppliquee = 0;
        let idParrainReferant = null;
        const POURCENTAGE_REDUCTION_CLIENT = 0.05; // Ex: 5% de réduction pour le client si code parrain
        const POURCENTAGE_COMMISSION_PARRAIN_REEL = 0.10; // Ex: 10% pour le parrain


        // 3. Vérifier et appliquer le code promo
        if (codePromo) {
            const parrain = await User.findById(idClient).select('+informationsPaiementSimulees.soldeCompteSimule'); // Récupérer le parrain pour créditer sa commission
            // Correction : on cherche le parrain par son code promo, pas l'idClient
            const parrainTrouve = await User.findOne({ codePromoPersonnel: codePromo.toUpperCase(), role: 'parrain' }).select('+informationsPaiementSimulees.soldeCompteSimule');

            if (parrainTrouve && parrainTrouve._id.toString() !== idClient) {
                reductionAppliquee = sousTotal * POURCENTAGE_REDUCTION_CLIENT;
                idParrainReferant = parrainTrouve._id; // Stocker l'ID du parrain trouvé
            } else {
                return res.status(400).json({ success: false, message: "Code promo invalide ou vous ne pouvez pas utiliser votre propre code." });
                
                // ("Code promo invalide ou tentative d'auto-parrainage ignorée.");
                 // Pour le proto, on peut juste ne pas appliquer la réduction
            }
        }


        let totalCommande = sousTotal - reductionAppliquee;

        // --- SIMULATION DE PAIEMENT PAR LE CLIENT ---
          if (totalCommande > 0) {
            if (!client.informationsPaiementSimulees || client.informationsPaiementSimulees.typePaiementPrincipal === 'non_configure') {
                return res.status(402).json({ success: false, message: "Veuillez configurer une méthode de paiement pour finaliser l'achat." });
            }
            if (client.informationsPaiementSimulees.soldeCompteSimule < totalCommande) {
                return res.status(402).json({
                    success: false,
                    message: `Solde insuffisant (${client.informationsPaiementSimulees.soldeCompteSimule} FCFA) pour payer la commande (${totalCommande.toFixed(2)} FCFA).`
                });
            }
            // Déduire le montant du solde simulé du client
            client.informationsPaiementSimulees.soldeCompteSimule -= totalCommande;
            await client.save(); // Sauvegarder le nouveau solde du client
            console.log(`Paiement simulé de ${totalCommande.toFixed(2)} FCFA par le client ${client.email}. Nouveau solde: ${client.informationsPaiementSimulees.soldeCompteSimule}`);
        }
        // --- FIN SIMULATION PAIEMENT CLIENT ---
        let savedOrder = null;
        // (Optionnel) Sauvegarder la simulation de commande si vous avez un modèle Order
        const newOrder = new Order({
            idClient,
            produits: produitsPourCommandeDetails,
            sousTotal,  
            codePromoUtilise: codePromo,
            idParrainReferant,
            reductionAppliquee,
            totalCommande,
            statut: 'simulation_payee'
        });
        await newOrder.save();
        savedOrder = newOrder; // Sauvegarder l'ID de la commande pour l'enregistrement dans le registre

             // --- APPLIQUER LES MISES À JOUR DE STOCK ---
             if (operationsStock.length > 0) {
                try {
                    const resultStock = await Product.bulkWrite(operationsStock);
                    // Vérifier si toutes les opérations de stock ont réussi
                    // resultStock.modifiedCount devrait être égal à operationsStock.length
                    // Si ce n'est pas le cas, cela signifie qu'un stock a changé entre la lecture et l'écriture (race condition)
                    // C'est une gestion plus avancée. Pour le prototype, on suppose que ça marche.
                    if (resultStock.modifiedCount !== operationsStock.length) {
                        // Gérer l'erreur: annuler le paiement simulé, restaurer les stocks (complexe)
                        // Pour le proto, on loggue une erreur et on continue, mais c'est un point critique en prod.
                        console.error("STOCK_UPDATE_ERROR: Incohérence lors de la mise à jour des stocks.", resultStock);
                        // Potentiellement, renvoyer une erreur au client et ne pas créer la commande/commission.
                        // return res.status(500).json({ success: false, message: "Erreur lors de la mise à jour des stocks, veuillez réessayer."});
                    }
                    console.log("Stocks mis à jour pour la commande.");
                } catch (stockError) {
                    console.error("ERREUR CRITIQUE lors de la mise à jour des stocks:", stockError);
                    // Ici, il faudrait annuler le paiement simulé et ne pas créer la commande.
                    return res.status(500).json({ success: false, message: "Erreur critique lors de la réservation des produits."});
                }
            }
            // --- FIN APPLICATION STOCKS ---

            await createNotification(
                idClient,
                'COMMANDE_RECUE_CLIENT',
                `Votre commande simulée #${savedOrder._id} d'un montant de ${savedOrder.totalCommande.toFixed(2)} FCFA a bien été enregistrée.`,
                'Confirmation de votre commande simulée',
                `/client/commandes/${savedOrder._id}` // Exemple de lien
            );

            // --- NOTIFICATION POUR LA BOUTIQUE ---
            if (savedOrder.idBoutiqueAssociee) {
                const boutiqueDeLaCommande = await User.findById(savedOrder.idBoutiqueAssociee).select('nomBoutique');
                const nomBoutiquePourNotif = boutiqueDeLaCommande ? boutiqueDeLaCommande.nomBoutique : "une boutique";
                await createNotification(
                    savedOrder.idBoutiqueAssociee,
                    'COMMANDE_RECUE_BOUTIQUE',
                    `Nouvelle commande simulée #${savedOrder._id} (Client: ${client.nomComplet || client.email}) d'un montant de ${savedOrder.totalCommande.toFixed(2)} FCFA concerne vos produits/services.`,
                    'Nouvelle Commande Simulée Reçue',
                    `/boutique/commandes/${savedOrder._id}` // Exemple de lien
                );
            }
            // --- FIN NOTIFICATION BOUTIQUE ---

            if (totalCommande >= 0) { // Ou une autre condition pour quand logguer une commande
                await logLedgerEvent(
                    'COMMANDE_SIMULEE_PAYEE',
                    {
                        orderId: savedOrder ? savedOrder._id : new mongoose.Types.ObjectId(), // Générer un ID si Order n'est pas sauvegardé
                        clientId: idClient,
                        produits: produitsPourCommandeDetails.map(p => ({ nom: p.nomProduit, qte: p.quantite, prix: p.prixUnitaire })),
                        sousTotal: sousTotal,
                        reduction: reductionAppliquee,
                        totalPaye: totalCommande,
                        codePromoUtilise: codePromo,
                        parrainIdSiApplicable: idParrainReferant
                    },
                    [idClient, idParrainReferant].filter(id => id) // Ajoute les IDs du client et du parrain s'il existe
                );
            }
            // --- FIN ENREGISTREMENT REGISTRE (COMMANDE) ---
           // --- GESTION COMMISSION PARRAIN ET ENREGISTREMENT REGISTRE (COMMISSION) ---
        if (idParrainReferant && totalCommande > 0) { // S'il y a un parrain et un paiement
            const montantBasePourCommission = sousTotal - reductionAppliquee; // Commission sur ce que le client a payé
            const montantCommissionCalcule = montantBasePourCommission * POURCENTAGE_COMMISSION_PARRAIN_REEL;
            const savedOrder = await Order.findOne({ _id: newOrder._id }).populate('idClient'); // Récupérer l'Order sauvegardé
            const parrainReferantDoc = await User.findOne({ codePromoPersonnel: codePromo.toUpperCase(), role: 'parrain' }).select('+informationsPaiementSimulees.soldeCompteSimule');
            produitsPourCommande.forEach((produit) => {
                produitsPourCommandeDetails.push({  
                    idProduit: produit.idProduit,
                    nomProduit: produit.nomProduit, 
                    quantite: produit.quantite,
                    prixUnitaire: produit.prixUnitaire
                });

            });
            // Vérifier si le parrain existe et a un solde simulé
            if (montantCommissionCalcule > 0) {
                const newCommission = new Commission({
                    idParrain: idParrainReferant,
                    idClientReffere: idClient,
                    idOrderAssocie: savedOrder ? savedOrder._id : null, // Lier à l'Order si sauvegardé
                    detailsCommandeSimulee: { // Toujours stocker les détails pour redondance/facilité
                        produits: produitsPourCommandeDetails,
                        sousTotal: sousTotal,
                        reductionAppliquee: reductionAppliquee,
                        totalPaye: totalCommande
                    },
                    montantBaseCommission: montantBasePourCommission,
                    pourcentageCommission: POURCENTAGE_COMMISSION_PARRAIN_REEL,
                    montantCommission: montantCommissionCalcule,
                    statut: 'validee' // Pour le prototype, on valide directement. En prod: 'en_attente_validation'
                });
                await newCommission.save();
                console.log(`Commission de ${montantCommissionCalcule.toFixed(2)} FCFA enregistrée pour le parrain ${idParrainReferant}`);

                 // --- ENREGISTREMENT DANS LE REGISTRE (COMMISSION) ---
                 await logLedgerEvent(
                    'COMMISSION_GENERE_E',
                    {
                        commissionId: newCommission._id,
                        orderIdAssociee: savedOrder ? savedOrder._id : null,
                        parrainId: idParrainReferant,
                        clientId: idClient,
                        montantCommission: montantCommissionCalcule,
                        pourcentage: POURCENTAGE_COMMISSION_PARRAIN_REEL
                    },
                    [idParrainReferant, idClient]
                );
                // --- FIN ENREGISTREMENT REGISTRE (COMMISSION) ---

                // Mais la source de vérité pour les gains du parrain sera la somme de ses commissions 'validee' ou 'payee'
                if(parrainReferantDoc){
                    if (!parrainReferantDoc.informationsPaiementSimulees) parrainReferantDoc.informationsPaiementSimulees = {};
                    if (parrainReferantDoc.informationsPaiementSimulees.soldeCompteSimule === undefined) parrainReferantDoc.informationsPaiementSimulees.soldeCompteSimule = 0;
                    parrainReferantDoc.informationsPaiementSimulees.soldeCompteSimule += montantCommissionCalcule;
                    await parrainReferantDoc.save();
                }
                // --- NOTIFICATION POUR LE PARRAIN (COMMISSION) ---
         await createNotification(
            idParrainReferant,
            'COMMISSION_GENEREE_PARRAIN',
            `Félicitations ! Vous avez gagné une commission de ${montantCommissionCalcule.toFixed(2)} FCFA suite à la commande #${savedOrder._id} de votre filleul ${client.nomComplet || client.email}.`,
            'Nouvelle Commission Gagnée !',
            `/parrain/commissions/${newCommission._id}` // Exemple de lien
        );
            }
             
        }
        
        // --- FIN GESTION COMMISSION PARRAIN ---

        // Réponse de la simulation
        res.status(200).json({
            success: true,
            message: 'Achat simulé avec succès! ' + (totalCommande > 0 ? 'Paiement effectué.' : ''),
            orderId: savedOrder ? savedOrder._id : null,
            details: {
                produits: produitsPourCommandeDetails,
                sousTotal: sousTotal.toFixed(2),
                codePromoApplique: codePromo || "Aucun",
                parrainReferantTrouve: !!idParrainReferant,
                reduction: reductionAppliquee.toFixed(2),
                totalAPayer: totalCommande.toFixed(2),
                orderId: newOrder ? newOrder._id : null // Si sauvegardé
            }
        });

    } catch (err) { 
        console.error("Erreur simulateOrder:", err);
        res.status(500).json({ success: false, message: 'Erreur serveur lors de la simulation.', error: err.message });
    }
};

// Récupérer les commandes du client connecté
exports.getMyOrdersAsClient = async (req, res) => {
    try {
        const clientId = req.user.userId;
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        const orders = await Order.find({ idClient: clientId })
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit)
            .populate('idBoutiqueAssociee', 'nomBoutique') // Afficher le nom de la boutique
            .populate('produits.idProduit', 'nom imageUrl'); // Afficher nom/image des produits

        const totalOrders = await Order.countDocuments({ idClient: clientId });

        res.status(200).json({
            success: true,
            currentPage: page,
            totalPages: Math.ceil(totalOrders / limit),
            totalOrders,
            orders
        });
    } catch (error) {
        console.error("Erreur getMyOrdersAsClient:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};

// Récupérer les commandes pour la boutique connectée
exports.getMyOrdersAsBoutique = async (req, res) => {
    try {
        const boutiqueId = req.user.userId; // L'ID de la boutique connectée
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        const orders = await Order.find({ idBoutiqueAssociee: boutiqueId })
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit)
            .populate('idClient', 'nomComplet email') // Afficher infos du client
            .populate('produits.idProduit', 'nom');

        const totalOrders = await Order.countDocuments({ idBoutiqueAssociee: boutiqueId });

        res.status(200).json({
            success: true,
            currentPage: page,
            totalPages: Math.ceil(totalOrders / limit),
            totalOrders,
            orders
        });
    } catch (error) {
        console.error("Erreur getMyOrdersAsBoutique:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};

// Mettre à jour le statut d'une commande (par la boutique)
exports.updateOrderStatusByBoutique = async (req, res) => {
    try {
        const boutiqueId = req.user.userId;
        const { orderId } = req.params;
        const { nouveauStatut } = req.body;
        let produitsPourCommande = [];


        if (!nouveauStatut || !['en_preparation', 'prete_pour_retrait', 'expediee', 'livree', 'retiree', 'annulee'].includes(nouveauStatut)) {
            return res.status(400).json({ success: false, message: 'Statut de commande invalide fourni.' });
        }
        if (!mongoose.Types.ObjectId.isValid(orderId)) {
            return res.status(400).json({ success: false, message: 'ID de commande invalide.' });
        }

        const order = await Order.findById(orderId);
        if (!order) {
            return res.status(404).json({ success: false, message: 'Commande non trouvée.' });
        }
            // Vérifiez que la commande a bien une boutique associée
            if (!order.idBoutiqueAssociee) {
                return res.status(400).json({ 
                    success: false, 
                    message: "Commande non associée à une boutique" 
                });
            }
    
            // Vérifiez la correspondance boutique
            if (order.idBoutiqueAssociee.toString() !== boutiqueId) {
                return res.status(403).json({ 
                    success: false, 
                    message: 'Action non autorisée' 
                });
            }

        // Vérifier que la boutique connectée est bien celle associée à la commande
        if (order.idBoutiqueAssociee.toString() !== boutiqueId) {
            return res.status(403).json({ success: false, message: 'Action non autorisée sur cette commande.' });
        }
        // Ajoutez cette logique après la validation des produits
        const boutiqueIds = [...new Set(produitsPourCommande.map(p => p.idProduit.boutique))];
        if (boutiqueIds.length > 2) {
            return res.status(400).json({ 
                success: false, 
                message: "Commande multi-boutique non supportée" 
            });
        }
        order.statutCommande = nouveauStatut;
        // Potentiellement ajouter une note ou un historique des changements de statut
        await order.save();

        // Logguer l'événement de changement de statut
        await logLedgerEvent('COMMANDE_STATUT_MAJ', {
                orderId: order._id,
                nouveauStatut: nouveauStatut,
                parBoutiqueId: boutiqueId
            },
            [order.idClient, boutiqueId].filter(id => id)
        );
           await createNotification(
                order.idClient,
                'COMMANDE_STATUT_MAJ_CLIENT',
                `Le statut de votre commande #${order._id} a été mis à jour à "${nouveauStatut}".`,
                'Mise à jour de votre commande',
                `/client/commandes/${order._id}` // Exemple de lien 
            );


        res.status(200).json({ success: true, message: 'Statut de la commande mis à jour.', order });

    } catch (error) {
        console.error("Erreur updateOrderStatusByBoutique:", error);
        res.status(500).json({ success: false, message: 'Erreur serveur.', error: error.message });
    }
};

