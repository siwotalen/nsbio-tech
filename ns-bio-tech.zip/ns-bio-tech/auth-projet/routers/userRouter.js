// routes/userRouter.js
const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { identifier } = require('../middlewares/identification'); // Votre middleware d'authentification
const { checkRole } = require('../middlewares/authorization'); // Assurez-vous que ce middleware existe

// Récupérer le profil de l'utilisateur actuellement connecté
router.get(
    '/me', // La route sera /api/users/me
    identifier, // L'utilisateur doit être connecté
    userController.getMyProfile
);

// Mettre à jour le profil de l'utilisateur actuellement connecté
router.put( // ou PATCH pour une mise à jour partielle, PUT est souvent utilisé pour remplacer la ressource ou la créer
    '/me',
    identifier,
    userController.updateMyProfile
);

// Route pour qu'une boutique mette à niveau son abonnement (simulation)
router.patch(
    '/me/subscription', // Ou /boutiques/me/subscription
    identifier,
    checkRole(['boutique']), // Seules les boutiques peuvent modifier leur abonnement
    userController.updateMySubscription // Nouvelle fonction à créer dans userController
);

router.get(
    '/me/commissions',
    identifier,
    checkRole(['parrain']), // Seuls les parrains peuvent voir leurs commissions
    userController.getMyCommissions
);

router.get(
    '/me/referred-users',
    identifier,
    checkRole(['parrain']),
    userController.getMyReferredUsers
);

router.post(
    '/me/commissions/request-payout',
    identifier,
    checkRole(['parrain']),
    userController.requestCommissionPayout
);

router.get(
    '/me/notifications',
    identifier,
    userController.getMyNotifications // ou notificationController.getMyNotifications
);

// Marquer une notification comme lue
router.patch(
    '/me/notifications/:notificationId/read',
    identifier,
    userController.markNotificationAsRead // ou notificationController.markNotificationAsRead
);

// Marquer toutes mes notifications comme lues
router.patch(
    '/me/notifications/read-all',
    identifier,
    userController.markAllMyNotificationsAsRead // ou notificationController.markAllMyNotificationsAsRead
);
router.get(
    '/me/notifications/:notificationId', // :notificationId sera req.params.notificationId
    identifier,
    userController.getSingleNotification // ou notificationController.getSingleNotification
);



// --- Routes pour administrateurs (à ajouter plus tard si besoin) ---
// const { checkRole } = require('../middlewares/authorization');
// router.get('/', identifier, checkRole(['admin']), userController.getAllUsers);
// router.get('/:id', identifier, checkRole(['admin']), userController.getUserById);
// router.put('/:id', identifier, checkRole(['admin']), userController.updateUserById);
// router.delete('/:id', identifier, checkRole(['admin']), userController.deleteUserById);


module.exports = router;