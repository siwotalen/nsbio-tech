// routes/orderRouter.js
const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');
const { identifier } = require('../middlewares/identification');
const { checkRole } = require('../middlewares/authorization'); // Au cas où on aurait des routes spécifiques aux rôles

// Simuler une commande (pour les clients)
router.post(
    '/simulate',
    identifier, // L'utilisateur doit être connecté
    checkRole(['client']), // Seuls les clients peuvent simuler une commande pour eux-mêmes
    orderController.simulateOrder
);


// Récupérer les commandes du client connecté
router.get(
    '/my-orders/client',
    identifier,
    checkRole(['client']),
    orderController.getMyOrdersAsClient
);

// Récupérer les commandes pour la boutique connectée
router.get(
    '/my-orders/boutique',
    identifier,
    checkRole(['boutique']),
    orderController.getMyOrdersAsBoutique
);

// Mettre à jour le statut d'une commande (par la boutique)
router.patch(
    '/:orderId/status', // Ex: /api/orders/ID_COMMANDE/status
    identifier,
    checkRole(['boutique']),
    orderController.updateOrderStatusByBoutique
);

module.exports = router;