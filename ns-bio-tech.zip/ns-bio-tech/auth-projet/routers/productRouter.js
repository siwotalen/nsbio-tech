// routes/productRouter.js
const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');
const { identifier } = require('../middlewares/identification');
const { checkRole } = require('../middlewares/authorization'); // Assurez-vous que ce middleware existe

// --- Routes de Modération (protégées pour le rôle 'admin') ---
// Pour le prototype, si vous n'avez pas de système de rôle admin complexe,
// vous pouvez temporairement retirer checkRole(['admin']) pour tester avec Postman,
// ou créer manuellement un utilisateur admin dans votre base et vous connecter avec lui.

// Récupérer les produits en attente
router.get(
    '/admin/pending', // Préfixe admin pour clarté
    identifier,
    checkRole(['admin']), // <<--- IMPORTANT: Seuls les admins
    productController.getPendingProducts
);

// Approuver un produit
router.patch( // PATCH car on modifie une partie de la ressource
    '/admin/:productId/approve',
    identifier,
    checkRole(['admin']), // <<--- IMPORTANT
    productController.approveProduct
);

// Rejeter un produit
router.patch(
    '/admin/:productId/reject',
    identifier,
    checkRole(['admin']), // <<--- IMPORTANT
    productController.rejectProduct
);
// http://localhost:8000/api/products/admin/681a472f10ebf14a9a2dfa9c/approve

// Créer un produit (seulement pour les boutiques)
router.post('/', identifier, checkRole(['boutique']), productController.createProduct);

// Obtenir les produits de la boutique connectée
router.get('/my-products', identifier, checkRole(['boutique']), productController.getProductsByVendor);

// Obtenir tous les produits (visibles par les clients - filtrés par statut 'approuve' dans le contrôleur)
router.get('/', productController.getAllProducts); // Peut être public ou nécessiter 'identifier'

// Obtenir un seul produit par son ID
router.get('/single/:productId', productController.getSingleProduct); // Peut être public ou nécessiter 'identifier'

// Mettre à jour un produit (seulement pour la boutique propriétaire)
router.put('/:productId', identifier, checkRole(['boutique']), productController.updateProduct);

// Supprimer un produit (seulement pour la boutique propriétaire)
router.delete('/:productId', identifier, checkRole(['boutique']), productController.deleteProduct);

module.exports = router;