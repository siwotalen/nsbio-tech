// routes/chatbotRouter.js
const express = require('express');
const router = express.Router();
const chatbotController = require('../controllers/chatbotController');
const { identifier } = require('../middlewares/identification'); // Optionnel ici

// Route pour envoyer un message au chatbot
// On pourrait utiliser 'identifier' si on veut que le chatbot connaisse l'utilisateur connecté
// pour des réponses personnalisées, mais pour ce proto simple, ce n'est pas nécessaire.
router.post('/query', chatbotController.handleChatMessage);

module.exports = router;