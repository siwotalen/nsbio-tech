// routes/boutiqueRouter.js
const express = require('express');
const router = express.Router();
const boutiqueController = require('../controllers/boutiqueController');
const { identifier } = require('../middlewares/identification');
const { checkRole } = require('../middlewares/authorization');

// Toutes les routes ici sont pour la boutique connectée, donc on met les middlewares en commun
router.use(identifier, checkRole(['boutique']));

// Récupérer tous les points de retrait de la boutique
router.get('/me/points-retrait', boutiqueController.getMesPointsDeRetrait);

// Ajouter un nouveau point de retrait
router.post('/me/points-retrait', boutiqueController.addPointDeRetrait);

// Mettre à jour un point de retrait spécifique
router.put('/me/points-retrait/:pointId', boutiqueController.updatePointDeRetrait);

// Supprimer un point de retrait spécifique
router.delete('/me/points-retrait/:pointId', boutiqueController.deletePointDeRetrait);

module.exports = router;