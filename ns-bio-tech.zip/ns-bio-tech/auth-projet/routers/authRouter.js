// routers/authRouter.js
const express = require('express');
const authController = require('../controllers/authController');
const { identifier } = require('../middlewares/identification');
const router = express.Router();

router.post('/signup', authController.signup);
router.post('/signin', authController.signin);
router.post('/admin/signin', authController.adminSignin);
router.post('/signout', identifier, authController.signout); // OK

// Si SendVerificationCode peut être appelé par un utilisateur non connecté (ex: après signup)
router.patch('/send-verification-code', identifier,authController.SendVerificationCode); // Retirer 'identifier', email via body
// Si verifyVerificationCode peut aussi être appelé sans token (ex: lien dans email)
router.patch('/verify-verification-code', identifier, authController.verifyVerificationCode); // Retirer 'identifier', email via body

// Si ces routes sont pour un utilisateur déjà connecté (ex: dans son profil)
// router.patch('/send-verification-code',identifier,authController.SendVerificationCode);
// router.patch('/verify-verification-code',identifier,authController.verifyVerificationCode);


router.patch('/change-password', identifier, authController.changePassword);// OK
router.post('/send-forgot-password-code', authController.SendForgotPasswordCode); // Pas d'identifier ici, email via body (CORRIGÉ de PATCH à POST car on crée une ressource "demande")
router.patch('/verify-forgot-password-code', authController.verifyForgotPasswordCode); // email via body, OK

module.exports = router;