// routes/adminRouter.js
const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController'); // Ou le nom de votre contrôleur admin
const productController = require('../controllers/productController'); // Pour les routes de modération produit
const ledgerController = require('../controllers/ledgerController'); // Pour les routes du registre

const { identifier } = require('../middlewares/identification');
const { checkRole } = require('../middlewares/authorization');

// Appliquer les middlewares d'admin à toutes les routes de ce fichier
router.use(identifier, checkRole(['admin']));

// --- Routes de Modération Produit (déplacées ou dupliquées ici pour centralisation admin) ---
router.get('/products/pending', productController.getPendingProducts);
router.patch('/products/:productId/approve', productController.approveProduct);
router.patch('/products/:productId/reject', productController.rejectProduct);

// --- Routes de Gestion des Paiements de Commissions ---
router.get('/commissions/payout-requests', adminController.getPendingPayoutRequests);
router.patch('/commissions/payout-requests/:commissionId/approve', adminController.approveCommissionPayout);

// --- Routes de Consultation du Registre ---
router.get('/ledger', ledgerController.getLedgerEntries);
router.get('/ledger/:hash', ledgerController.getLedgerEntryByHash);

// --- NOUVELLES ROUTES POUR LA GESTION DES COMMANDES PAR L'ADMIN ---
router.get('/orders', adminController.getAllPlatformOrders);
router.get('/orders/:orderId', adminController.getSinglePlatformOrder);


// Ajoutez d'autres routes admin ici (gestion utilisateurs, etc.)

module.exports = router;