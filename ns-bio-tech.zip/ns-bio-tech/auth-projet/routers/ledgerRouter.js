// routes/ledgerRouter.js
const express = require('express');
const router = express.Router();
const ledgerController = require('../controllers/ledgerController');
const { identifier } = require('../middlewares/identification');
const { checkRole } = require('../middlewares/authorization');

// Routes pour consulter le registre (protégées pour admin)
router.get(
    '/',
    identifier,
    checkRole(['admin']),
    ledgerController.getLedgerEntries
);

router.get(
    '/:hash',
    identifier,
    checkRole(['admin']),
    ledgerController.getLedgerEntryByHash
);

module.exports = router;