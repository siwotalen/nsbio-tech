// models/usersModel.js
const mongoose = require('mongoose');
const { nanoid } = require('nanoid'); // Pour générer des codes promos uniques

// Schéma pour un point de retrait individuel
const pointRetraitSchema = new mongoose.Schema({
  nom: { type: String, required: [true, 'Le nom du point de retrait est requis.'], trim: true },
  adresse: { type: String, required: [true, 'L\'adresse est requise.'], trim: true },
  ville: { type: String, trim: true },
  instructionsSupplementaires: { type: String, trim: true, default: '' },
  horairesOuverture: { type: String, trim: true, default: '' }, // Ex: "Lundi-Vendredi: 9h-17h"
  // Plus tard, on pourrait ajouter des coordonnées GPS:
  // localisation: {
  //    type: { type: String, enum: ['Point'], default: 'Point' },
  //    coordinates: { type: [Number], default: [0,0] } // [longitude, latitude]
  // }
}, { _id: true }); // _id: true est par défaut, mais on le met pour clarté que chaque point aura son ID

const userSchema = mongoose.Schema({
  email: {
    type: String,
    required: [true, 'L\'email est requis'],
    unique: true,
    lowercase: true,
    trim: true,
    minlength: [6, 'L\'email doit contenir au moins 6 caractères'],
  },
  password: {
    type: String,
    required: [true, 'Le mot de passe est requis'],
    trim: true,
    select: false, // Ne pas retourner le mot de passe par défaut
  },
  role: {
    type: String,
    enum: ['client', 'parrain', 'boutique','admin'],
    required: [true, 'Le rôle est requis'],
  },
  // permissionsAdmin: [{ type: String }], // Pour une gestion fine des droits admin
  informationsPaiementSimulees: {
    typePaiementPrincipal: { // Ex: 'MobileMoney', 'CarteBancaire', 'PayPal'
        type: String,
        enum: ['non_configure', 'mobile_money', 'carte_bancaire', 'paypal_simule'],
        default: 'non_configure'
    },
    detailsMobileMoney: { // Si typePaiementPrincipal est 'mobile_money'
        numero: String, // Ex: "+2250707070707"
        operateur: String // Ex: "Orange Money", "MTN Money", "Moov Money"
    },
    detailsCarteBancaire: { // Si typePaiementPrincipal est 'carte_bancaire'
        typeCarte: String, // Ex: "Visa", "Mastercard"
        quatreDerniersChiffres: String, // Ex: "1234"
        dateExpiration: String // Ex: "12/25" (MM/YY)
    },
      detailsVirementBancaire: { // Pour les parrains
      iban: String,
      nomBanque: String,
      nomTitulaireCompte: String // Optionnel
    },
    soldeCompteSimule: { // Pour simuler des transactions, surtout pour les tests de commission parrain
        type: Number,
        default: 100000 // Un solde initial fictif en FCFA par exemple
    }
  },
  verified: {
    type: Boolean,
    default: false,
  },
  verificationCode: {
    type: String,
    select: false,
  },
  verificationCodeValidation: {
    type: Date,
    select: false,
  },
  forgotPasswordCode: {
    type: String,
    select: false,
  },
  forgotPasswordCodeValidation: {
    type: Number,
    select: false,
  },

  // --- Champs communs ou pour Client/Parrain ---
  nomComplet: {
    type: String,
    trim: true,
  },
  telephone: {
    type: String,
    trim: true,
  },

  // --- Champs spécifiques au Client ---
  adresseLivraison: { // Optionnel pour le client
    rue: String,
    ville: String,
    codePostal: String,
    pays: String,
  },
  codeParrainSaisi: { // Code promo que le client a utilisé à l'inscription
    type: String,
    trim: true,
  },

  // --- Champs spécifiques à la Boutique ---
  nomBoutique: {
    type: String,
    trim: true,
  },
  descriptionBoutique: {
    type: String,
    trim: true,
  },
  logoUrlBoutique: {
    type: String,
    trim: true,
  },
  coordonneesBoutique: {
    adressePrincipale: String,
    ville: String,
    pays: String,
    telephoneBoutique: String,
    // geolocalisation: { lat: Number, lon: Number } // Pour plus tard
  },
  horairesOuvertureBoutique: { // ex: "Lundi-Vendredi: 9h-18h"
    type: String,
  },
  typeAbonnement: { // <<--- CHAMP IMPORTANT
    type: String,
    enum: ['classic', 'gold', 'platinum'],
    default: 'classic', // Abonnement par défaut à l'inscription d'une boutique
    // S'applique uniquement si role === 'boutique'
  },
  limiteProduits: { // <<--- CHAMP IMPORTANT
    type: Number,
    default: '3',
    // S'applique uniquement si role === 'boutique'
    // La valeur sera définie en fonction de typeAbonnement
  },
    pointsDeRetrait: [pointRetraitSchema], // <<--- CHAMP IMPORTANT POUR LES POINTS DE RETRAIT


  // --- Champs spécifiques au Parrain ---
  codePromoPersonnel: { // Le code unique du parrain
    type: String,
    unique: true,
    sparse: true, // Permet plusieurs documents sans ce champ, mais s'il est présent, il doit être unique
    // default: () => nanoid(8).toUpperCase() // Optionnel: générer un code par défaut si non fourni
  },
  idDuParrain: { // L'ID de l'utilisateur Parrain qui a référé ce Client
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null,
  },
  // infosPaiementCommissions: { // Pour plus tard
  //   typePaiement: String, // ex: 'MobileMoney', 'BankTransfer'
  //   details: String,      // ex: 'Numero Tel', 'IBAN'
  // }
  

}, {
  timestamps: true,
});

// Hook pre-save pour définir limiteProduits en fonction de typeAbonnement et 
// Générer un code promo personnel pour le parrain avant la sauvegarde s'il n'est pas fourni
userSchema.pre('save', async function(next) {
  // Définir la limite de produits pour les boutiques
  if (this.role === 'boutique' && (this.isModified('typeAbonnement') || this.isNew)) {
    switch (this.typeAbonnement) {
      case 'classic':
        this.limiteProduits = 3; // Ou la valeur de votre cahier des charges
        break;
      case 'gold':
        this.limiteProduits = 100;
        break;
      case 'platinum':
        this.limiteProduits = 500;
        break;
      default:
        this.limiteProduits = 3; // Fallback
    }
  }

  // Générer un code promo personnel pour le parrain s'il n'est pas déjà défini
  if (this.role === 'parrain' && this.isNew && !this.codePromoPersonnel) {
    let code;
    let existingUser;
    do {
      code = nanoid(8).toUpperCase(); // Génère un code de 8 caractères
      existingUser = await mongoose.model('User').findOne({ codePromoPersonnel: code });
    } while (existingUser); // S'assurer de l'unicité
    this.codePromoPersonnel = code;
  }
  next();
});


module.exports = mongoose.model('User', userSchema);