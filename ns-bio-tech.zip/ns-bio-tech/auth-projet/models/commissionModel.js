// models/commissionModel.js
const mongoose = require('mongoose');

const commissionSchema = new mongoose.Schema({
    idParrain: { // L'utilisateur qui reçoit la commission
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
        index: true // Utile pour rechercher les commissions d'un parrain
    },
    idClientReffere: { // Le client dont l'achat a généré la commission
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    idOrderAssocie: { // La commande simulée qui a déclenché cette commission
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Order', // Si vous avez un modèle Order pour les simulations
        // Si vous ne sauvegardez pas les simulations d'Order, ce champ peut être optionnel ou stocker des détails de la commande
        required: false // Mettre à true si vous liez toujours à un Order sauvegardé
    },
    detailsCommandeSimulee: { // Si idOrderAssocie n'est pas utilisé, stocker les infos ici
        produits: [{ nomProduit: String, quantite: Number, prixUnitaire: Number }],
        sousTotal: Number,
        reductionAppliquee: Number,
        totalPaye: Number,
    },
    montantBaseCommission: { // Le montant sur lequel la commission est calculée (ex: total payé par le client)
        type: Number,
        required: true
    },
    pourcentageCommission: { // Le taux de commission appliqué (ex: 0.10 pour 10%)
        type: Number,
        required: true
    },
    montantCommission: { // Le montant effectif de la commission gagnée
        type: Number,
        required: true
    },
    statut: { // Statut de la commission
        type: String,
        enum: ['en_attente_validation', 'validee', 'demandee_en_paiement', 'payee', 'annulee'],
        default: 'en_attente_validation' // Les commissions peuvent nécessiter une validation avant paiement
    },
    dateValidation: { type: Date },
    dateDemandePaiement: { type: Date },
    datePaiement: { type: Date },
    motifAnnulation: { type: String },
     // Optionnel: Un ID pour lier plusieurs commissions à une seule demande de paiement groupée
    // demandePaiementGroupId: { type: mongoose.Schema.Types.ObjectId, ref: 'PayoutRequest' } // Si vous créez un modèle PayoutRequest
}, {
    timestamps: true, // Ajoute createdAt et updatedAt
});

module.exports = mongoose.model('Commission', commissionSchema);