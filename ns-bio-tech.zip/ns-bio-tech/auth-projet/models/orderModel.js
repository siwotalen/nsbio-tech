// models/orderModel.js
const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    idClient: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    // Pour simplifier, supposons qu'une commande concerne des produits d'UNE SEULE boutique.
    // Si une commande peut avoir des produits de plusieurs boutiques, la structure devient plus complexe (sous-commandes par boutique).
    // Pour ce prototype, on va lier la commande à la boutique du premier produit, ou si vous avez une logique pour idVendeur au niveau de la commande.
    idBoutiqueAssociee: { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true }, // L'ID de la boutique concernée par cette commande

    produits: [{
        idProduit: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
        nomProduit: String,
        quantite: { type: Number, required: true, min: 1 },
        prixUnitaire: { type: Number, required: true },
        typeElement: { type: String, enum: ['produit', 'service'], required: true }, // Important pour savoir ce que c'était
        dureeServiceMinutes: { type: Number }, // Optionnel, rempli si service
        lieuService: { type: String }         // Optionnel, rempli si service
    }],
    sousTotal: { type: Number, required: true },
    codePromoUtilise: { type: String, trim: true },
    idParrainReferant: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    reductionAppliquee: { type: Number, default: 0 },
    totalCommande: { type: Number, required: true },
    statutCommande: { // Statut de la commande pour le suivi
        type: String,
        enum: [
            'simulation_payee', // Pour le prototype, après paiement simulé
            'en_preparation',   // La boutique prépare
            'prete_pour_retrait',// Prête au point de retrait
            'expediee',         // Si livraison
            'livree',
            'retiree',          // Client a récupéré
            'annulee'
        ],
        default: 'simulation_payee'
    },
    pointDeRetraitChoisi: { // Si le client a choisi un point de retrait
        idPoint: { type: mongoose.Schema.Types.ObjectId }, // Pas de ref direct ici car c'est un sous-doc de User
        nom: String,
        adresse: String
    },
    adresseLivraisonChoisie: { // Si livraison directe
        rue: String,
        ville: String,
        codePostal: String,
        pays: String,
    },
    // ... autres champs: date de livraison estimée, notes, etc.
}, { timestamps: true });

// Middleware pour déterminer idBoutiqueAssociee à partir du premier produit
orderSchema.pre('save', async function(next) {
    if (this.isNew && !this.idBoutiqueAssociee && this.produits && this.produits.length > 0) {
        try {
            const premierProduitId = this.produits[0].idProduit;
            const produitDoc = await mongoose.model('Product').findById(premierProduitId).select('idVendeur');
            if (produitDoc && produitDoc.idVendeur) {
                this.idBoutiqueAssociee = produitDoc.idVendeur;
            }
        } catch (error) {
            console.error("Erreur lors de la récupération de l'idBoutique pour la commande:", error);
            // Ne pas bloquer la sauvegarde, mais logguer
        }
    }
    next();
});


module.exports = mongoose.model('Order', orderSchema);