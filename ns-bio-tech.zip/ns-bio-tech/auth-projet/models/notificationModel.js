// models/notificationModel.js
const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema({
    idUtilisateurDestinataire: { // L'utilisateur qui doit recevoir la notification
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
        index: true
    },
    typeNotification: { // Catégorie de la notification pour filtrage ou icônes spécifiques
        type: String,
        enum: [
            'BIENVENUE',
            'COMMANDE_RECUE_CLIENT',
            'COMMANDE_RECUE_BOUTIQUE',
            'COMMISSION_GENEREE_PARRAIN',
            'PRODUIT_SOUMIS_BOUTIQUE',
            'PRODUIT_VALIDATION_ADMIN', // Admin informé qu'un produit est en attente
            'PRODUIT_APPROUVE_BOUTIQUE',
            'PRODUIT_REJETE_BOUTIQUE',
            'COMMANDE_STATUT_MAJ_CLIENT',
            'ABONNEMENT_MAJ_BOUTIQUE',
            'DEMANDE_PAIEMENT_COMMISSION_PARRAIN',
            'DEMANDE_PAIEMENT_COMMISSION_ADMIN', // Admin informé d'une demande
            'PAIEMENT_COMMISSION_EFFECTUE_PARRAIN',
            'GENERIQUE_INFO', // Pour des messages d'information généraux
            'GENERIQUE_ALERTE'
        ],
        required: true
    },
    titre: { // Titre court de la notification (optionnel, pourrait être généré)
        type: String,
        trim: true
    },
    message: { // Le contenu principal de la notification
        type: String,
        required: true,
        trim: true
    },
    estLue: {
        type: Boolean,
        default: false,
        index: true
    },
    dateLecture: {
        type: Date
    },
    lienInterne: { // Optionnel: un lien vers une page spécifique de l'application
        type: String, // Ex: '/commandes/ID_COMMANDE', '/produits/ID_PRODUIT'
        trim: true
    },
    metadata: { // Données supplémentaires liées à la notification
        type: mongoose.Schema.Types.Mixed // Ex: { orderId: '...', productId: '...' }
    }
}, {
    timestamps: true // createdAt (quand la notif a été créée), updatedAt
});

module.exports = mongoose.model('Notification', notificationSchema);