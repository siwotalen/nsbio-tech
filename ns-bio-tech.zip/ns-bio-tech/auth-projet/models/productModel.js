// models/productModel.js
const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    nom: {
        type: String,
        required: [true, 'Le nom du produit est requis.'],
        trim: true,
    },
    description: {
        type: String,
        trim: true,
        default: '',
    },
    prix: {
        type: Number,
        required: [true, 'Le prix du produit est requis.'],
        min: [0, 'Le prix ne peut pas être négatif.'],
    },
    idVendeur: { // L'ID de l'utilisateur (boutique) qui a créé ce produit
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User', // Référence au modèle User
        required: true,
    },
    imageUrl: { // Pour le prototype, une simple URL. Plus tard, gestion d'upload.
        type: String,
        trim: true,
        default: 'https://via.placeholder.com/150?text=Produit' // Placeholder
    },
    categorie: {
        type: String,
        trim: true,
        default: 'Non catégorisé'
    },
    statutValidation: {
        type: String,
        enum: ['en_attente', 'approuve', 'rejete'],
        default: 'en_attente' // Nouveau produit est en attente par défaut
    },
    motifRejet: { // Si le produit est rejeté
        type: String,
        default: ''
    },
    disponible: {
        type: Boolean,
        default: true,
    }
    , typeElement: {
        type: String,
        enum: ['produit', 'service'],
        required: [true, 'Le type d\'élément (produit ou service) est requis.'],
        default: 'produit'
    },
    quantiteEnStock: { // Pertinent pour typeElement: 'produit'
        type: Number,
        default: 0, // Ou null si on ne veut pas de valeur par défaut
        min: [0, 'La quantité en stock ne peut pas être négative.'],
        validate: { // N'est requis que si c'est un produit
            validator: function(value) {
                return this.typeElement === 'service' || (this.typeElement === 'produit' && typeof value === 'number');
            },
            message: 'La quantité en stock est requise pour un produit.'
        }
    },
    dureeServiceMinutes: { // Pertinent pour typeElement: 'service' (ex: consultation de 60 minutes)
        type: Number,
        min: [0, 'La durée du service ne peut être négative.']
    },
    lieuService: { // Pertinent pour typeElement: 'service' (ex: 'En ligne', 'À domicile', 'En cabinet')
        type: String,
        trim: true
    }
}, {
    timestamps: true, // Ajoute createdAt et updatedAt automatiquement
});
productSchema.index({ nom: 'text', description: 'text', categorie: 'text' });

module.exports = mongoose.model('Product', productSchema);