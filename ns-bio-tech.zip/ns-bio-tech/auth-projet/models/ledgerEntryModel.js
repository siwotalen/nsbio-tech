// models/ledgerEntryModel.js
const mongoose = require('mongoose');
const crypto = require('crypto'); // Pour le hachage

const ledgerEntrySchema = new mongoose.Schema({
    eventType: { // Ex: 'COMMANDE_SIMULEE', 'COMMISSION_GENERE_E', 'ABONNEMENT_PAYE'
        type: String,
        required: true,
        index: true
    },
    eventTimestamp: { // Horodatage précis de l'événement
        type: Date,
        default: Date.now,
        index: true
    },
    eventData: { // Données spécifiques à l'événement (ex: orderId, commissionId, userId, montant)
        type: mongoose.Schema.Types.Mixed, // Permet de stocker des objets flexibles
        required: true
    },
    relatedUserIds: [{ // Utilisateurs impliqués dans cet événement (client, vendeur, parrain)
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }],
    previousEntryHash: { // Hash de l'entrée précédente dans le registre (pour simuler le chaînage)
        type: String,
        default: '0' // Pour la première entrée (bloc genesis simulé)
    },
    entryHash: { // Hash de cette entrée (pour simuler l'intégrité)
        type: String,
        unique: true, // Chaque hash doit être unique
        required: true
    },
    // Champs optionnels pour une future intégration blockchain réelle
    // transactionIdBlockchain: { type: String },
    // blockNumberBlockchain: { type: Number },
}, {
    timestamps: true // createdAt/updatedAt pour le document MongoDB lui-même
});

// Méthode pour calculer le hash de l'entrée
ledgerEntrySchema.methods.calculateHash = function() {
    const dataToHash = JSON.stringify(this.eventType) +
                       JSON.stringify(this.eventTimestamp) +
                       JSON.stringify(this.eventData) +
                       JSON.stringify(this.relatedUserIds || []) + // S'assurer que c'est un tableau
                       this.previousEntryHash;
    return crypto.createHash('sha256').update(dataToHash).digest('hex');
};

// Hook pre-save pour s'assurer que le hash est calculé et unique (simulation de minage/validation)
// Et pour récupérer le hash de l'entrée précédente pour le chaînage
ledgerEntrySchema.pre('validate', async function(next) { // 'validate' au lieu de 'save' pour que le hash soit là avant la validation Mongoose
    if (this.isNew) {
        try {
            // 1. Récupérer le hash de la dernière entrée pour le chaînage
            // Pour une vraie blockchain, ce serait plus complexe (consensus, etc.)
            // Ici, on prend simplement la dernière entrée créée dans la DB.
            // ATTENTION: Ceci n'est PAS thread-safe pour des écritures concurrentes massives.
            // Pour un prototype, c'est acceptable.
            const lastEntry = await mongoose.model('LedgerEntry').findOne().sort({ createdAt: -1 });
            if (lastEntry) {
                this.previousEntryHash = lastEntry.entryHash;
            } else {
                this.previousEntryHash = '0'; // Genesis block
            }

            // 2. Calculer le hash de cette entrée
            this.entryHash = this.calculateHash();

            // Simulation d'unicité (un peu comme un nonce pour PoW, mais très simplifié)
            // Dans une vraie blockchain, le processus de s'assurer qu'un hash est valide et unique est le minage.
            // Ici, on va juste ajouter un petit nonce si le hash existe déjà, ce qui est une simplification extrême.
            let existingEntry = await mongoose.model('LedgerEntry').findOne({ entryHash: this.entryHash });
            let nonce = 0;
            while(existingEntry && nonce < 100) { // Limiter les tentatives pour éviter boucle infinie
                nonce++;
                const dataToHashWithNonce = JSON.stringify(this.eventType) +
                                            JSON.stringify(this.eventTimestamp) +
                                            JSON.stringify(this.eventData) +
                                            JSON.stringify(this.relatedUserIds || []) +
                                            this.previousEntryHash +
                                            nonce.toString(); // Ajouter le nonce
                this.entryHash = crypto.createHash('sha256').update(dataToHashWithNonce).digest('hex');
                existingEntry = await mongoose.model('LedgerEntry').findOne({ entryHash: this.entryHash });
            }
            if (nonce >= 100) {
                // Très improbable avec SHA256 et des données variées, mais au cas où
                return next(new Error("Impossible de générer un hash d'entrée de registre unique après plusieurs tentatives."));
            }

        } catch (err) {
            return next(err);
        }
    }
    next();
});


module.exports = mongoose.model('LedgerEntry', ledgerEntrySchema);