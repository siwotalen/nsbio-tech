const express= require('express');
const helmet =require("helmet");
const cors =require("cors");
const cookieParser =require("cookie-parser");
const mongoose = require('mongoose');

const path = require('path');
const authRouter=require('./routers/authRouter');
const postsRouter=require('./routers/postsRouter');
const productRouter=require('./routers/productRouter');
const orderRouter = require('./routers/orderRouter');
const userRouter = require('./routers/userRouter'); 
const boutiqueRouter = require('./routers/boutiqueRouter');
const chatbotRouter = require('./routers/chatbotRouter');
const ledgerRouter = require('./routers/ledgerRouter');
const adminRouter = require('./routers/adminRouter');

const app = express();
app.use(cors());
app.use(helmet());
app.use(express.json());
app.use(cookieParser());
app.use(express.urlencoded({extended:true}));

mongoose
   .connect(process.env.MONGO_URI)
   .then(() => {
      console.log('MongoDB connected successfully!');
   })
   .catch((err) => {
      console.error('MongoDB connection error:', err);
   });

app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/api/auth', authRouter);
app.use('/api/posts', postsRouter); // Si vous le gardez
app.use('/api/products', productRouter); // <--- AJOUTER CECI
app.use('/api/orders', orderRouter); // ou /api/commandes
app.use('/api/users', userRouter);// ou /api/utilisateurs
app.use('/api/shops', boutiqueRouter); // ou /api/shops
app.use('/api/chatbot', chatbotRouter);
app.use('/api/ledger', ledgerRouter);
app.use('/api/admin', adminRouter);

app.get('/', (req, res) => {
   res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
 });

app.listen(process.env.PORT ,() => {
      console.log('app listening ....');
      console.log(`Frontend accessible sur http://localhost:${process.env.PORT}/`);
   });