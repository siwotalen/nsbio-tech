// js/common.js ou dans le <script> de la page concernée

const API_BASE_URL_COMMON = 'http://localhost:8000/api'; // Assurez-vous que c'est défini


async function handleLogout() {
    const token = localStorage.getItem('authToken');
    if (!token) {
        // Déjà déconnecté localement, juste rediriger
        window.location.href = 'connexion.html';
        return;
    }

    try {
        // Appel API pour déconnexion côté serveur (optionnel mais recommandé)
        const response = await fetch(`${API_BASE_URL_COMMON}/auth/signout`, {
            method: 'POST', // Assurez-vous que votre route signout accepte POST ou changez ici
            headers: {
                'Authorization': `Bearer ${token}`
                // Pas besoin de Content-Type si le body est vide
            }
        });

        if (!response.ok) {
            // Même si l'API échoue, on déconnecte localement
            console.warn('API de déconnexion a retourné une erreur:', await response.text());
        }
    } catch (error) {
        console.error('Erreur lors de l\'appel à l\'API de déconnexion:', error);
        // Continuer la déconnexion locale même si l'API échoue
    } finally {
        // Déconnexion locale dans tous les cas
        localStorage.removeItem('authToken');
        localStorage.removeItem('userData'); // Supprimer aussi les infos utilisateur
        // Rediriger vers la page de connexion
        window.location.href = 'connexion.html';
    }
}

// Appeler cette fonction au chargement des pages où le bouton pourrait être présent
document.addEventListener('DOMContentLoaded', function() {
    checkLoginStatusAndSetupLogout();
    // ... autre logique de la page ...
});